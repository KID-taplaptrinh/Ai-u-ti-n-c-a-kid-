import { runAllKnowledgeTests } from '../src/services/knowledgeTests';

async function main() {
  console.log('--- ĐANG CHẠY BỘ KIỂM THỬ THỰC TẾ KHO KIẾN THỨC CỤC BỘ ---');
  const result = await runAllKnowledgeTests();
  console.log(`\nTổng số bài test: ${result.total}`);
  console.log(`Thành công (PASS): ${result.passedCount}`);
  console.log(`Thất bại (FAIL): ${result.failedCount}\n`);

  for (const t of result.results) {
    const status = t.passed ? '✅ [PASS]' : '❌ [FAIL]';
    console.log(`${status} ${t.name} (${t.category}) - ${t.durationMs}ms`);
    console.log(`    Thông điệp: ${t.message}`);
    if (t.details) {
      console.log(`    Chi tiết: ${t.details}`);
    }
  }

  if (result.failedCount > 0) {
    process.exit(1);
  } else {
    console.log('\n🎉 TOÀN BỘ 10 BÀI KIỂM THỬ THỰC TẾ ĐÃ VƯỢT QUA HOÀN TOÀN!');
  }
}

main().catch((err) => {
  console.error('Lỗi khi chạy bộ kiểm thử:', err);
  process.exit(1);
});
