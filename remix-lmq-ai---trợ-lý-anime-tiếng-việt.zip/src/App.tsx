import React, { useState, useEffect, useRef } from 'react';
import { Message, ExpressionType, CustomCharacterData } from './types';
import { processUserMessage } from './services/vietnameseRules';
import { PRESET_CHARACTERS } from './data/presetCharacters';
import { AnimeAvatar2D } from './components/AnimeAvatar2D';
import { VrmViewer } from './components/VrmViewer';
import { CharacterSelectorModal } from './components/CharacterSelectorModal';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { WindowsDownloadGuideModal } from './components/WindowsDownloadGuideModal';
import { ChessGameModal } from './components/ChessGameModal';
import { KnowledgeBaseModal } from './components/KnowledgeBaseModal';
import { getAllKnowledgeItems } from './services/knowledgeStorage';
import { searchRelatedKnowledgeItems } from './services/knowledgeSearch';
import { KnowledgeItem } from './types/knowledge';
import { Users, Box, Download, MessageSquare, Volume2, Sparkles, Swords, BookOpen } from 'lucide-react';

const STORAGE_KEYS = {
  CHAT: 'lmq_ai_chat_history_v2',
  ACTIVE_CHAR: 'lmq_ai_active_character_id_v2',
  CUSTOM_CHAR: 'lmq_ai_custom_character_data_v2',
  AUTO_SPEAK: 'lmq_ai_auto_speak_v2',
  VIEW_MODE: 'lmq_ai_view_mode_v2',
  USE_GEMINI_AI: 'lmq_ai_use_gemini_v1',
};

const INITIAL_MESSAGE: Message = {
  id: 'init-msg-1',
  sender: 'bot',
  text: 'Xin chào bạn! Mình là **LMQ AI** - trợ lý anime tiếng Việt thông minh của bạn! (✿◠‿◠)\n\nMình hoạt động **100% cục bộ trên trình duyệt của bạn**, hoàn toàn **không tốn phí API**, **không cần đăng nhập** và bảo mật dữ liệu tuyệt đối.\n\nBạn có thể thử hỏi hoặc trải nghiệm cùng mình:\n- ⛏️ **Minecraft (MC):** *"Cách chế tạo bàn phù phép"*, *"Xây cổng địa ngục"*, *"Tọa độ đào kim cương Y=-58"*\n- 💻 **Windows & Máy tính:** *"Dọn rác ổ C bị đầy"*, *"Phím tắt Windows hay"*, *"Xem cấu hình RAM CPU"*\n- 🌐 **Lập trình Web:** *"Căn giữa thẻ div trong CSS"*, *"Khái niệm Closure trong JavaScript"*, *"Lệnh Git cơ bản"*\n- ⭕ **Chơi cờ trực tiếp:** Gõ *"chơi cờ"* để đấu Cờ Caro hoặc Cờ Vua cùng mình!\n- ✍️ **Dạy LMQ AI:** Mở mục **"Kho Tri Thức"** ở góc trên để bổ sung kiến thức mới lưu vĩnh viễn vào IndexedDB!',
  timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
  expression: 'happy',
  matchedKnowledge: true,
};

export default function App() {
  // State: Tin nhắn & Chat
  const [messages, setMessages] = useState<Message[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CHAT);
      return saved ? JSON.parse(saved) : [INITIAL_MESSAGE];
    } catch {
      return [INITIAL_MESSAGE];
    }
  });

  // State: Nhân vật đang hoạt động
  const [activeCharacterId, setActiveCharacterId] = useState<string>(() => {
    return localStorage.getItem(STORAGE_KEYS.ACTIVE_CHAR) || 'aoi';
  });

  // State: Dữ liệu nhân vật tùy chỉnh (tải ảnh từ máy tính)
  const [customCharacter, setCustomCharacter] = useState<CustomCharacterData | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CUSTOM_CHAR);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // State: Chế độ hiển thị nhân vật ('2d' anime avatar hoặc '3d' Three.js VRM)
  const [viewMode, setViewMode] = useState<'2d' | '3d'>(() => {
    return (localStorage.getItem(STORAGE_KEYS.VIEW_MODE) as '2d' | '3d') || '2d';
  });

  // State: Biểu cảm hiện tại của nhân vật
  const [currentExpression, setCurrentExpression] = useState<ExpressionType>('idle');

  // State: Giọng nói (SpeechSynthesis)
  const [autoSpeak, setAutoSpeak] = useState<boolean>(() => {
    return localStorage.getItem(STORAGE_KEYS.AUTO_SPEAK) === 'true';
  });
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);

  // State: Kho kiến thức cục bộ (IndexedDB)
  const [knowledgeItems, setKnowledgeItems] = useState<KnowledgeItem[]>([]);
  const [isKnowledgeModalOpen, setIsKnowledgeModalOpen] = useState(false);
  const [knowledgeModalTab, setKnowledgeModalTab] = useState<'browse' | 'teach' | 'backup' | 'test'>('browse');
  const [knowledgeModalQuery, setKnowledgeModalQuery] = useState('');

  // State: Game Modals
  const [isGameModalOpen, setIsGameModalOpen] = useState(false);
  const [gameModalType, setGameModalType] = useState<'caro' | 'chess'>('caro');

  // State: Character & Windows Modals
  const [isSelectorOpen, setIsSelectorOpen] = useState(false);
  const [isWindowsGuideOpen, setIsWindowsGuideOpen] = useState(false);

  // State: Typing indicator
  const [isTyping, setIsTyping] = useState(false);

  // State: Tích hợp Gemini AI miễn phí (gemini-4-hydrogen) qua server-side
  const [geminiAvailable, setGeminiAvailable] = useState(false);
  const [useGeminiAi, setUseGeminiAi] = useState<boolean>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USE_GEMINI_AI);
    return saved === null ? true : saved === 'true';
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Tải toàn bộ kho kiến thức từ IndexedDB vào RAM khi khởi động ứng dụng
  const loadKnowledgeData = async () => {
    try {
      const data = await getAllKnowledgeItems();
      setKnowledgeItems(data);
    } catch (e) {
      console.warn('Lỗi nạp kho kiến thức IndexedDB:', e);
    }
  };

  useEffect(() => {
    loadKnowledgeData();
    // Kiểm tra server có cấu hình GEMINI_API_KEY miễn phí hay không
    fetch('/api/ai-status')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && data.configured) {
          setGeminiAvailable(true);
        }
      })
      .catch(() => {
        setGeminiAvailable(false);
      });
  }, []);

  // Tự động cuộn xuống cuối khi có tin nhắn mới
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Lưu lịch sử tin nhắn vào localStorage (Độc lập hoàn toàn với kho kiến thức)
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CHAT, JSON.stringify(messages));
    } catch (e) {
      console.warn('Không thể lưu tin nhắn vào localStorage:', e);
    }
  }, [messages]);

  // Lưu nhân vật đã chọn vào localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_CHAR, activeCharacterId);
    } catch (e) {
      console.warn('Lỗi lưu active character:', e);
    }
  }, [activeCharacterId]);

  // Lưu nhân vật tùy chỉnh vào localStorage
  useEffect(() => {
    try {
      if (customCharacter) {
        localStorage.setItem(STORAGE_KEYS.CUSTOM_CHAR, JSON.stringify(customCharacter));
      } else {
        localStorage.removeItem(STORAGE_KEYS.CUSTOM_CHAR);
      }
    } catch (e) {
      console.warn('Lỗi lưu custom character data:', e);
    }
  }, [customCharacter]);

  // Lưu cấu hình tự động đọc vào localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.AUTO_SPEAK, String(autoSpeak));
    } catch (e) {
      console.warn('Lỗi lưu auto speak:', e);
    }
  }, [autoSpeak]);

  // Lưu view mode vào localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.VIEW_MODE, viewMode);
    } catch (e) {
      console.warn('Lỗi lưu view mode:', e);
    }
  }, [viewMode]);

  // Lưu tùy chọn dùng Gemini AI vào localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.USE_GEMINI_AI, String(useGeminiAi));
    } catch (e) {
      console.warn('Lỗi lưu useGeminiAi:', e);
    }
  }, [useGeminiAi]);

  // Lấy thông tin nhân vật hiện tại
  const currentPreset = PRESET_CHARACTERS.find((c) => c.id === activeCharacterId);
  const characterDisplayName =
    activeCharacterId === 'custom' && customCharacter
      ? customCharacter.name
      : currentPreset?.name || 'LMQ AI';

  // Quản lý phát âm thanh giọng nói tiếng Việt bằng SpeechSynthesis API của trình duyệt
  const speakText = (text: string, msgId?: string) => {
    if (!('speechSynthesis' in window)) {
      console.warn('Trình duyệt không hỗ trợ Web Speech Synthesis');
      return;
    }

    window.speechSynthesis.cancel();

    const cleanText = text
      .replace(/```[\s\S]*?```/g, 'Đoạn mã lập trình')
      .replace(/\$\$[\s\S]*?\$\$/g, 'Phép tính')
      .replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '$1 chia $2')
      .replace(/\\times/g, ' nhân ')
      .replace(/\\Omega/g, ' ôm ')
      .replace(/\\mathcal\{([^}]+)\}/g, '$1')
      .replace(/\\mathbf\{([^}]+)\}/g, '$1')
      .replace(/[$*_#`[\]()>—-]/g, ' ')
      .replace(/https?:\/\/\S+/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = 'vi-VN';
    utterance.rate = 1.05;
    utterance.pitch = 1.1;

    const voices = window.speechSynthesis.getVoices();
    const viVoice = voices.find((v) => v.lang.includes('vi') || v.lang.includes('VN'));
    if (viVoice) {
      utterance.voice = viVoice;
    }

    utterance.onstart = () => {
      setIsSpeaking(true);
      if (msgId) setSpeakingMessageId(msgId);
      setCurrentExpression('speaking');
    };

    utterance.onend = () => {
      setIsSpeaking(false);
      setSpeakingMessageId(null);
      setCurrentExpression('idle');
    };

    utterance.onerror = () => {
      setIsSpeaking(false);
      setSpeakingMessageId(null);
      setCurrentExpression('idle');
    };

    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
    setSpeakingMessageId(null);
    setCurrentExpression('idle');
  };

  // Mở bàn cờ chơi với loại cờ cụ thể
  const handleOpenGame = (type: 'caro' | 'chess' = 'caro') => {
    setGameModalType(type);
    setIsGameModalOpen(true);
  };

  // Gọi endpoint proxy /api/chat-gemini (gemini-4-hydrogen miễn phí trên server-side) kèm ngữ cảnh kho tri thức liên quan
  const callGeminiServer = async (
    queryText: string
  ): Promise<{ text: string; expression: ExpressionType; error?: string } | null> => {
    try {
      const relatedItems = searchRelatedKnowledgeItems(queryText, knowledgeItems, undefined, 3);
      const knowledgeContext = relatedItems.map((item) => ({
        title: item.title,
        category: item.category,
        content: item.content.slice(0, 600),
      }));

      const res = await fetch('/api/chat-gemini', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: queryText,
          characterName: characterDisplayName,
          personality: currentPreset?.personality,
          history: messages.slice(-4).map((m) => ({ sender: m.sender, text: m.text })),
          knowledgeContext,
        }),
      });
      const data = await res.json();
      if (!res.ok || data.fallback) {
        return { text: '', expression: 'thinking', error: data?.error };
      }
      return {
        text: data.text,
        expression: (data.expression as ExpressionType) || 'happy',
      };
    } catch {
      return null;
    }
  };

  // Xử lý hỏi trực tiếp Gemini AI từ nút trên tin nhắn fallback
  const handleAskGemini = async (question: string) => {
    if (!question.trim() || isTyping) return;
    setCurrentExpression('thinking');
    setIsTyping(true);

    const aiRes = await callGeminiServer(question);
    const botTimeStr = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });

    if (aiRes && aiRes.text) {
      const aiMsg: Message = {
        id: `bot-ai-${Date.now()}`,
        sender: 'bot',
        text: aiRes.text,
        timestamp: botTimeStr,
        expression: aiRes.expression,
        isGeminiAi: true,
      };
      setMessages((prev) => [...prev, aiMsg]);
      setCurrentExpression(aiRes.expression);
      setIsTyping(false);

      if (autoSpeak) {
        speakText(aiRes.text, aiMsg.id);
      } else {
        setTimeout(() => {
          setCurrentExpression((prev) => (prev === 'speaking' ? prev : 'idle'));
        }, 5000);
      }
    } else {
      const errMsg: Message = {
        id: `bot-ai-err-${Date.now()}`,
        sender: 'bot',
        text: `Không thể kết nối Gemini AI lúc này${aiRes?.error ? ` (${aiRes.error})` : ''}. Bạn vẫn có thể dùng nút **"Dạy câu này cho LMQ AI"** hoặc **"Tra cứu Google"** nhé!`,
        timestamp: botTimeStr,
        expression: 'sad',
        queryForSearch: question,
        triggerTeach: question,
      };
      setMessages((prev) => [...prev, errMsg]);
      setCurrentExpression('sad');
      setIsTyping(false);
    }
  };

  // Xử lý gửi tin nhắn của người dùng: Ưu tiên Kho Tri Thức Cục Bộ, mở rộng với Gemini AI miễn phí khi cần
  const handleSendMessage = (userText: string) => {
    const timeStr = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });

    const newUserMsg: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: userText,
      timestamp: timeStr,
      expression: 'idle',
    };

    setMessages((prev) => [...prev, newUserMsg]);
    setCurrentExpression('thinking');
    setIsTyping(true);

    // Tra cứu qua Kho Kiến Thức Cục Bộ và bộ quy tắc tiếng Việt với độ trễ phản hồi tự nhiên (280ms)
    setTimeout(async () => {
      const ruleResult = processUserMessage(
        userText,
        knowledgeItems,
        activeCharacterId,
        characterDisplayName,
        geminiAvailable && useGeminiAi
      );

      // Nếu kho cục bộ chưa có câu trả lời (triggerTeach) và Gemini AI miễn phí đang bật, hỏi Gemini AI
      if (ruleResult.triggerTeach && geminiAvailable && useGeminiAi) {
        const aiRes = await callGeminiServer(userText);
        if (aiRes && aiRes.text) {
          const botTimeStr = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
          const aiMsg: Message = {
            id: `bot-${Date.now()}`,
            sender: 'bot',
            text: aiRes.text,
            timestamp: botTimeStr,
            expression: aiRes.expression,
            isGeminiAi: true,
          };
          setMessages((prev) => [...prev, aiMsg]);
          setCurrentExpression(aiRes.expression);
          setIsTyping(false);

          if (autoSpeak) {
            speakText(aiRes.text, aiMsg.id);
          } else {
            setTimeout(() => {
              setCurrentExpression((prev) => (prev === 'speaking' ? prev : 'idle'));
            }, 5000);
          }
          return;
        }
      }

      const botTimeStr = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });

      const newBotMsg: Message = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: ruleResult.text,
        timestamp: botTimeStr,
        expression: ruleResult.expression,
        queryForSearch: ruleResult.queryForSearch,
        mathCalculation: ruleResult.mathCalculation,
        triggerGame: ruleResult.triggerGame,
        triggerKnowledgeModal: ruleResult.triggerKnowledgeModal,
        matchedKnowledge: ruleResult.matchedKnowledge,
        knowledgeCategory: ruleResult.knowledgeCategory,
        triggerTeach: ruleResult.triggerTeach,
        relatedSuggestions: ruleResult.relatedSuggestions,
      };

      setMessages((prev) => [...prev, newBotMsg]);
      setCurrentExpression(ruleResult.expression);
      setIsTyping(false);

      // Nếu có lệnh mở Kho Kiến Thức
      if (ruleResult.triggerKnowledgeModal) {
        setKnowledgeModalTab('browse');
        setKnowledgeModalQuery('');
        setIsKnowledgeModalOpen(true);
      } else if (ruleResult.triggerGame) {
        // Nếu có lệnh mở Cờ
        handleOpenGame(ruleResult.triggerGame);
      }

      if (autoSpeak) {
        speakText(ruleResult.text, newBotMsg.id);
      } else {
        setTimeout(() => {
          setCurrentExpression((prev) => (prev === 'speaking' ? prev : 'idle'));
        }, 5000);
      }
    }, 280);
  };

  // Xóa lịch sử chat (KHÔNG làm mất kho kiến thức lưu trong IndexedDB!)
  const handleClearChat = () => {
    if (window.confirm('Bạn có chắc chắn muốn xóa lịch sử đoạn chat? Kho kiến thức đã lưu của bạn vẫn sẽ được giữ nguyên an toàn.')) {
      stopSpeaking();
      const resetMsg: Message = {
        ...INITIAL_MESSAGE,
        id: `init-${Date.now()}`,
        timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages([resetMsg]);
      setCurrentExpression('idle');
    }
  };

  return (
    <div className="min-h-screen bg-[#090714] text-slate-100 flex flex-col font-sans">
      {/* ===================== TOP NAVIGATION BAR ===================== */}
      <header className="h-16 border-b border-purple-500/20 bg-[#0e081e]/90 backdrop-blur-md sticky top-0 z-40 px-3 sm:px-6 md:px-8 flex items-center justify-between gap-2 sm:gap-4">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-purple-600 to-pink-500 p-0.5 shadow-lg shadow-purple-900/50 flex items-center justify-center">
            <div className="w-full h-full bg-[#0e081e] rounded-[10px] flex items-center justify-center">
              <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-cyan-400" />
            </div>
          </div>
          <div>
            <span className="text-base sm:text-lg font-black tracking-wider text-white">
              LMQ <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400">AI</span>
            </span>
          </div>
        </div>

        {/* Zone 2: Navigation Links, Knowledge Button & View Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          {/* Nút Kho Tri Thức Cục Bộ (Local Knowledge Base) */}
          <button
            type="button"
            onClick={() => {
              setKnowledgeModalTab('browse');
              setKnowledgeModalQuery('');
              setIsKnowledgeModalOpen(true);
            }}
            className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-[#180f33] hover:bg-purple-900/60 border border-purple-500/35 text-cyan-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm hover:border-cyan-400"
            title="Mở Kho Kiến Thức Cục Bộ & Dạy LMQ AI"
          >
            <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden md:inline">Kho Tri Thức ({knowledgeItems.length})</span>
            <span className="md:hidden">Tri thức ({knowledgeItems.length})</span>
          </button>

          {/* Nút Chơi Cờ nổi bật */}
          <button
            type="button"
            onClick={() => handleOpenGame('caro')}
            className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-purple-900/40 transition-all hover:scale-105"
            title="Mở Bàn cờ Caro & Cờ Vua đấu cùng Bot"
          >
            <Swords className="w-3.5 h-3.5" />
            <span>Chơi Cờ</span>
          </button>

          {/* Switch 2D Anime Avatar / 3D VRM */}
          <div className="hidden lg:flex p-1 rounded-xl bg-[#160f2e] border border-purple-500/30 items-center gap-1">
            <button
              type="button"
              onClick={() => setViewMode('2d')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
                viewMode === '2d'
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <MessageSquare className="w-3 h-3" />
              <span>2D</span>
            </button>

            <button
              type="button"
              onClick={() => setViewMode('3d')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
                viewMode === '3d'
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Box className="w-3 h-3" />
              <span>3D VRM</span>
            </button>
          </div>

          {/* Nút mở Thư viện "Nhân vật của tôi" */}
          <button
            type="button"
            onClick={() => setIsSelectorOpen(true)}
            className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-purple-950/60 hover:bg-purple-800/60 border border-purple-500/35 text-purple-200 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm"
          >
            <Users className="w-3.5 h-3.5 text-pink-400" />
            <span className="hidden sm:inline">Nhân vật</span>
          </button>
        </div>

        {/* Zone 3: Hướng dẫn chạy Windows */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setIsWindowsGuideOpen(true)}
            className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-200 hover:text-white text-xs font-medium flex items-center gap-1.5 transition-colors"
            title="Xem hướng dẫn chạy ứng dụng trên máy tính Windows"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden md:inline">Windows PC</span>
          </button>
        </div>
      </header>

      {/* ===================== MAIN LAYOUT ===================== */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-2 sm:p-5 grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-5 items-stretch">
        {/* ===================== KHU VỰC NHÂN VẬT ANIME (Trái / 4 Cột) ===================== */}
        <section className="lg:col-span-4 bg-[#120a24]/90 rounded-2xl border border-purple-500/25 p-4 sm:p-5 shadow-2xl flex flex-col justify-between items-center relative overflow-hidden">
          {/* Hào quang nền phía sau */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-64 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />

          {/* Header phụ nhân vật */}
          <div className="w-full flex items-center justify-between pb-3 border-b border-purple-500/15 relative z-10">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span>{characterDisplayName}</span>
              </h2>
              <p className="text-[11px] text-purple-300/80">
                {activeCharacterId === 'custom'
                  ? 'Ảnh avatar tùy chỉnh của bạn'
                  : currentPreset?.subtitle}
              </p>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setViewMode(viewMode === '2d' ? '3d' : '2d')}
                className="lg:hidden text-xs px-2 py-1 rounded-lg bg-purple-950/60 border border-purple-500/30 text-purple-300"
              >
                {viewMode === '2d' ? '3D' : '2D'}
              </button>
              <button
                type="button"
                onClick={() => setIsSelectorOpen(true)}
                className="text-xs px-2.5 py-1 rounded-lg bg-purple-900/50 hover:bg-purple-700/60 border border-purple-500/40 text-purple-200 hover:text-white transition-colors"
              >
                Đổi
              </button>
            </div>
          </div>

          {/* Vùng hiển thị Avatar 2D hoặc 3D VRM Three.js */}
          <div className="w-full flex-1 flex items-center justify-center py-4 sm:py-6 relative z-10">
            {viewMode === '2d' ? (
              <AnimeAvatar2D
                characterId={activeCharacterId}
                expression={currentExpression}
                customCharacter={customCharacter}
                isSpeaking={isSpeaking}
              />
            ) : (
              <VrmViewer isSpeaking={isSpeaking} />
            )}
          </div>

          {/* Thẻ mô tả & tính cách nhân vật */}
          <div className="w-full pt-3 border-t border-purple-500/15 relative z-10">
            {activeCharacterId === 'custom' && customCharacter ? (
              <div className="text-center text-xs text-slate-300">
                <p className="font-semibold text-purple-300">Trợ lý tùy biến riêng của bạn</p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Đã tải {Object.keys(customCharacter.images).length} biểu cảm · Tự động lưu trên máy
                </p>
              </div>
            ) : (
              <div className="space-y-1 text-center">
                <p className="text-xs text-slate-300 font-medium leading-relaxed">
                  "{currentPreset?.description}"
                </p>
                <div className="flex items-center justify-center gap-2 text-[11px] text-purple-300 pt-1">
                  <span>Phong cách: <strong>{currentPreset?.personality}</strong></span>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* ===================== KHU VỰC HỘI THOẠI (Phải / 8 Cột) ===================== */}
        <section className="lg:col-span-8 bg-[#120a24]/90 rounded-2xl border border-purple-500/25 p-3 sm:p-5 shadow-2xl flex flex-col justify-between h-[640px] lg:h-[720px] relative">
          {/* Header khu vực chat */}
          <div className="flex items-center justify-between pb-3 border-b border-purple-500/15 gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 shrink-0" />
              <span className="text-xs font-bold text-slate-200 truncate">
                Kho Tri Thức ({knowledgeItems.length} chủ đề)
              </span>
              <span className="text-xs text-slate-500 hidden sm:inline">· {messages.length} tin nhắn</span>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {geminiAvailable && (
                <button
                  type="button"
                  onClick={() => setUseGeminiAi((prev) => !prev)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all ${
                    useGeminiAi
                      ? 'bg-indigo-950/70 border-indigo-400/40 text-indigo-200 hover:bg-indigo-900/60'
                      : 'bg-slate-900/70 border-slate-700 text-slate-400 hover:text-slate-200'
                  }`}
                  title="Bật/tắt chế độ Gemini AI miễn phí khi Kho Tri Thức Cục Bộ chưa có câu trả lời"
                >
                  <Sparkles className={`w-3.5 h-3.5 ${useGeminiAi ? 'text-cyan-400' : 'text-slate-500'}`} />
                  <span>{useGeminiAi ? 'Gemini AI: Bật' : 'Chỉ Offline'}</span>
                </button>
              )}

              {isSpeaking && (
                <button
                  type="button"
                  onClick={stopSpeaking}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-pink-950/60 border border-pink-500/40 text-pink-300 text-xs font-semibold animate-pulse hover:bg-pink-900/60 transition-colors"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Dừng đọc</span>
                </button>
              )}
            </div>
          </div>

          {/* Danh sách tin nhắn cuộn */}
          <div className="flex-1 overflow-y-auto py-3 sm:py-4 space-y-4 pr-1">
            {messages.map((msg) => (
              <ChatMessage
                key={msg.id}
                message={msg}
                botName={characterDisplayName}
                onSpeak={(text, id) => speakText(text, id)}
                isSpeaking={isSpeaking && speakingMessageId === msg.id}
                onStopSpeak={stopSpeaking}
                onOpenGame={handleOpenGame}
                onOpenKnowledge={() => {
                  setKnowledgeModalTab('browse');
                  setIsKnowledgeModalOpen(true);
                }}
                onTeach={(q) => {
                  setKnowledgeModalTab('teach');
                  setKnowledgeModalQuery(q);
                  setIsKnowledgeModalOpen(true);
                }}
                onSelectPrompt={(prompt) => handleSendMessage(prompt)}
                onAskGemini={handleAskGemini}
                geminiAvailable={geminiAvailable}
              />
            ))}

            {/* Hiệu ứng đang tra cứu (Typing Indicator) */}
            {isTyping && (
              <div className="flex items-center gap-2 text-xs text-cyan-300 pl-11 animate-pulse">
                <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                <span className="text-[11px] text-cyan-400/80 ml-1">
                  {characterDisplayName} đang tra cứu kho tri thức cục bộ...
                </span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Thanh nhập tin nhắn và gợi ý */}
          <div className="pt-3 border-t border-purple-500/15">
            <ChatInput
              onSendMessage={handleSendMessage}
              onClearChat={handleClearChat}
              autoSpeak={autoSpeak}
              onToggleAutoSpeak={() => setAutoSpeak((prev) => !prev)}
              onOpenGameModal={() => handleOpenGame('caro')}
              onOpenKnowledgeModal={() => {
                setKnowledgeModalTab('browse');
                setIsKnowledgeModalOpen(true);
              }}
              disabled={isTyping}
            />
          </div>
        </section>
      </main>

      {/* ===================== MODALS ===================== */}
      {/* 1. Modal Kho Kiến Thức Cục Bộ (Local Knowledge Base) */}
      <KnowledgeBaseModal
        isOpen={isKnowledgeModalOpen}
        onClose={() => setIsKnowledgeModalOpen(false)}
        botName={characterDisplayName}
        initialTab={knowledgeModalTab}
        initialQuery={knowledgeModalQuery}
        onKnowledgeUpdated={loadKnowledgeData}
      />

      {/* 2. Modal Bàn cờ Tương tác (Caro & Cờ Vua) */}
      <ChessGameModal
        isOpen={isGameModalOpen}
        onClose={() => setIsGameModalOpen(false)}
        botName={characterDisplayName}
        initialGameType={gameModalType}
        onBotExpressionChange={(expr) => setCurrentExpression(expr)}
      />

      {/* 3. Modal Anime Character Selector */}
      <CharacterSelectorModal
        isOpen={isSelectorOpen}
        onClose={() => setIsSelectorOpen(false)}
        activeCharacterId={activeCharacterId}
        onSelectCharacter={(id) => {
          setActiveCharacterId(id);
          stopSpeaking();
        }}
        customCharacter={customCharacter}
        onSaveCustomCharacter={(data) => {
          setCustomCharacter(data);
          setActiveCharacterId('custom');
        }}
        onClearCustomCharacter={() => {
          setCustomCharacter(null);
          if (activeCharacterId === 'custom') {
            setActiveCharacterId('aoi');
          }
        }}
      />

      {/* 4. Modal Hướng dẫn Windows */}
      <WindowsDownloadGuideModal
        isOpen={isWindowsGuideOpen}
        onClose={() => setIsWindowsGuideOpen(false)}
      />
    </div>
  );
}
