export type ExpressionType = 'idle' | 'happy' | 'sad' | 'thinking' | 'speaking';

export interface Message {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  expression: ExpressionType;
  queryForSearch?: string;
  mathCalculation?: string;
  triggerGame?: 'caro' | 'chess';
  triggerKnowledgeModal?: boolean;
  matchedKnowledge?: boolean;
  isGeminiAi?: boolean;
  knowledgeCategory?: string;
  triggerTeach?: string;
  relatedSuggestions?: string[];
}

export interface PresetCharacter {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  accentColor: string;
  personality: string;
  tag: string;
}

export interface CustomCharacterData {
  id: string;
  name: string;
  images: Partial<Record<ExpressionType, string>>; // base64 or object URLs
  updatedAt: number;
}
