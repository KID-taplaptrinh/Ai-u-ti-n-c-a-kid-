// Types for Local Knowledge Base (Kho kiến thức cục bộ)

export type KnowledgeCategory =
  | 'minecraft'
  | 'windows'
  | 'computer'
  | 'anime'
  | 'html'
  | 'css'
  | 'html_css'
  | 'javascript'
  | 'programming'
  | 'math'
  | 'science'
  | 'general'
  | 'custom';

export interface KnowledgeCategoryInfo {
  id: KnowledgeCategory;
  name: string;
  icon: string;
  badgeColor: string;
  description: string;
}

export const KNOWLEDGE_CATEGORIES: Record<KnowledgeCategory, KnowledgeCategoryInfo> = {
  minecraft: {
    id: 'minecraft',
    name: 'Minecraft (MC)',
    icon: 'Pickaxe',
    badgeColor: 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300',
    description: 'Công thức chế tạo, phù phép, tọa độ quặng, cổng Nether/End và mẹo sinh tồn',
  },
  windows: {
    id: 'windows',
    name: 'Windows & PC',
    icon: 'Monitor',
    badgeColor: 'bg-blue-950/80 border-blue-500/40 text-blue-300',
    description: 'Phím tắt hệ thống, dọn dẹp ổ C, quản lý Task Manager, tối ưu hiệu năng',
  },
  computer: {
    id: 'computer',
    name: 'Phần cứng & Mạng',
    icon: 'Cpu',
    badgeColor: 'bg-cyan-950/80 border-cyan-500/40 text-cyan-300',
    description: 'CPU, RAM, ổ cứng SSD/HDD, card đồ họa, router wifi, địa chỉ IP',
  },
  html: {
    id: 'html',
    name: 'HTML & Cấu trúc',
    icon: 'FileCode',
    badgeColor: 'bg-rose-950/80 border-rose-500/40 text-rose-300',
    description: 'Thẻ ngữ nghĩa Semantic HTML5, form, thẻ meta SEO, accessibility',
  },
  css: {
    id: 'css',
    name: 'CSS & Bố cục',
    icon: 'Palette',
    badgeColor: 'bg-pink-950/80 border-pink-500/40 text-pink-300',
    description: 'Flexbox, CSS Grid, căn giữa thẻ div, responsive rem/vw, Box Model',
  },
  html_css: {
    id: 'html_css',
    name: 'HTML & CSS',
    icon: 'Layout',
    badgeColor: 'bg-pink-950/80 border-pink-500/40 text-pink-300',
    description: 'Thẻ ngữ nghĩa, Flexbox, CSS Grid, căn giữa, responsive, animation',
  },
  javascript: {
    id: 'javascript',
    name: 'JavaScript',
    icon: 'Code2',
    badgeColor: 'bg-amber-950/80 border-amber-500/40 text-amber-300',
    description: 'Closure, Scope, Async/Await, Promise, Array methods, Event Loop',
  },
  programming: {
    id: 'programming',
    name: 'Lập trình & Git',
    icon: 'Terminal',
    badgeColor: 'bg-purple-950/80 border-purple-500/40 text-purple-300',
    description: 'Git lệnh cơ bản, thuật toán, REST API, Docker, tư duy giải quyết vấn đề',
  },
  anime: {
    id: 'anime',
    name: 'Anime & Manga',
    icon: 'Sparkles',
    badgeColor: 'bg-fuchsia-950/80 border-fuchsia-500/40 text-fuchsia-300',
    description: 'Thuật ngữ Otaku, thể loại Isekai/Shounen, các bộ phim anime kinh điển',
  },
  math: {
    id: 'math',
    name: 'Toán học',
    icon: 'Calculator',
    badgeColor: 'bg-indigo-950/80 border-indigo-500/40 text-indigo-300',
    description: 'Định lý hình học, công thức lượng giác, đại số, số Pi, thống kê',
  },
  science: {
    id: 'science',
    name: 'Khoa học & Vũ trụ',
    icon: 'Atom',
    badgeColor: 'bg-teal-950/80 border-teal-500/40 text-teal-300',
    description: 'Vật lý, hóa học, sinh học, vũ trụ, vận tốc ánh sáng, hệ mặt trời',
  },
  general: {
    id: 'general',
    name: 'Kiến thức phổ thông',
    icon: 'BookOpen',
    badgeColor: 'bg-orange-950/80 border-orange-500/40 text-orange-300',
    description: 'Mẹo học tập Pomodoro, kỹ thuật Feynman, văn hóa ẩm thực Việt Nam',
  },
  custom: {
    id: 'custom',
    name: 'Do bạn đóng góp',
    icon: 'UserPlus',
    badgeColor: 'bg-rose-950/80 border-rose-500/40 text-rose-300',
    description: 'Kiến thức do bạn tự dạy cho LMQ AI lưu trên trình duyệt này',
  },
};

export interface KnowledgeItem {
  id: string;
  category: KnowledgeCategory;
  title: string;
  content: string; // Nội dung câu trả lời hoàn chỉnh (hỗ trợ Markdown)
  keywords: string[]; // Từ khóa cốt lõi
  synonyms: string[]; // Từ đồng nghĩa, cách gọi khác (vd: enchanting table, bàn phù phép, ban enchant)
  sampleQuestions: string[]; // Các biến thể câu hỏi người dùng thường hỏi
  source?: string; // Nguồn tham khảo
  verified: boolean; // Đã xác minh tính chính xác
  isCustom?: boolean; // Do người dùng tự tạo qua "Dạy LMQ AI"
  createdAt: number;
  updatedAt: number;
}

export interface KnowledgeSearchResult {
  item: KnowledgeItem;
  score: number; // Điểm xếp hạng tương quan (0 - 100+)
  confidence: 'high' | 'medium' | 'low';
  matchedReasons: string[];
  relatedMatches?: KnowledgeItem[];
}

export interface KnowledgeBackupFile {
  version: string;
  exportedAt: string;
  appName: string;
  totalItems: number;
  items: KnowledgeItem[];
}
