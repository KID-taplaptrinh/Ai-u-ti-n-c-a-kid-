import { KnowledgeItem } from '../types/knowledge';

export const DEFAULT_KNOWLEDGE_BASE: KnowledgeItem[] = [
  // =========================================================================
  // 1. MINECRAFT (MC)
  // =========================================================================
  {
    id: 'mc-enchanting-table',
    category: 'minecraft',
    title: 'Cách chế tạo và sử dụng Bàn Phù Phép (Enchanting Table) trong Minecraft',
    content: `Để chế tạo **Bàn Phù Phép (Enchanting Table)** trong Minecraft, bạn cần chuẩn bị các nguyên liệu sau:

### 1. Nguyên liệu chế tạo:
- 📖 **1 Quyển sách (Book)**: Chế tạo từ 3 giấy (Paper) + 1 miếng da (Leather).
- 💎 **2 Kim cương (Diamond)**: Khai thác ở các tầng sâu dưới lòng đất (tốt nhất là Y = -58).
- ⬛ **4 Hắc diện thạch (Obsidian)**: Khai thác bằng cúp kim cương từ khối dung nham tiếp xúc với nước.

### 2. Công thức đặt trên Bàn Chế Tạo (3x3):
- Hàng 1 (trên cùng): Ô giữa đặt **1 Quyển sách**.
- Hàng 2 (ở giữa): [Kim cương] - [Hắc diện thạch] - [Kim cương].
- Hàng 3 (dưới cùng): [Hắc diện thạch] - [Hắc diện thạch] - [Hắc diện thạch].

### 3. Mẹo nâng cấp cấp độ 30 (Max Level):
- Xếp **15 Kệ sách (Bookshelf)** cách bàn phù phép đúng 1 ô trống (hình vòng cung quanh bàn, cao tối đa 2 khối, không đặt đuốc hay thảm ở ô giữa).
- Khi phù phép cần mang theo **Ngọc lưu ly (Lapis Lazuli)** và đủ cấp độ kinh nghiệm (XP)!`,
    keywords: ['minecraft', 'mc', 'ban phu phep', 'enchanting table', 'enchant', 'phu phep', 'sach', 'obsidian', 'kim cuong', 'lapis lazuli'],
    synonyms: ['enchant table', 'ban enchant', 'lam ban phu phep', 'che tao ban phu phep', 'enchanting', 'cuon sach phu phep', 'bang me hoac'],
    sampleQuestions: [
      'Minecraft chế tạo bàn phù phép như nào',
      'Làm enchanting table trong MC ra sao',
      'Cần nguyên liệu gì để tạo bàn phù phép',
      'Cách làm bàn phù phép cấp 30 trong minecraft',
      'Công thức bàn enchant mc',
      'Làm bảng mê hoặc trong MC ra sao',
    ],
    source: 'Minecraft Official Wiki',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'mc-nether-portal',
    category: 'minecraft',
    title: 'Cách xây Cổng Địa Ngục (Nether Portal) trong Minecraft',
    content: `**Cổng Địa Ngục (Nether Portal)** là cánh cửa đưa bạn từ Overworld tới chiều không gian Nether nguy hiểm và tài nguyên:

### 1. Nguyên liệu cần có:
- Ít nhất **10 khối Hắc diện thạch (Obsidian)** (khung tối thiểu không cần 4 góc) hoặc **14 khối Obsidian** (khung đầy đủ 4 góc).
- **1 Bật lửa (Flint and Steel)** hoặc Quả cầu lửa (Fire Charge) để kích hoạt.

### 2. Kích thước khung cổng chuẩn:
- Chiều rộng bên trong: **2 khối**.
- Chiều cao bên trong: **3 khối**.
- Kích thước toàn khung: Rộng 4 khối x Cao 5 khối.

### 3. Cách kích hoạt:
- Cầm bật lửa trên tay, nhấp chuột phải vào bề mặt phía trong của khung Obsidian. Ngọn lửa sẽ biến thành màn sương tím huyền bí!

### 4. Mẹo không cần cúp kim cương:
- Bạn có thể dùng xô dung nham (Lava) đổ vào các ô nước đã xếp ván gỗ để đúc Obsidian tạo thành hình khung cổng trực tiếp!`,
    keywords: ['minecraft', 'mc', 'cong dia nguc', 'nether portal', 'obsidian', 'bat lua', 'dia nguc', 'nether'],
    synonyms: ['cong nether', 'lam cong dia nguc', 'xay cong nether', 'kich hoat cong dia nguc', 'nether portal mc'],
    sampleQuestions: [
      'Cách làm cổng địa ngục trong minecraft',
      'Xây nether portal trong mc cần mấy khối obsidian',
      'Làm sao để kích hoạt cổng nether',
      'Cổng địa ngục mc làm thế nào',
    ],
    source: 'Minecraft Official Wiki',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'mc-find-diamond',
    category: 'minecraft',
    title: 'Tọa độ và mẹo đào Kim Cương (Diamond) hiệu quả nhất trong Minecraft',
    content: `Kể từ phiên bản Minecraft 1.18 (Caves & Cliffs) trở đi, thuật toán tạo quặng đã thay đổi:

### 1. Tọa độ kim cương xuất hiện nhiều nhất:
- Kim cương xuất hiện từ độ cao **Y = 14 xuống đến Y = -63**.
- Càng đào sâu xuống đáy thế giới, mật độ kim cương càng dày đặc.
- Tọa độ tối ưu nhất để đào hầm (Strip Mining) là **Y = -58 hoặc Y = -59** (ngay sát trên tầng đá nền Bedrock để tránh hồ dung nham ngầm ở Y = -54).

### 2. Dụng cụ cần thiết:
- Phải dùng **Cúp Sắt (Iron Pickaxe)**, Cúp Kim Cương hoặc Cúp Netherite. (Tuyệt đối KHÔNG dùng cúp đá hay vàng vì sẽ vỡ quặng mà không rơi kim cương!).

### 3. Mẹo nhân đôi số kim cương:
- Hãy phù phép cúp với bùa **Gia tài (Fortune III)**, bạn có thể nhận từ 1 đến 4 viên kim cương từ một khối quặng duy nhất!`,
    keywords: ['minecraft', 'mc', 'dao kim cuong', 'tim kim cuong', 'diamond', 'toa do kim cuong', 'y -58', 'fortune'],
    synonyms: ['tim diamond trong mc', 'toa do diamond', 'kim cuong o tang bao nhieu', 'dao khoang san'],
    sampleQuestions: [
      'Kim cương trong Minecraft tìm ở tầng bao nhiêu',
      'Tọa độ đào kim cương mc phiên bản mới',
      'Cách kiếm nhiều kim cương nhất trong minecraft',
      'Đào kim cương ở độ cao nào',
    ],
    source: 'Minecraft Official Mining Guide',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'mc-brewing-stand',
    category: 'minecraft',
    title: 'Cách chế tạo Giàn Pha Thuốc (Brewing Stand) và pha thuốc cơ bản trong Minecraft',
    content: `**Giàn Pha Thuốc (Brewing Stand)** là công cụ thiết yếu để bào chế các loại thuốc tàng hình, kháng lửa, hồi máu và tăng sức mạnh:

### 1. Nguyên liệu chế tạo:
- 🔥 **1 Que quỷ lửa (Blaze Rod)**: Đánh bại quái vật Blaze trong pháo đài Nether (Nether Fortress).
- 🪨 **3 Đá cuội (Cobblestone)** hoặc Đá đen (Blackstone).

### 2. Công thức bàn chế tạo:
- Hàng 2: Đặt **1 Que quỷ lửa** ở ô chính giữa.
- Hàng 3: Đặt **3 viên Đá cuội** nằm ngang ở hàng dưới cùng.

### 3. Quy trình pha thuốc cơ bản:
1. Cho **Bột quỷ lửa (Blaze Powder)** vào góc trên bên trái làm nhiên liệu đốt.
2. Đặt 3 chai nước vào 3 ô đáy.
3. Cho **Bướu địa ngục (Nether Wart)** vào ô đỉnh để tạo ra **Thuốc vụng về (Awkward Potion)** - nền tảng của hầu hết mọi loại thuốc hữu ích!`,
    keywords: ['minecraft', 'mc', 'gian pha thuoc', 'brewing stand', 'pha thuoc', 'blaze rod', 'nether wart', 'potion'],
    synonyms: ['che tao gian pha thuoc', 'lam ban pha thuoc', 'pha che thuoc mc', 'awkward potion'],
    sampleQuestions: [
      'Cách chế tạo giàn pha thuốc trong minecraft',
      'Làm bình pha thuốc trong MC như thế nào',
      'Công thức pha thuốc cơ bản minecraft',
      'Cần gì để làm brewing stand',
    ],
    source: 'Minecraft Official Wiki',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'mc-end-portal',
    category: 'minecraft',
    title: 'Cách tìm Pháo Đài Cổ và kích hoạt Cổng Kết Thúc (End Portal) trong Minecraft',
    content: `Để đến chiều không gian The End và tiêu diệt Rồng Ender Dragon:

### 1. Chuẩn bị Mắt Ender (Eye of Ender):
- Chế tạo bằng **Bột quỷ lửa (Blaze Powder)** + **Ngọc Ender (Ender Pearl)** (đánh bại Enderman).
- Cần chuẩn bị từ 15-20 Mắt Ender (vừa để định vị vừa để cắm vào khung cổng).

### 2. Định vị Pháo đài Stronghold:
- Cầm Mắt Ender nhấp chuột phải ném lên không trung. Mắt sẽ bay về hướng có Pháo đài Stronghold.
- Đi theo hướng mắt bay cho đến khi mắt bay chúc xuống lòng đất. Đào xuống bạn sẽ tìm thấy Thư viện và Căn phòng Cổng End!

### 3. Kích hoạt Cổng End:
- Khung cổng gồm 12 khối đá End Portal Frame xếp thành hình vuông 3x3 rỗng ở giữa.
- Đặt Mắt Ender vào tất cả các ô khung còn thiếu (thường cần thêm 10-12 mắt).
- Khi đủ 12 mắt, tâm cổng sẽ biến thành hố đen vũ trụ với những vì sao lấp lánh dẫn tới The End!

### 4. Mẹo diệt rồng Ender Dragon:
- Phá hủy các Tinh thể Ender (End Crystal) trên đỉnh các cột đá Obsidian trước.
- Đặt Giường ngủ và bấm chuột phải khi rồng đậu xuống bệ đá trung tâm (giường phát nổ cực mạnh trong The End giúp diệt rồng siêu nhanh)!`,
    keywords: ['minecraft', 'mc', 'cong end', 'end portal', 'ender dragon', 'stronghold', 'mat ender', 'eye of ender'],
    synonyms: ['tim cong the end', 'cach kich hoat cong end', 'tieu diet rong ender', 'phao dai stronghold mc'],
    sampleQuestions: [
      'Cách tìm và kích hoạt cổng End trong Minecraft',
      'Làm sao để đến The End giết rồng trong MC',
      'Cần bao nhiêu mắt ender để mở cổng End',
      'Mẹo giết rồng Ender Dragon nhanh bằng giường',
    ],
    source: 'Minecraft End Dimension Guide',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'mc-netherite-gear',
    category: 'minecraft',
    title: 'Cách tìm Mảnh Netherite và nâng cấp trang bị Netherite mạnh nhất Minecraft',
    content: `**Netherite** là kim loại quý giá nhất trong Minecraft, không bị cháy trong dung nham và có độ bền, sát thương vượt trội hơn cả Kim cương:

### 1. Khai thác Mảnh vụn cổ đại (Ancient Debris):
- Xuất hiện ở chiều không gian Nether, tập trung dày đặc nhất ở độ cao **Y = 15**.
- Dùng mẹo cho nổ Giường ngủ hoặc Thuốc nổ TNT ở Y=15 để bộc lộ Ancient Debris (vì khối này có khả năng chống nổ cực cao).
- Phải khai thác bằng **Cúp Kim Cương** trở lên!

### 2. Nung và chế tạo Thỏi Netherite (Netherite Ingot):
- Cho Ancient Debris vào lò nung để thu về **Mảnh vụn Netherite (Netherite Scrap)**.
- Đặt vào bàn chế tạo: **4 Netherite Scrap + 4 Thỏi vàng (Gold Ingot)** = **1 Thỏi Netherite**.

### 3. Nâng cấp trên Bàn Rèn (Smithing Table):
Từ bản Minecraft 1.20 trở lên, bạn cần 3 món:
1. **Phôi đúc nâng cấp Netherite (Netherite Upgrade Template)**: Tìm trong tàn tích Bastion Remnant.
2. **Trang bị Kim cương** cần nâng cấp (Kiếm, Cúp, Giáp...).
3. **1 Thỏi Netherite (Netherite Ingot)**.`,
    keywords: ['minecraft', 'mc', 'netherite', 'ancient debris', 'smithing table', 'giap netherite', 'kiem netherite'],
    synonyms: ['cach lam do netherite', 'tim ancient debris', 'nang cap trang bi netherite trong mc'],
    sampleQuestions: [
      'Cách nâng cấp đồ Netherite trong Minecraft',
      'Tìm Ancient Debris ở tầng bao nhiêu trong Nether',
      'Công thức chế tạo thỏi Netherite',
      'Làm sao để có giáp Netherite trong MC',
    ],
    source: 'Minecraft Nether Update Guide',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },

  // =========================================================================
  // 2. WINDOWS & MÁY TÍNH
  // =========================================================================
  {
    id: 'win-shortcuts-essential',
    category: 'windows',
    title: 'Top các phím tắt Windows 10/11 thiết yếu tăng 200% năng suất',
    content: `Dưới đây là các phím tắt quyền năng trên hệ điều hành Windows:

### 1. Thao tác hàng ngày:
- \`Win + Shift + S\`: Cắt và chụp ảnh màn hình vùng tùy chọn (Snipping Tool).
- \`Win + V\`: Mở **Lịch sử Clipboard** lưu trữ nhiều đoạn văn bản và hình ảnh đã sao chép trước đó.
- \`Ctrl + Shift + Esc\`: Mở trực tiếp **Task Manager** không qua màn hình trung gian.
- \`Win + D\`: Ẩn/hiện màn hình Desktop tức thì.
- \`Win + L\`: Khóa máy tính ngay lập tức khi rời khỏi bàn làm việc.

### 2. Quản lý cửa sổ & màn hình:
- \`Win + Mũi tên (Trái / Phải / Lên / Xuống)\`: Chia đôi hoặc chia tư cửa sổ làm việc trên màn hình (Snap Window).
- \`Win + Tab\`: Xem chế độ Task View và chuyển đổi các màn hình ảo (Virtual Desktops).
- \`Win + .\` (hoặc \`Win + ;\/\`): Mở bảng chọn biểu tượng cảm xúc Emoji, Kaomoji và ký tự toán học.`,
    keywords: ['windows', 'phim tat', 'shortcut', 'win shift s', 'win v', 'clipboard', 'task manager', 'pc'],
    synonyms: ['phim tat windows 11', 'phim tat windows 10', 'phim tat may tinh', 'chup man hinh windows', 'copy history'],
    sampleQuestions: [
      'Các phím tắt Windows hữu ích',
      'Cách mở lịch sử copy trên máy tính',
      'Phím tắt chụp màn hình trên máy tính',
      'Phím tắt mở Task Manager nhanh',
    ],
    source: 'Microsoft Windows Documentation',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'win-clean-disk-c',
    category: 'windows',
    title: 'Cách dọn dẹp dung lượng ổ đĩa C bị đầy trên máy tính Windows',
    content: `Khi ổ đĩa hệ thống (ổ C:) báo đỏ do đầy dung lượng, bạn hãy áp dụng các bước an toàn sau:

### 1. Xóa các tệp tạm thời (Temp Files):
- Nhấn tổ hợp \`Win + R\`, gõ \`temp\` rồi nhấn Enter -> Xóa toàn bộ file trong thư mục này.
- Nhấn lại \`Win + R\`, gõ \`%temp%\` rồi nhấn Enter -> Chọn tất cả (Ctrl + A) và nhấn Shift + Delete để xóa sạch.

### 2. Sử dụng công cụ Disk Cleanup của Windows:
- Mở menu Start, tìm kiếm **Disk Cleanup** -> Chọn ổ đĩa C.
- Bấm vào nút **Clean up system files** (Dọn dẹp tệp hệ thống).
- Tích chọn mục *Windows Update Cleanup* (bản cập nhật cũ thường chiếm từ 5GB - 20GB), *Recycle Bin*, và *Temporary files* rồi bấm OK.

### 3. Bật tính năng Storage Sense:
- Vào **Settings** -> **System** -> **Storage**.
- Bật công tắc **Storage Sense** để Windows tự động dọn dẹp các tệp tin rác định kỳ!`,
    keywords: ['windows', 'don rac o c', 'o c bi day', 'disk cleanup', 'temp', 'storage sense', 'giai phong dung luong'],
    synonyms: ['xoa file tam', 'don dep may tinh', 'may tinh bi day bo nho', 'tang dung luong o c'],
    sampleQuestions: [
      'Làm thế nào để dọn rác ổ C bị đầy',
      'Cách giải phóng dung lượng ổ C trên Windows',
      'Xóa file temp trong máy tính như thế nào',
      'Ổ C bị đỏ đầy bộ nhớ phải làm sao',
    ],
    source: 'Microsoft Support & Diagnostics',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'win-bsod-troubleshoot',
    category: 'windows',
    title: 'Cách khắc phục lỗi Màn hình xanh chết chóc (BSOD) trên Windows',
    content: `Lỗi **Màn hình xanh chết chóc (Blue Screen of Death - BSOD)** xảy ra khi hệ điều hành Windows gặp sự cố nghiêm trọng về phần cứng hoặc xung đột Driver:

### 1. Chạy lệnh sửa chữa tập tin hệ thống (SFC & DISM):
1. Mở Start Menu, gõ \`cmd\`, nhấp chuột phải chọn **Run as administrator**.
2. Nhập lệnh sau và nhấn Enter:
\`\`\`bash
sfc /scannow
\`\`\`
Hệ thống sẽ quét và tự động sửa các file Windows bị hỏng.
3. Tiếp tục chạy lệnh khôi phục hình ảnh hệ thống:
\`\`\`bash
DISM /Online /Cleanup-Image /RestoreHealth
\`\`\`

### 2. Cập nhật hoặc Rollback Driver Card đồ họa (GPU):
- Hơn $70\\%$ lỗi BSOD (mã như \`VIDEO_TDR_FAILURE\` hay \`DPC_WATCHDOG_VIOLATION\`) xuất phát từ driver GPU bị xung đột. Hãy vào trang chủ NVIDIA/AMD/Intel để cài bản driver mới nhất hoặc sạch nhất (Clean Install).

### 3. Kiểm tra lỗi bộ nhớ RAM:
- Nhấn \`Win + R\`, gõ \`mdsched.exe\` -> Chọn **Restart now and check for problems** để máy quét lỗi thanh RAM.`,
    keywords: ['windows', 'bsod', 'man hinh xanh', 'sfc scannow', 'dism', 'driver', 'video tdr failure', 'loi may tinh'],
    synonyms: ['khac phuc man hinh xanh', 'sua loi bsod', 'may tinh bi dump xanh', 'chua man hinh xanh windows'],
    sampleQuestions: [
      'Cách sửa lỗi màn hình xanh trên Windows',
      'Lệnh sfc scannow dùng để làm gì',
      'Máy tính bị màn hình xanh BSOD phải làm sao',
      'Tại sao máy tính bị màn hình xanh khởi động lại',
    ],
    source: 'Microsoft Windows Troubleshooting Guide',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'win-disable-startup-apps',
    category: 'windows',
    title: 'Cách tắt ứng dụng khởi động cùng Windows giúp máy tính mở siêu nhanh',
    content: `Nhiều ứng dụng (như Discord, Spotify, Steam, trình duyệt) tự động khởi động cùng Windows khiến thời gian boot máy bị chậm chạp:

### 1. Cách tắt qua Task Manager:
1. Nhấn tổ hợp phím \`Ctrl + Shift + Esc\` để mở **Task Manager**.
2. Chọn tab **Startup apps** (biểu tượng đồng hồ tốc độ).
3. Xem cột **Startup impact** (Tác động khởi động: High, Medium, Low).
4. Nhấp chuột phải vào những ứng dụng có tác động *High* không cần thiết (vd: Spotify, Epic Games, uTorrent) và chọn **Disable (Vô hiệu hóa)**.

### 2. Cách tắt qua Settings:
1. Nhấn \`Win + I\` để mở Cài đặt (Settings).
2. Chọn **Apps** -> **Startup**.
3. Gạt nút sang trạng thái **Off** cho các ứng dụng bạn không muốn tự bật lúc mở máy!

*(Lưu ý: Không tắt các tiến trình âm thanh Realtek Audio, Windows Security Antivirus nhé!)*`,
    keywords: ['windows', 'khoi dong nhanh', 'startup apps', 'task manager', 'tat ung dung khoi dong', 'may tinh cham'],
    synonyms: ['tang toc khoi dong windows', 'tat chuong trinh chay ngam khi bat may', 'startup impact'],
    sampleQuestions: [
      'Cách tắt ứng dụng khởi động cùng máy tính',
      'Làm thế nào để máy tính khởi động nhanh hơn',
      'Tắt ứng dụng chạy ngầm lúc bật máy trong Task Manager',
      'Cách quản lý startup apps trên Windows 10 và 11',
    ],
    source: 'Microsoft Windows Performance Optimization',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },

  // =========================================================================
  // 3. MÁY TÍNH (PHẦN CỨNG & MẠNG)
  // =========================================================================
  {
    id: 'comp-hardware-specs',
    category: 'computer',
    title: 'Cách kiểm tra cấu hình phần cứng máy tính (CPU, RAM, Card màn hình)',
    content: `Để kiểm tra thông số chi tiết phần cứng máy tính đang dùng:

### Cách 1: Sử dụng DirectX Diagnostic Tool (dxdiag) - Nhanh & Chi tiết nhất:
1. Nhấn tổ hợp phím \`Win + R\`.
2. Gõ chữ \`dxdiag\` rồi nhấn Enter.
3. Tab **System**: Xem tên máy, Chip xử lý CPU, Dung lượng RAM, Phiên bản BIOS.
4. Tab **Display**: Xem mã Card màn hình (GPU rời / onboard) và dung lượng VRAM.

### Cách 2: Xem trong Task Manager:
1. Nhấn \`Ctrl + Shift + Esc\` để mở Task Manager.
2. Bấm sang tab **Performance (Hiệu năng)**: Xem mức tiêu thụ thời gian thực của CPU, RAM, Ổ đĩa SSD/HDD, Card đồ họa GPU và tốc độ mạng Wi-Fi/Ethernet.`,
    keywords: ['may tinh', 'cau hinh may tinh', 'dxdiag', 'cpu', 'ram', 'gpu', 'card man hinh', 'hardware'],
    synonyms: ['xem ram may tinh', 'kiem tra thong so pc', 'check cau hinh may tinh', 'xem card do hoa'],
    sampleQuestions: [
      'Cách kiểm tra cấu hình máy tính',
      'Xem máy tính có bao nhiêu RAM bằng cách nào',
      'Kiểm tra card màn hình máy tính',
      'Lệnh dxdiag xem thông tin máy tính',
    ],
    source: 'Hardware Diagnostics Standard',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'comp-ram-dual-channel',
    category: 'computer',
    title: 'Khái niệm RAM Dual Channel và cách cắm RAM đúng khe tối ưu hiệu năng',
    content: `**Dual Channel (Kênh đôi)** là công nghệ cho phép CPU giao tiếp với bộ nhớ RAM qua hai kênh độc lập $64\\text{-bit}$ đồng thời, nhân đôi băng thông truyền tải dữ liệu lên $128\\text{-bit}$:

### 1. Lợi ích của Dual Channel:
- Tăng FPS khi chơi game từ $15\\% - 30\\%$, đặc biệt rõ rệt với card đồ họa tích hợp iGPU (như AMD Radeon Vega hay Intel Iris Xe).
- Giảm thiểu hiện tượng giật khung hình (Stuttering/1% low FPS).

### 2. Quy tắc cắm 2 thanh RAM trên bo mạch chủ 4 khe:
- Bo mạch chủ thường đánh dấu các khe: DIMM A1, A2, B1, B2 (hoặc 1, 2, 3, 4 tính từ CPU sang phải).
- **Vị trí chuẩn vàng**: Hãy cắm vào **khe 2 và khe 4** (DIMM A2 và B2).
- Cắm xen kẽ cách nhau 1 khe như vậy bo mạch mới kích hoạt được chế độ Dual Channel!

### 3. Kiểm tra máy đã chạy Dual Channel chưa:
- Tải phần mềm miễn phí **CPU-Z** -> Xem tab **Memory** -> Mục **Channel #** hiển thị chữ "Dual" là đã thành công!`,
    keywords: ['computer', 'may tinh', 'ram', 'dual channel', 'khe ram', 'cpu z', 'bang thong ram', 'a2 b2'],
    synonyms: ['ram kenh doi la gi', 'cach cam ram dung khe', 'tai sao nen chay dual channel ram', 'cam ram 2 va 4'],
    sampleQuestions: [
      'RAM Dual Channel là gì',
      'Cách cắm RAM chạy Dual Channel đúng cách',
      'Nên cắm 2 thanh RAM vào khe nào trên mainboard',
      'Tại sao nên dùng 2 thanh 8GB thay vì 1 thanh 16GB',
    ],
    source: 'PC Hardware Architecture Standards',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'comp-ssd-vs-hdd',
    category: 'computer',
    title: 'So sánh ổ cứng SSD NVMe PCIe, SSD SATA và ổ HDD truyền thống',
    content: `Sự khác biệt giữa các chuẩn ổ cứng lưu trữ hiện nay:

### 1. Ổ cứng HDD cơ truyền thống:
- Cơ chế: Đĩa từ quay bằng mô-tơ cơ học ($5400$ hoặc $7200$ vòng/phút).
- Tốc độ đọc/ghi: Khoảng **$100 - 180$ MB/s**.
- Ưu điểm: Giá thành trên mỗi GB cực rẻ, phù hợp lưu trữ dữ liệu dung lượng lớn (phim, ảnh lưu trữ lâu năm).
- Nhược điểm: Tốc độ chậm, dễ sốc vật lý hỏng đĩa khi va đập.

### 2. Ổ SSD SATA III (2.5 inch hoặc M.2 SATA):
- Tốc độ đọc/ghi: Tối đa khoảng **$550$ MB/s** (bị giới hạn bởi băng thông cổng SATA 3).
- Nhanh gấp 4 lần HDD, khởi động Windows chỉ mất 10-15 giây.

### 3. Ổ SSD M.2 NVMe (Giao thức PCIe):
- Chạy trực tiếp qua các làn PCIe của CPU/Chipset.
- Tốc độ: **$3500$ MB/s** (PCIe Gen 3) đến **$7500$ MB/s** (PCIe Gen 4) và hơn **$12000$ MB/s** (PCIe Gen 5)!
- Mở game nặng tức thì, render video 4K siêu mượt mà không lo bị nghẽn cổ chai.`,
    keywords: ['may tinh', 'ssd', 'hdd', 'nvme', 'sata', 'pcie', 'toc do o cung', 'o cung'],
    synonyms: ['so sanh ssd va hdd', 'ssd nvme khac gi ssd sata', 'o cung nao nhanh nhat'],
    sampleQuestions: [
      'Phân biệt ổ cứng SSD và HDD',
      'SSD NVMe khác gì SSD SATA',
      'Nên mua ổ cứng SSD nào cho máy tính',
      'Tốc độ đọc ghi của SSD là bao nhiêu',
    ],
    source: 'Storage Technology Standards Association',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'comp-fix-wifi-dns',
    category: 'computer',
    title: 'Cách sửa lỗi máy tính mất kết nối mạng Wi-Fi và đổi DNS 1.1.1.1 / 8.8.8.8',
    content: `Khi máy tính báo lỗi mạng chấm than vàng hoặc "No Internet, Secured":

### 1. Làm mới địa chỉ IP và xóa bộ nhớ đệm DNS bằng Command Prompt:
1. Mở \`cmd\` với quyền Administrator.
2. Gõ tuần tự 3 lệnh sau (nhấn Enter sau mỗi lệnh):
\`\`\`bash
ipconfig /flushdns
ipconfig /release
ipconfig /renew
\`\`\`
Lệnh này xóa sạch cache phân giải tên miền bị nghẽn và xin cấp lại IP mới từ Router.

### 2. Đổi sang DNS nhanh và ổn định:
- **Cloudflare DNS**: \`1.1.1.1\` (Phụ: \`1.0.0.1\`) -> Độ trễ thấp nhất thế giới, bảo mật cao.
- **Google DNS**: \`8.8.8.8\` (Phụ: \`8.8.4.4\`) -> Ổn định và tương thích cao.

### Cách đổi:
1. Nhấn \`Win + R\`, gõ \`ncpa.cpl\` -> Nhấn Enter.
2. Nhấp chuột phải vào card mạng Wi-Fi/Ethernet -> Chọn **Properties**.
3. Nhấp đúp vào **Internet Protocol Version 4 (TCP/IPv4)**.
4. Tích chọn *Use the following DNS server addresses* và nhập \`1.1.1.1\` và \`1.0.0.1\`.`,
    keywords: ['may tinh', 'wifi', 'mat mang', 'doi dns', 'flushdns', '1.1.1.1', '8.8.8.8', 'ipconfig'],
    synonyms: ['sua loi mat ket noi internet', 'cach doi dns google', 'lenh flushdns', 'no internet secured'],
    sampleQuestions: [
      'Cách sửa lỗi máy tính bị mất mạng wifi',
      'Lệnh ipconfig flushdns dùng để làm gì',
      'Cách đổi DNS 1.1.1.1 hoặc 8.8.8.8 trên Windows',
      'Máy tính báo No Internet Secured phải làm sao',
    ],
    source: 'Network Protocols & Troubleshooting',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },

  // =========================================================================
  // 4. HTML
  // =========================================================================
  {
    id: 'html-semantic-tags',
    category: 'html',
    title: 'Các thẻ ngữ nghĩa HTML5 (Semantic Tags) và lý do nên dùng',
    content: `**Semantic HTML** là việc sử dụng các thẻ HTML có ý nghĩa rõ ràng phản ánh cấu trúc nội dung, thay vì lạm dụng toàn bộ bằng thẻ \`<div>\`:

### Các thẻ ngữ nghĩa phổ biến nhất:
- \`<header>\`: Phần đầu trang hoặc đầu một bài viết (chứa logo, tiêu đề).
- \`<nav>\`: Khu vực chứa các liên kết điều hướng (menu navigation).
- \`<main>\`: Nội dung chính yếu, độc nhất của trang web (mỗi trang chỉ có 1 thẻ main).
- \`<section>\`: Một phân đoạn nội dung theo chủ đề cụ thể.
- \`<article>\`: Một khối bài viết hoàn chỉnh, có thể đứng độc lập (tin tức, blog post, bình luận).
- \`<aside>\`: Thanh bên lề, chứa thông tin phụ trợ (sidebar, quảng cáo, mục lục).
- \`<footer>\`: Phần chân trang (chứa bản quyền, liên hệ, chính sách).

### Tại sao bắt buộc phải dùng Semantic Tags?
1. **Chuẩn SEO hàng đầu**: Công cụ tìm kiếm như Google hiểu chính xác đâu là nội dung cốt lõi để xếp hạng cao hơn.
2. **Hỗ trợ người khuyết tật (Accessibility - a11y)**: Trình đọc màn hình (Screen Reader) điều hướng dễ dàng.
3. **Mã nguồn sạch & dễ bảo trì**: Đồng nghiệp đọc code hiểu ngay cấu trúc layout.`,
    keywords: ['html', 'semantic', 'the ngu nghia', 'header', 'nav', 'main', 'section', 'article', 'footer', 'seo'],
    synonyms: ['semantic tags html5', 'the ngu nghia html la gi', 'tai sao nen dung the semantic'],
    sampleQuestions: [
      'Các thẻ ngữ nghĩa trong HTML5 là gì',
      'Phân biệt section và article trong HTML',
      'Tại sao không nên dùng toàn bộ thẻ div trong HTML',
      'Các thẻ Semantic HTML quan trọng nhất',
    ],
    source: 'W3C HTML5 Semantic Specification',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'html-meta-seo',
    category: 'html',
    title: 'Cấu trúc thẻ <meta> chuẩn SEO và hiển thị chia sẻ mạng xã hội OpenGraph',
    content: `Trong phần thẻ \`<head>\` của trang web HTML, các thẻ \`<meta>\` đóng vai trò quyết định cách website hiển thị trên Google và Facebook/Zalo:

### 1. Thẻ meta cơ bản:
\`\`\`html
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Tiêu đề trang (dưới 60 ký tự)</title>
<meta name="description" content="Đoạn tóm tắt nội dung trang web hiển thị trên kết quả tìm kiếm Google (120-160 ký tự)." />
\`\`\`

### 2. Thẻ OpenGraph (Hiển thị thẻ xem trước khi share link lên Facebook, Zalo, Twitter):
\`\`\`html
<meta property="og:title" content="Tiêu đề bài viết hấp dẫn" />
<meta property="og:description" content="Mô tả tóm tắt ngắn gọn thu hút người bấm" />
<meta property="og:image" content="https://example.com/banner-1200x630.jpg" />
<meta property="og:type" content="website" />
\`\`\`
*(Kích thước ảnh đại diện OpenGraph chuẩn nhất là $1200 \\times 630$ pixel).*`,
    keywords: ['html', 'meta', 'seo', 'opengraph', 'viewport', 'head', 'tieu de trang'],
    synonyms: ['the meta trong html', 'the meta seo', 'cach tao the share facebook open graph'],
    sampleQuestions: [
      'Các thẻ meta quan trọng trong HTML',
      'Thẻ OpenGraph trong HTML dùng để làm gì',
      'Cách cấu hình thẻ meta chuẩn SEO cho website',
      'Thẻ meta viewport có ý nghĩa gì',
    ],
    source: 'Open Graph Protocol & Google Search Central',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },

  // =========================================================================
  // 5. CSS
  // =========================================================================
  {
    id: 'css-center-div',
    category: 'css',
    title: 'Các cách căn giữa một thẻ div bằng CSS hiện đại (Flexbox & Grid)',
    content: `Căn giữa một phần tử con cả theo chiều ngang lẫn chiều dọc là bài toán kinh điển trong lập trình Web:

### Cách 1: Dùng CSS Flexbox (Phổ biến và linh hoạt nhất)
Áp dụng trên thẻ cha (container):
\`\`\`css
.parent {
  display: flex;
  justify-content: center; /* Căn giữa theo trục chính (ngang) */
  align-items: center;     /* Căn giữa theo trục phụ (dọc) */
  min-height: 100vh;
}
\`\`\`

### Cách 2: Dùng CSS Grid (Gọn gàng nhất - Chỉ 2 dòng)
Áp dụng trên thẻ cha (container):
\`\`\`css
.parent {
  display: grid;
  place-items: center; /* Tự động căn giữa cả ngang và dọc */
  min-height: 100vh;
}
\`\`\`

### Cách 3: Dùng Position Absolute (Áp dụng khi phần tử nổi)
\`\`\`css
.child {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
\`\`\``,
    keywords: ['css', 'can giua div', 'center div', 'flexbox', 'grid', 'justify center', 'align items', 'place items'],
    synonyms: ['can giua the div', 'can giua noi dung trong css', 'cach can giua phan tu', 'center flexbox'],
    sampleQuestions: [
      'Căn giữa một thẻ div trong CSS như thế nào',
      'Cách center div bằng flexbox',
      'Dùng css grid để căn giữa phần tử',
      'Làm sao để đưa chữ ra chính giữa màn hình bằng css',
    ],
    source: 'MDN Web Docs - Centering in CSS',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'css-box-model',
    category: 'css',
    title: 'Khái niệm CSS Box Model và thuộc tính box-sizing: border-box',
    content: `**CSS Box Model** là mô hình nền tảng quy định cách trình duyệt tính toán kích thước hiển thị của mọi phần tử HTML:

### 1. Bốn lớp của một Box (từ trong ra ngoài):
1. **Content**: Vùng chứa văn bản, hình ảnh thực tế.
2. **Padding**: Khoảng cách đệm từ nội dung đến viền (trong suốt).
3. **Border**: Đường viền bao quanh nội dung và phần padding.
4. **Margin**: Khoảng cách lề từ viền này đến các phần tử lân cận bên ngoài.

### 2. Thuộc tính quan trọng \`box-sizing: border-box\`:
- Mặc định (\`content-box\`): Chiều rộng \`width\` chỉ tính vùng Content. Nếu thêm padding hoặc border, thẻ sẽ bị nở to ra ngoài!
- Chuẩn hiện đại (\`border-box\`): Chiều rộng \`width\` đã bao gồm cả Content + Padding + Border, giúp kích thước không bị xô lệch layout:
\`\`\`css
* {
  box-sizing: border-box;
}
\`\`\``,
    keywords: ['css', 'box model', 'margin', 'padding', 'border', 'box sizing', 'border box'],
    synonyms: ['mo hinh hop css', 'khai niem box model', 'padding va margin khac nhau the nao'],
    sampleQuestions: [
      'CSS Box Model là gì',
      'Phân biệt margin và padding trong CSS',
      'Tại sao nên dùng box-sizing: border-box',
      'Mô hình hộp trong CSS gồm những gì',
    ],
    source: 'W3C & MDN Web Docs',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'css-flexbox-vs-grid',
    category: 'css',
    title: 'So sánh CSS Flexbox và CSS Grid: Khi nào nên sử dụng cái nào?',
    content: `Hai công cụ bố cục (Layout) quyền năng nhất của CSS hiện đại:

### 1. CSS Flexbox - Bố cục một chiều (One-Dimensional):
- Được thiết kế để sắp xếp các phần tử theo **MỘT chiều duy nhất**: hoặc theo hàng ngang (\`flex-direction: row\`) hoặc theo cột dọc (\`flex-direction: column\`).
- **Thích hợp nhất cho**:
  - Thanh menu điều hướng (Navbar).
  - Căn giữa một hoặc vài phần tử.
  - Phân bổ khoảng cách đều giữa các nút bấm (\`justify-content: space-between\`).

### 2. CSS Grid - Bố cục hai chiều (Two-Dimensional):
- Được thiết kế để làm việc với cả **HÀNG và CỘT cùng một lúc**.
- **Thích hợp nhất cho**:
  - Bố cục tổng thể của toàn bộ trang web (Header, Sidebar, Content, Footer).
  - Lưới danh sách sản phẩm hoặc thư viện ảnh (\`grid-template-columns: repeat(auto-fit, minmax(250px, 1fr))\`).
  - Giao diện Dashboard phức tạp có các ô kích thước khác nhau.`,
    keywords: ['css', 'flexbox', 'grid', 'css grid', 'so sanh flexbox va grid', 'layout'],
    synonyms: ['khi nao nen dung flexbox', 'khi nao nen dung grid', 'phan biet flexbox va grid'],
    sampleQuestions: [
      'Phân biệt CSS Flexbox và CSS Grid',
      'Khi nào nên dùng CSS Grid thay cho Flexbox',
      'So sánh flexbox và grid trong css',
      'Nên chọn flexbox hay grid để làm layout',
    ],
    source: 'CSS Tricks & MDN Web Docs',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },

  // =========================================================================
  // 6. JAVASCRIPT
  // =========================================================================
  {
    id: 'js-closure-concept',
    category: 'javascript',
    title: 'Khái niệm Closure trong JavaScript và ví dụ thực tế',
    content: `**Closure** là một trong những đặc tính cốt lõi và mạnh mẽ nhất của ngôn ngữ JavaScript:

### 1. Định nghĩa:
Closure là khả năng một hàm bên trong **ghi nhớ và truy cập được các biến ở phạm vi bên ngoài (Lexical Scope)** ngay cả khi hàm bên ngoài đó đã thực thi xong và kết thúc khỏi call stack!

### 2. Ví dụ kinh điển: Bộ đếm (Counter với biến Private)
\`\`\`javascript
function createCounter() {
  let count = 0; // Biến private, bên ngoài không thể can thiệp trực tiếp

  return {
    increment: function() {
      count++;
      return count;
    },
    getCount: function() {
      return count;
    }
  };
}

const counter = createCounter();
console.log(counter.increment()); // In ra: 1
console.log(counter.increment()); // In ra: 2
console.log(counter.count);       // In ra: undefined (Bảo mật tuyệt đối!)
\`\`\`

### 3. Ứng dụng thực tế:
- Tạo biến riêng tư (Data Privacy).
- Tạo các hàm tùy biến (Currying & Function Factories).
- Sử dụng trong React Hooks (như \`useState\`).`,
    keywords: ['javascript', 'closure', 'scope', 'lexical scope', 'bien private', 'ham con', 'js'],
    synonyms: ['khai niem closure trong js', 'vi du closure javascript', 'closure la gi'],
    sampleQuestions: [
      'Closure trong JavaScript là gì',
      'Giải thích khái niệm closure trong JS',
      'Cho ví dụ về closure trong javascript',
      'Closure hoạt động như thế nào',
    ],
    source: 'MDN Web Docs - JavaScript Closures',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'js-async-await-promise',
    category: 'javascript',
    title: 'Phân biệt Promise và Async/Await trong JavaScript',
    content: `Trong lập trình bất đồng bộ JavaScript (gọi API, đọc file, hẹn giờ):

### 1. Promise:
Là đối tượng đại diện cho một tác vụ bất đồng bộ với 3 trạng thái: \`pending\`, \`fulfilled\` (thành công), và \`rejected\` (thất bại).
\`\`\`javascript
fetchData()
  .then((data) => processData(data))
  .catch((error) => console.error(error));
\`\`\`

### 2. Async / Await:
Là cú pháp "đường cú pháp" (Syntactic Sugar) được xây dựng trên nền tảng Promise, giúp code bất đồng bộ trông giống như code đồng bộ tuần tự, dễ đọc và dễ gỡ lỗi hơn:
\`\`\`javascript
async function loadData() {
  try {
    const data = await fetchData();
    const result = await processData(data);
    return result;
  } catch (error) {
    console.error('Xảy ra lỗi:', error);
  }
}
\`\`\`

### Lợi ích của Async/Await:
- Tránh hiện tượng "Callback Hell" hay chuỗi \`.then()\` lồng nhau phức tạp.
- Sử dụng cấu trúc bắt lỗi quen thuộc \`try...catch\`.`,
    keywords: ['javascript', 'promise', 'async await', 'bat dong bo', 'then catch', 'api call', 'js'],
    synonyms: ['lap trinh bat dong bo js', 'so sanh promise va async await', 'cach dung async await'],
    sampleQuestions: [
      'Phân biệt Promise và Async Await trong JS',
      'Async await là gì trong javascript',
      'Cách xử lý bất đồng bộ trong javascript',
      'Tại sao nên dùng async await thay cho promise',
    ],
    source: 'ECMAScript Modern Specifications',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'js-event-loop',
    category: 'javascript',
    title: 'Cơ chế hoạt động của Event Loop trong JavaScript',
    content: `JavaScript là ngôn ngữ **đơn luồng (Single-Threaded)**, nhưng có thể xử lý các tác vụ bất đồng bộ non-blocking nhờ vào cơ chế **Event Loop**:

### Các thành phần chính:
1. **Call Stack**: Nơi thực thi các dòng lệnh đồng bộ theo thứ tự LIFO (Last In First Out).
2. **Web APIs**: Các tác vụ như \`setTimeout\`, \`fetch\`, DOM Events được đẩy sang môi trường trình duyệt xử lý ngầm.
3. **Microtask Queue**: Hàng đợi ưu tiên cao nhất, chứa các Callback của **Promise** (\`.then\`, \`.catch\`, \`async/await\`) và \`queueMicrotask\`.
4. **Macrotask Queue (Callback Queue)**: Chứa các Callback của \`setTimeout\`, \`setInterval\`, I/O.

### Thứ tự thực thi của Event Loop:
1. Thực thi hết toàn bộ code đồng bộ trong **Call Stack**.
2. Khi Call Stack rỗng, Event Loop sẽ kiểm tra và thực thi **TOÀN BỘ** các tác vụ trong **Microtask Queue** (Promise luôn chạy trước!).
3. Lấy tiếp **MỘT tác vụ** từ **Macrotask Queue** đưa vào Call Stack để chạy.
4. Lặp lại chu kỳ không ngừng nghỉ!`,
    keywords: ['javascript', 'event loop', 'call stack', 'microtask', 'macrotask', 'callback queue', 'single threaded'],
    synonyms: ['co che event loop trong js', 'tai sao js don luong lai bat dong bo', 'thu tu chay event loop'],
    sampleQuestions: [
      'Event Loop trong JavaScript hoạt động như thế nào',
      'Phân biệt Microtask và Macrotask trong JS',
      'Tại sao Promise lại chạy trước setTimeout trong JavaScript',
      'Giải thích cơ chế Event Loop',
    ],
    source: 'JavaScript Runtime Architecture Standards',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'js-array-methods',
    category: 'javascript',
    title: 'Bốn phương thức xử lý mảng thiết yếu trong JavaScript: map, filter, reduce, find',
    content: `Bốn hàm xử lý mảng (Array Methods) theo phong cách Lập trình Hàm (Functional Programming) bất biến trong JavaScript:

### 1. \`map()\`: Biến đổi từng phần tử thành phần tử mới (trả về mảng mới cùng độ dài):
\`\`\`javascript
const numbers = [1, 2, 3];
const doubled = numbers.map(x => x * 2); // [2, 4, 6]
\`\`\`

### 2. \`filter()\`: Lọc các phần tử thỏa mãn điều kiện logic:
\`\`\`javascript
const scores = [45, 80, 92, 30];
const passed = scores.filter(score => score >= 50); // [80, 92]
\`\`\`

### 3. \`find()\`: Tìm phần tử ĐẦU TIÊN thỏa mãn điều kiện (trả về giá trị hoặc undefined):
\`\`\`javascript
const users = [{ id: 1, name: 'Aoi' }, { id: 2, name: 'Ren' }];
const user = users.find(u => u.id === 2); // { id: 2, name: 'Ren' }
\`\`\`

### 4. \`reduce()\`: Tích lũy toàn bộ mảng thành một giá trị duy nhất (tính tổng, đếm số lần xuất hiện):
\`\`\`javascript
const prices = [10, 20, 30];
const total = prices.reduce((sum, p) => sum + p, 0); // 60
\`\`\``,
    keywords: ['javascript', 'array', 'map', 'filter', 'reduce', 'find', 'ham mang', 'js'],
    synonyms: ['cac ham xu ly mang trong js', 'cach dung map va filter', 'phuong thuc mang javascript'],
    sampleQuestions: [
      'Các phương thức mảng phổ biến trong JavaScript',
      'Cách sử dụng hàm reduce trong JavaScript',
      'Phân biệt map và filter trong JS',
      'Ví dụ về map filter reduce',
    ],
    source: 'MDN Web Docs - Array Methods',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },

  // =========================================================================
  // 7. LẬP TRÌNH (GIT, REST API & OOP)
  // =========================================================================
  {
    id: 'prog-git-commands',
    category: 'programming',
    title: 'Tổng hợp các lệnh Git thiết yếu cho lập trình viên',
    content: `Git là hệ thống quản lý phiên bản mã nguồn phân tán phổ biến nhất thế giới:

### Các lệnh làm việc cơ bản:
- \`git init\`: Khởi tạo một kho lưu trữ Git mới trong thư mục hiện tại.
- \`git status\`: Kiểm tra trạng thái các tệp đã sửa đổi, thêm mới hoặc chưa được theo dõi.
- \`git add .\`: Thêm toàn bộ các thay đổi vào khu vực Staging Area.
- \`git commit -m "Mô tả thay đổi"\`: Lưu lại một phiên bản snapshot cùng ghi chú.
- \`git log --oneline\`: Xem lại lịch sử các commit ngắn gọn.

### Làm việc với nhánh (Branch):
- \`git branch <ten-nhanh>\`: Tạo một nhánh làm việc mới.
- \`git checkout -b <ten-nhanh>\`: Vừa tạo nhánh vừa chuyển sang nhánh đó.
- \`git merge <ten-nhanh>\`: Gộp mã nguồn từ nhánh chỉ định vào nhánh hiện tại.

### Làm việc với kho từ xa (GitHub/GitLab):
- \`git push -u origin main\`: Đẩy mã nguồn lên máy chủ nhánh main.
- \`git pull\`: Kéo các thay đổi mới nhất từ kho từ xa về máy tính.`,
    keywords: ['git', 'github', 'commit', 'branch', 'push', 'pull', 'merge', 'lap trinh'],
    synonyms: ['lenh git co ban', 'cac lenh git thong dung', 'huong dan git cho nguoi moi', 'git workflow'],
    sampleQuestions: [
      'Các lệnh Git cơ bản là gì',
      'Cách commit và push code lên GitHub',
      'Lệnh tạo nhánh mới trong Git',
      'Quy trình làm việc với Git',
    ],
    source: 'Pro Git Book by Scott Chacon',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'prog-restful-api',
    category: 'programming',
    title: 'Khái niệm RESTful API và các mã trạng thái HTTP Status Code',
    content: `**RESTful API (Representational State Transfer)** là kiến trúc tiêu chuẩn để các ứng dụng Front-end và Back-end trao đổi dữ liệu qua giao thức HTTP:

### 1. Các phương thức HTTP (HTTP Methods) chính:
- **GET**: Lấy dữ liệu từ máy chủ (không làm thay đổi tài nguyên).
- **POST**: Tạo mới một tài nguyên (gửi dữ liệu trong Body).
- **PUT**: Cập nhật toàn bộ tài nguyên hiện có.
- **PATCH**: Cập nhật một phần thuộc tính của tài nguyên.
- **DELETE**: Xóa tài nguyên khỏi máy chủ.

### 2. Các mã trạng thái HTTP Status Code kinh điển:
- **2xx (Thành công)**:
  - \`200 OK\`: Yêu cầu thành công.
  - \`201 Created\`: Tài nguyên mới đã được tạo thành công.
- **4xx (Lỗi phía người dùng Client)**:
  - \`400 Bad Request\`: Dữ liệu gửi lên sai định dạng.
  - \`401 Unauthorized\`: Chưa đăng nhập hoặc Token xác thực không hợp lệ.
  - \`403 Forbidden\`: Đã đăng nhập nhưng không có quyền truy cập.
  - \`404 Not Found\`: Đường dẫn hoặc tài nguyên không tồn tại.
- **5xx (Lỗi phía máy chủ Server)**:
  - \`500 Internal Server Error\`: Lỗi sập server do logic code hoặc ngoại lệ chưa bắt.`,
    keywords: ['programming', 'restful api', 'http methods', 'status code', 'get post put delete', '404', '200', 'lap trinh'],
    synonyms: ['rest api la gi', 'cac ma loi http', 'phan biet get va post', 'http status code y nghia'],
    sampleQuestions: [
      'RESTful API là gì',
      'Ý nghĩa các mã trạng thái HTTP Status Code 200 404 500',
      'Phân biệt phương thức PUT và PATCH',
      'Khi nào trả về lỗi 401 và 403 trong API',
    ],
    source: 'Roy Fielding REST Dissertation & RFC HTTP Specs',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'prog-oop-principles',
    category: 'programming',
    title: 'Bốn tính chất cốt lõi của Lập trình Hướng đối tượng (OOP)',
    content: `**Lập trình Hướng đối tượng (OOP - Object-Oriented Programming)** xây dựng hệ thống phần mềm dựa trên các "Đối tượng" với 4 trụ cột chính:

### 1. Đóng gói (Encapsulation):
- Gom nhóm dữ liệu (thuộc tính) và các hàm thao tác trên dữ liệu (phương thức) vào một Lớp (Class).
- Che giấu trạng thái bên trong bằng các phạm vi truy cập: \`private\`, \`protected\`, \`public\`, chỉ cho phép tương tác qua các hàm getter/setter an toàn.

### 2. Kế thừa (Inheritance):
- Cho phép một lớp con tái sử dụng các thuộc tính và phương thức của một lớp cha mà không cần viết lại mã nguồn.
- Ví dụ: Lớp \`Dog\` kế thừa từ lớp \`Animal\`.

### 3. Đa hình (Polymorphism):
- Cho phép các đối tượng khác nhau thực thi cùng một tên hàm nhưng theo các hành vi riêng biệt.
- Ví dụ: Cùng gọi hàm \`makeSound()\`, nhưng \`Cat\` kêu "Meo meo" còn \`Dog\` sủa "Gâu gâu".

### 4. Trừu tượng (Abstraction):
- Ẩn đi các chi tiết triển khai phức tạp bên dưới, chỉ cung cấp giao diện tương tác đơn giản cho người sử dụng (thông qua \`Interface\` hoặc \`Abstract Class\`).`,
    keywords: ['programming', 'oop', 'huong doi tuong', 'dong goi', 'ke thua', 'da hinh', 'truu tuong', 'class'],
    synonyms: ['4 tinh chat oop', 'lap trinh huong doi tuong la gi', 'encapsulation inheritance polymorphism abstraction'],
    sampleQuestions: [
      'Bốn tính chất của lập trình hướng đối tượng OOP là gì',
      'Giải thích tính đóng gói và tính trừu tượng trong OOP',
      'Tính đa hình trong lập trình là gì',
      'OOP gồm những đặc điểm nào',
    ],
    source: 'Software Engineering Design Principles',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },

  // =========================================================================
  // 8. TOÁN HỌC
  // =========================================================================
  {
    id: 'math-pythagorean-theorem',
    category: 'math',
    title: 'Định lý Pytago (Pythagorean Theorem) trong tam giác vuông',
    content: `**Định lý Pytago** là một trong những định lý hình học nền tảng nhất:

### Phát biểu định lý:
Trong một tam giác vuông, bình phương độ dài cạnh huyền bằng tổng bình phương độ dài hai cạnh góc vuông.

### Công thức toán học:
$$a^2 + b^2 = c^2$$
- Trong đó:
  - $a, b$: Độ dài hai cạnh góc vuông.
  - $c$: Độ dài cạnh huyền (cạnh đối diện với góc vuông $90^\\circ$).

### Ví dụ tam giác Pytago kinh điển:
- Bộ ba số nguyên: **(3, 4, 5)**: vì $3^2 + 4^2 = 9 + 16 = 25 = 5^2$.
- Bộ ba số nguyên: **(5, 12, 13)**: vì $5^2 + 12^2 = 25 + 144 = 169 = 13^2$.`,
    keywords: ['toan hoc', 'dinh ly pytago', 'tam giac vuong', 'canh huyen', 'pythagorean', 'hinh hoc'],
    synonyms: ['dinh ly py-ta-go', 'cong thuc pytago', 'tinh canh huyen tam giac vuong'],
    sampleQuestions: [
      'Định lý Pytago là gì',
      'Công thức định lý Pytago',
      'Cách tính cạnh huyền tam giác vuông',
      'Cho ví dụ về định lý Pytago',
    ],
    source: 'Euclidean Geometry Standards',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'math-circle-pi',
    category: 'math',
    title: 'Công thức Chu vi, Diện tích Hình tròn và Ý nghĩa của số Pi (π)',
    content: `Hình tròn là hình học hoàn hảo với khoảng cách từ tâm đến mọi điểm trên đường tròn bằng bán kính $r$:

### 1. Công thức tính Chu vi hình tròn ($C$):
$$C = 2 \\pi r = \\pi d$$
- $r$: Bán kính hình tròn.
- $d = 2r$: Đường kính hình tròn.

### 2. Công thức tính Diện tích hình tròn ($S$):
$$S = \\pi r^2$$

### 3. Ý nghĩa kỳ diệu của số Pi ($\\pi$):
- $\\pi$ là tỷ số giữa chu vi của một hình tròn bất kỳ với đường kính của nó: $\\pi = \\frac{C}{d}$.
- Giá trị xấp xỉ thường dùng: $\\pi \\approx 3.14159265...$
- $\\pi$ là một số vô tỉ và số siêu việt, phần thập phân kéo dài vô tận không bao giờ lặp lại tuần hoàn! Ngày số Pi quốc tế được kỷ niệm vào ngày 14 tháng 3 hàng năm.`,
    keywords: ['toan hoc', 'hinh tron', 'chu vi hinh tron', 'dien tich hinh tron', 'so pi', 'pi', 'ban kinh'],
    synonyms: ['cong thuc tinh dien tich hinh tron', 'cong thuc tinh chu vi hinh tron', 'so pi la gi'],
    sampleQuestions: [
      'Công thức tính chu vi và diện tích hình tròn',
      'Diện tích hình tròn tính như thế nào',
      'Số Pi là gì và bằng bao nhiêu',
      'Tính diện tích hình tròn có bán kính r',
    ],
    source: 'Mathematical Constants & Geometry Standards',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'math-quadratic-formula',
    category: 'math',
    title: 'Cách giải Phương Trình Bậc Hai và Công thức Biệt thức Delta (Δ)',
    content: `Phương trình bậc hai một ẩn có dạng tổng quát:
$$ax^2 + bx + c = 0 \\quad (a \\neq 0)$$

### 1. Công thức tính biệt thức Delta ($\\Delta$):
$$\\Delta = b^2 - 4ac$$

### 2. Ba trường hợp nghiệm:
1. **Nếu $\\Delta > 0$**: Phương trình có **2 nghiệm phân biệt**:
   $$x_1 = \\frac{-b + \\sqrt{\\Delta}}{2a}, \\quad x_2 = \\frac{-b - \\sqrt{\\Delta}}{2a}$$
2. **Nếu $\\Delta = 0$**: Phương trình có **nghiệm kép**:
   $$x_1 = x_2 = \\frac{-b}{2a}$$
3. **Nếu $\\Delta < 0$**: Phương trình **vô nghiệm** trên tập số thực $\\mathbb{R}$ (hoặc có 2 nghiệm phức liên hợp).

### Ví dụ: Giải $x^2 - 5x + 6 = 0$:
- $a = 1, b = -5, c = 6$.
- $\\Delta = (-5)^2 - 4(1)(6) = 25 - 24 = 1 > 0$.
- Nghiệm: $x_1 = \\frac{5 + 1}{2} = 3$, $x_2 = \\frac{5 - 1}{2} = 2$.`,
    keywords: ['toan hoc', 'phuong trinh bac hai', 'delta', 'cong thuc nghiem', 'bac 2', 'tam thuc'],
    synonyms: ['cong thuc delta', 'giai phuong trinh bac 2', 'cach tinh delta phuong trinh bac hai'],
    sampleQuestions: [
      'Công thức giải phương trình bậc hai',
      'Cách tính biệt thức Delta',
      'Phương trình bậc 2 có mấy nghiệm',
      'Giải phương trình ax2 + bx + c = 0',
    ],
    source: 'Algebra Foundation Handbook',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },

  // =========================================================================
  // 9. KHOA HỌC
  // =========================================================================
  {
    id: 'sci-speed-of-light',
    category: 'science',
    title: 'Vận tốc ánh sáng trong chân không và ý nghĩa vật lý',
    content: `**Vận tốc ánh sáng trong chân không** (ký hiệu là $c$) là hằng số vật lý phổ quát quan trọng nhất trong vũ trụ:

### Giá trị chính xác:
$$c = 299.792.458 \\text{ m/s}$$
Xấp xỉ bằng **$300.000$ km/giây** (hoặc $1$ tỷ km/giờ).

### Những sự thật thú vị:
1. **Giới hạn tốc độ của vũ trụ**: Theo thuyết tương đối hẹp của Albert Einstein, không có bất kỳ vật chất hay thông tin nào có thể di chuyển nhanh hơn ánh sáng trong chân không.
2. **Khoảng cách Mặt Trời - Trái Đất**: Ánh sáng từ bề mặt Mặt Trời mất khoảng **8 phút 20 giây** để đi qua quãng đường $\\approx 150$ triệu km và chạm tới Trái Đất.
3. **Năm ánh sáng**: Là đơn vị đo khoảng cách thiên văn, tương đương quãng đường ánh sáng đi được trong 1 năm Julius (khoảng **$9.460$ tỷ km**).`,
    keywords: ['khoa hoc', 'van toc anh sang', 'toc do anh sang', 'toc do anh sang trong chan khong', 'einstein', 'vat ly', 'vu tru'],
    synonyms: ['anh sang di nhanh bao nhieu', 'hang so c vat ly', 'nam anh sang la gi'],
    sampleQuestions: [
      'Vận tốc ánh sáng là bao nhiêu',
      'Ánh sáng từ mặt trời đến trái đất mất bao lâu',
      'Tốc độ ánh sáng trong chân không',
      'Một năm ánh sáng bằng bao nhiêu km',
    ],
    source: 'CODATA Internationally Recommended Values',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'sci-solar-system',
    category: 'science',
    title: 'Thái Dương Hệ: Thứ tự 8 hành tinh từ gần đến xa Mặt Trời',
    content: `Hệ Mặt Trời (Solar System) của chúng ta có trung tâm là Mặt Trời cùng 8 hành tinh quay quanh theo quỹ đạo elip:

### Thứ tự 8 hành tinh tính từ Mặt Trời ra ngoài:
1. **Sao Thủy (Mercury)**: Hành tinh nhỏ nhất và ở gần Mặt Trời nhất, ban ngày bỏng rát $430^\\circ\\text{C}$, ban đêm hạ xuống $-180^\\circ\\text{C}$.
2. **Sao Kim (Venus)**: Hành tinh nóng nhất hệ Mặt Trời ($475^\\circ\\text{C}$) do hiệu ứng nhà kính cực mạnh từ bầu khí quyển dày đặc $\\text{CO}_2$.
3. **Trái Đất (Earth)**: Hành tinh duy nhất được biết đến có sự sống, $71\\%$ bề mặt bao phủ bởi nước lỏng.
4. **Sao Hỏa (Mars)**: "Hành tinh Đỏ" giàu oxide sắt, có núi lửa Olympus Mons cao nhất hệ mặt trời ($22$ km).
5. **Sao Mộc (Jupiter)**: Hành tinh khí khổng lồ lớn nhất hệ Mặt Trời, chứa được $1.300$ Trái Đất bên trong.
6. **Sao Thổ (Saturn)**: Nổi tiếng với vành đai băng đá và bụi sáng rực rỡ kỳ vĩ nhất.
7. **Sao Thiên Vương (Uranus)**: Hành tinh băng khổng lồ có trục tự quay nghiêng gần $98^\\circ$ như đang "lăn" trên quỹ đạo.
8. **Sao Hải Vương (Neptune)**: Hành tinh xa nhất, có những cơn gió siêu thanh bão táp mạnh nhất lên tới $2.100$ km/h!

*(Sao Diêm Vương - Pluto đã được phân loại lại thành Hành tinh lùn từ năm 2006).*`,
    keywords: ['khoa hoc', 'he mat troi', 'thai duong he', 'cac hanh tinh', 'sao hoa', 'sao moc', 'sao tho', 'sao kim', 'trai dat'],
    synonyms: ['thu tu cac hanh tinh trong he mat troi', '8 hanh tinh he mat troi', 'solar system'],
    sampleQuestions: [
      'Thứ tự các hành tinh trong Hệ Mặt Trời',
      'Hành tinh nào gần mặt trời nhất',
      'Hành tinh nào nóng nhất trong hệ mặt trời',
      'Hệ Mặt Trời gồm những hành tinh nào',
    ],
    source: 'NASA Solar System Exploration',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'sci-periodic-table',
    category: 'science',
    title: 'Cấu tạo Nguyên tử và Quy luật Bảng Tuần Hoàn Hóa Học',
    content: `Tất cả vật chất xung quanh chúng ta đều được cấu tạo từ các nguyên tử của các nguyên tố hóa học:

### 1. Cấu tạo cơ bản của một Nguyên tử:
- **Hạt nhân (Nucleus) ở tâm**:
  - **Proton ($p^+$)**: Mang điện tích dương $+1$. Số lượng proton chính là Số hiệu nguyên tử ($Z$).
  - **Neutron ($n^0$)**: Không mang điện tích.
- **Lớp vỏ Electron ($e^-$)**: Mang điện tích âm $-1$, chuyển động trên các orbital quanh hạt nhân.
- Trong nguyên tử trung hòa về điện: **Số Proton = Số Electron**.

### 2. Quy luật Bảng Tuần Hoàn Mendeleev:
- Bảng hiện tại gồm 118 nguyên tố hóa học được sắp xếp theo chiều **tăng dần của điện tích hạt nhân**.
- **Chu kỳ (Hàng ngang)**: Các nguyên tố có cùng số lớp electron.
- **Nhóm (Cột dọc)**: Các nguyên tố có số electron lớp ngoài cùng giống nhau, do đó có tính chất hóa học rất tương đồng.
- Nhóm 18 (Cột cuối cùng bên phải) là các **Khí hiếm (Helium, Neon, Argon...)** vô cùng bền vững, hầu như không phản ứng hóa học.`,
    keywords: ['khoa hoc', 'hoa hoc', 'bang tuan hoan', 'nguyen tu', 'proton', 'electron', 'neutron', 'mendeleev'],
    synonyms: ['cau tao nguyen tu la gi', 'quy luat bang tuan hoan hoa hoc', 'so hieu nguyen tu'],
    sampleQuestions: [
      'Cấu tạo của nguyên tử gồm những gì',
      'Bảng tuần hoàn hóa học được sắp xếp theo quy luật nào',
      'Phân biệt proton electron và neutron',
      'Khí hiếm trong hóa học là gì',
    ],
    source: 'IUPAC Periodic Table of the Elements',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },

  // =========================================================================
  // 10. ANIME & MANGA
  // =========================================================================
  {
    id: 'anime-frieren-overview',
    category: 'anime',
    title: 'Tổng quan và sức hút của anime Frieren: Pháp Sư Tiễn Táng (Beyond Journey\'s End)',
    content: `**Frieren: Beyond Journey's End (Sousou no Frieren)** là một trong những kiệt tác anime được đánh giá cao nhất lịch sử:

### 1. Cốt truyện độc đáo:
Phim không bắt đầu bằng hành trình đi diệt Ma Vương, mà bắt đầu **SAU KHI** Ma Vương đã bị tiêu diệt! Nhân vật chính là Frieren - một nữ pháp sư tộc Elf sống hàng ngàn năm. Trong khi các đồng đội loài người già đi và qua đời, Frieren mới nhận ra cô đã quá hời hợt với thời gian hữu hạn của họ, từ đó bắt đầu chuyến hành trình tìm hiểu trái tim con người.

### 2. Điểm đặc sắc:
- **Xưởng phim sản xuất**: Madhouse với hoạt ảnh mượt mà, phân cảnh chiến đấu mãn nhãn và nhạc nền hòa tấu đỉnh cao của Evan Call.
- **Thông điệp nhân văn**: Bài học sâu sắc về trân trọng từng khoảnh khắc bình dị bên những người thân yêu khi còn có thể.`,
    keywords: ['anime', 'frieren', 'phap su tien tang', 'sousou no frieren', 'elf', 'himmel', 'fern', 'stark', 'madhouse'],
    synonyms: ['review anime frieren', 'noi dung frieren', 'phim frieren co hay khong'],
    sampleQuestions: [
      'Anime Frieren nói về điều gì',
      'Tại sao anime Frieren lại nổi tiếng',
      'Giới thiệu anime Pháp sư tiễn táng Frieren',
      'Nội dung chính của anime Sousou no Frieren',
    ],
    source: 'Anime News Network & Shogakukan',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'anime-terms-guide',
    category: 'anime',
    title: 'Từ điển thuật ngữ Anime thông dụng: Waifu, Isekai, Shounen, Slice of Life',
    content: `Một số thuật ngữ quen thuộc trong cộng đồng người hâm mộ Anime/Manga:

- 🌸 **Waifu / Husbando**: Bắt nguồn từ từ tiếng Anh "wife/husband", dùng để chỉ nhân vật nữ/nam anime mà người xem vô cùng yêu mến và xem như hình mẫu lý tưởng.
- 🌀 **Isekai (Dị giới)**: Thể loại truyện/phim mà nhân vật chính bị chuyển sinh, triệu hồi hoặc xuyên không sang một thế giới ma thuật hoàn toàn mới.
- ⚔️ **Shounen**: Dòng tác phẩm hướng tới độc giả thiếu niên, thường đề cao tình bạn, sự nỗ lực rèn luyện và tinh thần không bao giờ bỏ cuộc (*One Piece*, *Naruto*, *Dragon Ball*).
- ☕ **Slice of Life (Đời thường)**: Thể loại tái hiện cuộc sống thường nhật bình dị, học đường, tình cảm ấm áp và thư giãn, không có phản diện hay xung đột gay gắt.
- 🎭 **Tsundere**: Mẫu nhân vật bên ngoài tỏ ra lạnh lùng, khó gần hoặc bướng bỉnh nhưng bên trong lại rất ấm áp và quan tâm đối phương.`,
    keywords: ['anime', 'waifu', 'isekai', 'shounen', 'slice of life', 'tsundere', 'thuat ngu anime', 'otaku'],
    synonyms: ['y nghia tu waifu', 'the loai isekai la gi', 'shounen anime nghia la gi'],
    sampleQuestions: [
      'Waifu nghĩa là gì trong anime',
      'Thể loại phim anime Isekai là gì',
      'Phân biệt Shounen và Slice of life',
      'Thuật ngữ anime phổ biến',
    ],
    source: 'Anime Terminology Archive',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'anime-one-piece-devil-fruit',
    category: 'anime',
    title: 'Phân loại 3 hệ Trái Ác Quỷ (Devil Fruit) trong thế giới One Piece',
    content: `Trong thế giới hải tặc **One Piece** của tác giả Eiichiro Oda, Trái Ác Quỷ mang lại cho người ăn những siêu năng lực phi thường nhưng đổi lại là lời nguyền bị biển cả ruồng bỏ (mất khả năng bơi lội):

### 1. Hệ Siêu Nhiên (Paramecia):
- Hệ phổ biến nhất, cho phép người dùng biến đổi cơ thể hoặc tác động lên môi trường xung quanh.
- Ví dụ: Trái Gomu Gomu no Mi của Luffy (biến cơ thể thành cao su), Trái Gura Gura no Mi của Râu Trắng (tạo ra chấn động động đất).

### 2. Hệ Biến Thú (Zoan):
- Cho phép người ăn biến hình thành một loài động vật hoặc dạng lai thú, tăng cường vượt bậc sức mạnh thể chất, tốc độ và khả năng phục hồi.
- **Zoan Thần Thoại (Mythical Zoan)**: Cực kỳ hiếm, mang sức mạnh của sinh vật thần thoại (như Trái Rồng Seiryu của Kaido hay Trái Phượng Hoàng của Marco).

### 3. Hệ Nguyên Tố Tự Nhiên (Logia):
- Hệ quả hiếm và mạnh nhất trong tự nhiên, cho phép người dùng biến toàn bộ cơ thể thành một nguyên tố tự nhiên (lửa, băng, ánh sáng, sấm sét...).
- Các đòn đánh vật lý thông thường sẽ xuyên qua người dùng Logia vô hại (chỉ có thể đánh trúng khi dùng Haki Vũ Trang hoặc khắc tinh nguyên tố).`,
    keywords: ['anime', 'one piece', 'trai ac quy', 'devil fruit', 'logia', 'paramecia', 'zoan', 'luffy'],
    synonyms: ['phan loai trai ac quy one piece', 'he logia la gi', 'he zoan than thoai', 'trai cao su luffy'],
    sampleQuestions: [
      'Trái Ác Quỷ trong One Piece chia làm mấy hệ',
      'Phân biệt 3 hệ Paramecia, Zoan và Logia',
      'Hệ Logia trong One Piece mạnh như thế nào',
      'Trái Ác Quỷ của Luffy thuộc hệ gì',
    ],
    source: 'One Piece Databook & Eiichiro Oda',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },

  // =========================================================================
  // 11. KIẾN THỨC PHỔ THÔNG & ĐỜI SỐNG
  // =========================================================================
  {
    id: 'gen-pomodoro-technique',
    category: 'general',
    title: 'Phương pháp Quả cà chua (Pomodoro) giúp tập trung học tập đỉnh cao',
    content: `**Phương pháp Pomodoro** do Francesco Cirillo phát triển vào cuối thập niên 1980 là công cụ quản lý thời gian và chống trì hoãn hàng đầu:

### Quy trình 5 bước thực hiện:
1. **Chọn một mục tiêu duy nhất**: Xác định nhiệm vụ cần hoàn thành (bài tập, ôn thi, viết code).
2. **Cài đặt đồng hồ 25 phút**: Đây là một phiên Pomodoro. Trong 25 phút này, hãy tắt toàn bộ mạng xã hội, tập trung $100\\%$ trí não.
3. **Nghỉ ngắn 5 phút**: Khi chuông reo, đứng dậy vươn vai, uống một ngụm nước, để mắt rời xa màn hình (tuyệt đối không lướt video ngắn).
4. **Lặp lại chu kỳ**: Sau mỗi chu kỳ 25 phút tập trung + 5 phút nghỉ.
5. **Nghỉ dài 15-30 phút**: Sau khi hoàn thành đủ 4 phiên Pomodoro (tương đương 2 tiếng), hãy thưởng cho não bộ một quãng nghỉ dài để tái tạo năng lượng!`,
    keywords: ['pomodoro', 'hoc tap', 'tap trung', 'quan ly thoi gian', 'nang suat', 'qua ca chua'],
    synonyms: ['phuong phap pomodoro la gi', 'cach hoc tap trung cao do', 'ky thuat pomodoro'],
    sampleQuestions: [
      'Phương pháp Pomodoro là gì',
      'Cách áp dụng kỹ thuật quả cà chua Pomodoro',
      'Làm thế nào để tập trung học bài không bị phân tâm',
      'Quy trình học theo phương pháp Pomodoro',
    ],
    source: 'Cirillo Consulting - The Pomodoro Technique',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'gen-feynman-technique',
    category: 'general',
    title: 'Kỹ thuật học nhanh Feynman: Nắm vững mọi kiến thức bằng 4 bước',
    content: `**Kỹ thuật Feynman (The Feynman Technique)** được đặt tên theo nhà vật lý đoạt giải Nobel Richard Feynman, được mệnh danh là phương pháp học tập hiệu quả nhất thế giới:

### 4 bước của Kỹ thuật Feynman:
1. **Bước 1: Chọn chủ đề và viết tên lên trang giấy trắng**: Viết ra tất cả những gì bạn đã biết về chủ đề đó.
2. **Bước 2: Giảng giải lại cho một đứa trẻ 10 tuổi**:
   - Dùng từ ngữ đơn giản, mộc mạc, không dùng thuật ngữ chuyên ngành phức tạp.
   - Nếu bạn phải dùng từ ngữ đao to búa lớn để giải thích, điều đó chứng tỏ bạn chưa thực sự hiểu sâu vấn đề!
3. **Bước 3: Xác định lỗ hổng kiến thức**:
   - Khi đang giải thích mà bị ngập ngừng, lúng túng hoặc không giải thích được "tại sao", đó chính là lỗ hổng kiến thức của bạn.
   - Quay lại sách giáo khoa hoặc tài liệu để đọc lại phần đó cho đến khi thông suốt.
4. **Bước 4: Đơn giản hóa và dùng phép ẩn dụ (Analogy)**:
   - Tinh chỉnh lại câu chuyện, sử dụng các hình ảnh so sánh đời thường quen thuộc để khắc sâu vào trí nhớ dài hạn.`,
    keywords: ['general', 'feynman', 'ky thuat feynman', 'hoc nhanh', 'ghi nho', 'phuong phap hoc'],
    synonyms: ['cach hoc theo feynman', 'phuong phap ghi nho dinh cao', 'feynman technique'],
    sampleQuestions: [
      'Kỹ thuật học tập Feynman là gì',
      'Bốn bước của phương pháp Feynman',
      'Làm sao để hiểu sâu một bài học khó',
      'Cách giải thích kiến thức cho người mới bắt đầu',
    ],
    source: 'Richard Feynman Learning Philosophy',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'gen-vietnam-pho',
    category: 'general',
    title: 'Nét tinh hoa ẩm thực Phở truyền thống Việt Nam',
    content: `**Phở** được coi là quốc hồn quốc túy của nền ẩm thực Việt Nam và được bạn bè quốc tế vinh danh khắp năm châu:

### 1. Bí quyết của nồi nước dùng:
Nước dùng phở bò truyền thống phải được ninh từ xương bò từ 8 đến 12 tiếng cùng các loại gia vị nướng dậy mùi: gừng nướng, hành củ nướng, hoa hồi, quế, thảo quả, đinh hương và hạt mùi thơm nức mũi. Nước dùng chuẩn phải trong, ngọt thanh tự nhiên từ tủy xương chứ không gắt vị mì chính.

### 2. Sự khác biệt giữa Phở Bắc và Phở Nam:
- **Phở Bắc (Hà Nội)**: Chú trọng độ thanh trong của nước dùng, ăn kèm bánh phở mỏng mềm, nhiều hành hoa, giấm tỏi ớt tươi và quẩy giòn tan.
- **Phở Nam (Sài Gòn)**: Nước dùng đậm đà, hơi thiên vị ngọt, bánh phở sợi nhỏ dai, ăn kèm đĩa rau thơm phong phú (ngò gai, húng quế), giá đỗ, tương đen và tương ớt.`,
    keywords: ['pho', 'pho bo', 'am thuc viet nam', 'mon an viet nam', 'pho ha noi', 'pho bac', 'pho nam'],
    synonyms: ['nguon goc pho viet nam', 'cach nau pho bo truyen thong', 'mon ngon viet nam'],
    sampleQuestions: [
      'Giới thiệu về món phở Việt Nam',
      'Sự khác nhau giữa phở Bắc và phở Nam',
      'Bí quyết nấu nước dùng phở bò thơm ngon',
      'Nét đặc sắc của phở truyền thống',
    ],
    source: 'Vietnam Culinary Heritage Association',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
  {
    id: 'gen-daily-water-intake',
    category: 'general',
    title: 'Công thức tính lượng nước cơ thể cần uống mỗi ngày và thời điểm vàng',
    content: `Nước chiếm khoảng $60\\% - 70\\%$ trọng lượng cơ thể người. Thiếu nước gây mệt mỏi, đau đầu, giảm tập trung và ảnh hưởng xấu đến thận:

### 1. Công thức tính lượng nước chuẩn theo cân nặng:
$$\\text{Lượng nước (Lít)} = \\text{Cân nặng (kg)} \\times 0.04$$
- Ví dụ:
  - Bạn nặng $50$ kg $\\rightarrow$ Cần uống: $50 \\times 0.04 = \\mathbf{2.0 \\text{ lít/ngày}}$.
  - Bạn nặng $65$ kg $\\rightarrow$ Cần uống: $65 \\times 0.04 = \\mathbf{2.6 \\text{ lít/ngày}}$.
*(Nếu bạn chơi thể thao đổ nhiều mồ hôi hoặc thời tiết nắng nóng, hãy bổ sung thêm $500$ ml nước điện giải).*

### 2. Bốn thời điểm vàng nên uống nước:
1. **Ngay sau khi thức dậy**: $1$ ly nước ấm ($250$ ml) giúp đánh thức hệ tiêu hóa và đào thải độc tố sau giấc ngủ dài.
2. **Trước bữa ăn 30 phút**: Giúp niêm mạc dạ dày chuẩn bị tiêu hóa tốt hơn.
3. **Trước khi đi tắm**: Giúp cân bằng huyết áp.
4. **Trước khi đi ngủ 30 phút**: $1$ ly nhỏ giúp phòng ngừa cô đặc máu và đột quỵ ban đêm.`,
    keywords: ['general', 'uong nuoc', 'luong nuoc moi ngay', 'suc khoe', 'cach tinh luong nuoc', 'nuoc uong'],
    synonyms: ['moi ngay nen uong bao nhieu lit nuoc', 'cong thuc tinh nuoc uong', 'uong nuoc dung cach'],
    sampleQuestions: [
      'Mỗi ngày nên uống bao nhiêu nước',
      'Công thức tính lượng nước cần uống theo cân nặng',
      'Các thời điểm nên uống nước trong ngày',
      'Cách uống nước đúng cách tốt cho sức khỏe',
    ],
    source: 'World Health Organization (WHO) Hydration Guidelines',
    verified: true,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
  },
];
