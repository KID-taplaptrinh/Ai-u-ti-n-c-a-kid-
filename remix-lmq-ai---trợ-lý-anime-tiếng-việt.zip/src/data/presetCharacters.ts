import { PresetCharacter } from '../types';

export const PRESET_CHARACTERS: PresetCharacter[] = [
  {
    id: 'aoi',
    name: 'Aoi',
    subtitle: 'Nữ trợ lý Cyberpunk',
    description: 'Năng động, thông minh, phong cách tương lai với mái tóc xanh neon.',
    accentColor: '#38bdf8',
    personality: 'Nhiệt tình & Sáng tạo',
    tag: 'Cyber Assistant',
  },
  {
    id: 'kuro',
    name: 'Kuro',
    subtitle: 'Neko Chibi Tinh Nghịch',
    description: 'Cô bé tai mèo dễ thương, luôn mang lại tiếng cười và sự ấm áp.',
    accentColor: '#f43f5e',
    personality: 'Hài hước & Đáng yêu',
    tag: 'Neko Girl',
  },
  {
    id: 'luna',
    name: 'Luna',
    subtitle: 'Android Hacker',
    description: 'Chiến binh công nghệ mắt tím, điềm tĩnh và thông thái.',
    accentColor: '#a855f7',
    personality: 'Bí ẩn & Sắc bén',
    tag: 'Purple Android',
  },
  {
    id: 'ren',
    name: 'Ren',
    subtitle: 'Quản Gia Học Giả',
    description: 'Quản gia lịch lãm, điềm đạm, sẵn sàng hỗ trợ giải đáp mọi bài toán.',
    accentColor: '#eab308',
    personality: 'Lịch thiệp & Thông thái',
    tag: 'Butler Scholar',
  },
];
