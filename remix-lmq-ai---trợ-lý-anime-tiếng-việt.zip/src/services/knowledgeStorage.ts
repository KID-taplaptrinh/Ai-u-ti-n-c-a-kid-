import { KnowledgeItem, KnowledgeBackupFile } from '../types/knowledge';
import { DEFAULT_KNOWLEDGE_BASE } from '../data/defaultKnowledge';

const DB_NAME = 'lmq_knowledge_database_v2';
const DB_VERSION = 1;
const STORE_NAME = 'custom_knowledge_store';
const LOCAL_STORAGE_FALLBACK_KEY = 'lmq_custom_knowledge_backup_v2';

// Bộ nhớ đệm In-Memory hỗ trợ môi trường không có DOM/Window (SSR, CLI, Node Test)
const inMemoryFallbackStore = new Map<string, KnowledgeItem>();

// Khởi tạo và kết nối IndexedDB an toàn
function openIndexedDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !('indexedDB' in window)) {
      return reject(new Error('Môi trường không hỗ trợ IndexedDB'));
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event: any) => {
      const db = event.target.result as IDBDatabase;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Lỗi mở IndexedDB'));
  });
}

// Lấy toàn bộ các mục kiến thức tùy chỉnh do người dùng thêm vào
export async function getCustomKnowledgeItems(): Promise<KnowledgeItem[]> {
  try {
    const db = await openIndexedDB();
    return new Promise((resolve) => {
      const transaction = db.transaction(STORE_NAME, 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.getAll();

      request.onsuccess = () => {
        const items = (request.result as KnowledgeItem[]) || [];
        resolve(items);
      };

      request.onerror = () => {
        resolve(getFallbackItems());
      };
    });
  } catch {
    return getFallbackItems();
  }
}

// Lấy toàn bộ kho kiến thức hoàn chỉnh (Mặc định + Tùy chỉnh người dùng)
export async function getAllKnowledgeItems(): Promise<KnowledgeItem[]> {
  const customItems = await getCustomKnowledgeItems();
  const customMap = new Map<string, KnowledgeItem>();
  for (const item of customItems) {
    customMap.set(item.id, item);
  }

  // Kết hợp: Nếu mục mặc định bị người dùng sửa (trùng ID), ưu tiên bản sửa đổi của người dùng
  const combined: KnowledgeItem[] = [];

  for (const defaultItem of DEFAULT_KNOWLEDGE_BASE) {
    if (customMap.has(defaultItem.id)) {
      combined.push(customMap.get(defaultItem.id)!);
      customMap.delete(defaultItem.id);
    } else {
      combined.push(defaultItem);
    }
  }

  // Thêm các mục người dùng tạo mới hoàn toàn
  for (const newItem of customMap.values()) {
    combined.push(newItem);
  }

  return combined;
}

// Thêm hoặc Cập nhật một mục kiến thức
export async function saveKnowledgeItem(item: KnowledgeItem): Promise<void> {
  const itemToSave: KnowledgeItem = {
    ...item,
    updatedAt: Date.now(),
  };

  try {
    const db = await openIndexedDB();
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.put(itemToSave);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch {
    // IndexedDB không khả dụng -> fallback
  }

  // Luôn đồng bộ vào Fallback làm bản sao lưu an toàn
  saveToFallback(itemToSave);
}

// Xóa một mục kiến thức
export async function deleteKnowledgeItem(id: string): Promise<void> {
  try {
    const db = await openIndexedDB();
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.delete(id);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch {
    // fallback
  }

  deleteFromFallback(id);
}

// Khôi phục kho kiến thức về trạng thái mặc định
export async function resetKnowledgeBase(): Promise<void> {
  try {
    const db = await openIndexedDB();
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.clear();

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch {
    // fallback
  }

  inMemoryFallbackStore.clear();
  if (typeof localStorage !== 'undefined') {
    try {
      localStorage.removeItem(LOCAL_STORAGE_FALLBACK_KEY);
    } catch {
      // ignore
    }
  }
}

// Xuất kho kiến thức ra tệp JSON sao lưu
export async function exportKnowledgeToJSON(): Promise<string> {
  const items = await getAllKnowledgeItems();
  const backup: KnowledgeBackupFile = {
    version: '2.0.0',
    appName: 'LMQ AI Local Knowledge Base',
    exportedAt: new Date().toISOString(),
    totalItems: items.length,
    items,
  };
  return JSON.stringify(backup, null, 2);
}

// Nhập kho kiến thức từ chuỗi JSON
export async function importKnowledgeFromJSON(
  jsonText: string
): Promise<{ success: boolean; count: number; error?: string }> {
  try {
    const parsed = JSON.parse(jsonText);
    const items: KnowledgeItem[] = Array.isArray(parsed)
      ? parsed
      : Array.isArray(parsed.items)
      ? parsed.items
      : null;

    if (!items || items.length === 0) {
      return { success: false, count: 0, error: 'File JSON không chứa danh sách kiến thức hợp lệ' };
    }

    let importedCount = 0;
    for (const raw of items) {
      if (raw && typeof raw.title === 'string' && typeof raw.content === 'string') {
        const validItem: KnowledgeItem = {
          id: raw.id || `custom-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          category: raw.category || 'general',
          title: raw.title.trim(),
          content: raw.content.trim(),
          keywords: Array.isArray(raw.keywords) ? raw.keywords : [],
          synonyms: Array.isArray(raw.synonyms) ? raw.synonyms : [],
          sampleQuestions: Array.isArray(raw.sampleQuestions) ? raw.sampleQuestions : [],
          source: raw.source || 'Nhập từ file JSON',
          verified: Boolean(raw.verified),
          isCustom: true,
          createdAt: raw.createdAt || Date.now(),
          updatedAt: Date.now(),
        };

        await saveKnowledgeItem(validItem);
        importedCount++;
      }
    }

    return { success: true, count: importedCount };
  } catch (err: any) {
    return {
      success: false,
      count: 0,
      error: `Định dạng tệp JSON không hợp lệ: ${err.message || 'Lỗi phân tích cú pháp'}`,
    };
  }
}

// --- HELPER FALLBACK (LocalStorage & In-Memory) ---
function getFallbackItems(): KnowledgeItem[] {
  if (typeof localStorage === 'undefined') {
    return Array.from(inMemoryFallbackStore.values());
  }
  try {
    const data = localStorage.getItem(LOCAL_STORAGE_FALLBACK_KEY);
    if (data) {
      const parsed: KnowledgeItem[] = JSON.parse(data);
      for (const item of parsed) {
        inMemoryFallbackStore.set(item.id, item);
      }
      return parsed;
    }
  } catch {
    // ignore
  }
  return Array.from(inMemoryFallbackStore.values());
}

function saveToFallback(item: KnowledgeItem) {
  inMemoryFallbackStore.set(item.id, item);
  if (typeof localStorage !== 'undefined') {
    try {
      const items = Array.from(inMemoryFallbackStore.values());
      localStorage.setItem(LOCAL_STORAGE_FALLBACK_KEY, JSON.stringify(items));
    } catch {
      // ignore
    }
  }
}

function deleteFromFallback(id: string) {
  inMemoryFallbackStore.delete(id);
  if (typeof localStorage !== 'undefined') {
    try {
      const items = Array.from(inMemoryFallbackStore.values());
      localStorage.setItem(LOCAL_STORAGE_FALLBACK_KEY, JSON.stringify(items));
    } catch {
      // ignore
    }
  }
}
