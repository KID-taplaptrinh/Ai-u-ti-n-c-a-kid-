import { KnowledgeItem, KnowledgeSearchResult } from '../types/knowledge';
import { removeVietnameseAccents, normalizeVietnameseSlang } from './vietnameseRules';

// Danh sách từ dừng (Stop words) và các từ khung câu hỏi tiếng Việt không mang ý nghĩa chủ đề riêng biệt
const STOP_WORDS = new Set([
  'la',
  'gi',
  'sao',
  'nhu',
  'the',
  'nao',
  'the nao',
  'ntn',
  'cho',
  'minh',
  'toi',
  'em',
  'anh',
  'chi',
  'ban',
  'hoi',
  'voi',
  'cua',
  'trong',
  'ngoai',
  'co',
  'va',
  'de',
  'mot',
  'nhung',
  'cac',
  'moi',
  'duoc',
  'giup',
  'biet',
  'cai',
  'chiec',
  'xin',
  'a',
  'y',
  'ha',
  'nhe',
  'nha',
  'ra',
  'vao',
  'len',
  'xuong',
  'hay',
  'o',
  'tai',
  'vi',
  'vay',
  'nua',
  'di',
  'nhi',
  'ma',
  'thi',
  'cung',
  'da',
  'se',
  'dang',
  'chua',
  'roi',
  'khi',
  'dau',
  'ai',
  'bao',
  'nhieu',
  've',
  'bang',
  'theo',
  'co the',
  'lam sao',
  'nhu nao',
  'ra sao',
  // Từ khung câu hỏi chung chung dễ gây khớp nhầm chủ đề (ví dụ: "ý nghĩa của cuộc sống")
  'nghia',
  'khai',
  'niem',
  'giai',
  'thich',
  'phan',
  'tich',
  'thong',
  'tin',
  'kien',
  'thuc',
  'tom',
  'tat',
  'so',
  'sanh',
  'tong',
  'hop',
  'chi',
  'tiet',
  'loai',
  'kieu',
  'dang',
  'vai',
  'tro',
  'tam',
  'quan',
  'trong',
  'su',
  'viec',
  'thu',
]);

// Chuẩn hóa văn bản tìm kiếm: chữ thường, bỏ dấu, thay teencode, bỏ ký tự đặc biệt
export function cleanSearchQuery(query: string): string {
  const slangNorm = normalizeVietnameseSlang(query);
  const noAccent = removeVietnameseAccents(slangNorm);
  return noAccent
    .replace(/[?!.,;:()[\]{}"'\\/`~@#$%^&*+=<>]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// Kiểm tra khớp nguyên cụm từ có ranh giới từ (tránh "pi" khớp nhầm vào "api" hay "ram" vào "program")
export function containsWholePhrase(haystack: string, needle: string): boolean {
  if (!haystack || !needle) return false;
  return ` ${haystack} `.includes(` ${needle} `);
}

// Tách chuỗi thành mảng các từ đơn (tokens) đã lọc bỏ stop words
export function extractMeaningfulTokens(cleanedQuery: string): string[] {
  const words = cleanedQuery.split(' ').filter((w) => w.length > 0);
  return words.filter((w) => !STOP_WORDS.has(w) && w.length > 1);
}

// Trích xuất các cụm 2 từ mang ý nghĩa chủ đề (từ danh sách meaningful tokens)
export function extractBigrams(cleanedText: string): string[] {
  const words = extractMeaningfulTokens(cleanedText);
  const bigrams: string[] = [];
  for (let i = 0; i < words.length - 1; i++) {
    bigrams.push(`${words[i]} ${words[i + 1]}`);
  }
  return bigrams;
}

// Tính độ tương đồng Dice Coefficient giữa hai chuỗi
function diceCoefficient(str1: string, str2: string): number {
  if (str1 === str2) return 1.0;
  if (str1.length < 2 || str2.length < 2) return 0.0;

  const getBigrams = (str: string) => {
    const s = str.replace(/\s+/g, '');
    const v: string[] = [];
    for (let i = 0; i < s.length - 1; i++) {
      v.push(s.slice(i, i + 2));
    }
    return v;
  };

  const bg1 = getBigrams(str1);
  const bg2 = getBigrams(str2);
  let intersection = 0;

  const countMap = new Map<string, number>();
  for (const b of bg1) {
    countMap.set(b, (countMap.get(b) || 0) + 1);
  }

  for (const b of bg2) {
    const count = countMap.get(b) || 0;
    if (count > 0) {
      countMap.set(b, count - 1);
      intersection++;
    }
  }

  return (2.0 * intersection) / (bg1.length + bg2.length);
}

// Nhận diện chủ đề từ câu hỏi (Topic Detection) để tăng độ ưu tiên
function detectQueryTopic(cleanedQuery: string): string | null {
  if (/\b(minecraft|mc|nether|enchant|enchanting|diamond|obsidian|stronghold|ender dragon|ancient debris|netherite|blaze rod)\b/.test(cleanedQuery)) {
    return 'minecraft';
  }
  if (/\b(windows|win\s*(10|11)?|shortcut|phim tat|task manager|disk cleanup|bsod|sfc scannow|startup apps)\b/.test(cleanedQuery)) {
    return 'windows';
  }
  if (/\b(may tinh|pc|ram|dual channel|cpu|gpu|card do hoa|card man hinh|ssd|hdd|nvme|wifi|dns|flushdns|ipconfig)\b/.test(cleanedQuery)) {
    return 'computer';
  }
  if (/\b(html|semantic|opengraph|the meta|viewport)\b/.test(cleanedQuery)) {
    return 'html';
  }
  if (/\b(css|can giua|center div|flexbox|grid|box model|border box|margin|padding|rem|vw)\b/.test(cleanedQuery)) {
    return 'css';
  }
  if (/\b(javascript|js|closure|async|await|promise|event loop|call stack|microtask|macrotask|reduce|map filter)\b/.test(cleanedQuery)) {
    return 'javascript';
  }
  if (/\b(git|github|commit|branch|push|pull|merge|restful|rest api|http status|oop|huong doi tuong|dong goi|ke thua|da hinh)\b/.test(cleanedQuery)) {
    return 'programming';
  }
  if (/\b(toan hoc|pytago|pythagorean|tam giac vuong|hinh tron|dien tich|chu vi|so pi|phuong trinh bac|delta)\b/.test(cleanedQuery)) {
    return 'math';
  }
  if (/\b(khoa hoc|van toc anh sang|toc do anh sang|thai duong he|he mat troi|hanh tinh|bang tuan hoan|nguyen tu|proton|electron)\b/.test(cleanedQuery)) {
    return 'science';
  }
  if (/\b(anime|manga|frieren|waifu|isekai|shounen|slice of life|tsundere|one piece|trai ac quy|devil fruit)\b/.test(cleanedQuery)) {
    return 'anime';
  }
  if (/\b(pomodoro|qua ca chua|feynman|pho bo|uong nuoc|luong nuoc)\b/.test(cleanedQuery)) {
    return 'general';
  }
  return null;
}

// Đánh giá điểm độ phù hợp của một KnowledgeItem với câu hỏi của người dùng
export function scoreKnowledgeItem(
  query: string,
  item: KnowledgeItem
): { score: number; matchedReasons: string[] } {
  const cleanedQuery = cleanSearchQuery(query);
  const queryTokens = extractMeaningfulTokens(cleanedQuery);
  const queryTokenSet = new Set(queryTokens);
  const queryBigrams = extractBigrams(cleanedQuery);

  if (queryTokens.length === 0) {
    return { score: 0, matchedReasons: [] };
  }

  let totalScore = 0;
  const matchedReasons: string[] = [];
  let hasSampleMatch = false;
  let hasAliasPhraseMatch = false;
  let titleTokenMatches = 0;
  let aliasSingleTokenMatches = 0;

  // 1. So khớp với các câu hỏi mẫu (Sample Questions) - Trọng số cao nhất
  for (const sq of item.sampleQuestions) {
    const cleanedSQ = cleanSearchQuery(sq);
    const sqTokens = extractMeaningfulTokens(cleanedSQ);

    if (cleanedSQ === cleanedQuery) {
      totalScore += 100;
      hasSampleMatch = true;
      matchedReasons.push('Trùng khớp chính xác câu hỏi mẫu');
      break;
    }
    if (
      sqTokens.length >= 2 &&
      (containsWholePhrase(cleanedQuery, cleanedSQ) || containsWholePhrase(cleanedSQ, cleanedQuery))
    ) {
      totalScore += 80;
      hasSampleMatch = true;
      matchedReasons.push('Bao hàm câu hỏi mẫu');
      break;
    }

    // Độ tương đồng chuỗi cao (Dice coefficient) + phải có ít nhất 1 từ khóa chủ đề chung
    const dice = diceCoefficient(cleanedQuery, cleanedSQ);
    const sharedSubjectTokens = sqTokens.filter((t) => queryTokenSet.has(t)).length;
    if (dice > 0.65 && sharedSubjectTokens >= 2) {
      totalScore += Math.round(dice * 75);
      hasSampleMatch = true;
      matchedReasons.push(`Gần giống câu hỏi mẫu (${Math.round(dice * 100)}%)`);
      break;
    }
  }

  // 2. So khớp với Tiêu đề (Title)
  const cleanedTitle = cleanSearchQuery(item.title);
  const titleTokens = extractMeaningfulTokens(cleanedTitle);
  const titleTokenSet = new Set(titleTokens);

  if (queryTokens.length >= 2 && containsWholePhrase(cleanedTitle, queryTokens.join(' '))) {
    totalScore += 70;
    titleTokenMatches = queryTokens.length;
    matchedReasons.push('Trùng trực tiếp tiêu đề bài viết');
  } else {
    for (const token of queryTokens) {
      if (titleTokenSet.has(token)) {
        titleTokenMatches++;
      }
    }
    if (titleTokenMatches > 0) {
      const titleMatchRatio = titleTokenMatches / Math.max(queryTokens.length, 1);
      // Nếu chỉ khớp 1 từ trên câu hỏi dài (>= 3 từ), không thưởng điểm cao để tránh lạc đề
      if (titleTokenMatches >= 2 || queryTokens.length <= 2) {
        const titlePoints = Math.round(titleMatchRatio * 55);
        totalScore += titlePoints;
        matchedReasons.push(`Khớp ${titleTokenMatches} từ khóa trong tiêu đề (+${titlePoints}đ)`);
      }
    }
  }

  // 3. So khớp với Từ khóa (Keywords) & Từ đồng nghĩa (Synonyms)
  const allAliases = [...item.keywords, ...item.synonyms];
  const matchedAliasTokens = new Set<string>();

  for (const alias of allAliases) {
    const cleanedAlias = cleanSearchQuery(alias);
    if (!cleanedAlias) continue;

    const aliasTokens = extractMeaningfulTokens(cleanedAlias);
    if (aliasTokens.length === 0) continue;

    // Khớp cụm từ có ranh giới từ (ưu tiên cụm từ >= 2 từ hoặc từ khóa chuyên biệt như "flexbox", "pomodoro", "minecraft")
    if (containsWholePhrase(cleanedQuery, cleanedAlias)) {
      if (aliasTokens.length >= 2 || cleanedAlias.length >= 4 || queryTokens.length <= 2) {
        hasAliasPhraseMatch = true;
        totalScore += aliasTokens.length >= 2 ? 42 : 30;
        matchedReasons.push(`Khớp cụm từ khóa/đồng nghĩa: "${alias}"`);
      }
    } else {
      // Khớp từng từ đơn nguyên vẹn trong alias
      for (const token of queryTokens) {
        if (aliasTokens.includes(token) && !matchedAliasTokens.has(token)) {
          matchedAliasTokens.add(token);
          aliasSingleTokenMatches++;
          totalScore += 14;
        }
      }
    }
  }

  // 4. So khớp Cụm 2 từ chủ đề (Subject Bigrams) với Tiêu đề
  const meaningfulTitleText = titleTokens.join(' ');
  for (const bigram of queryBigrams) {
    if (containsWholePhrase(meaningfulTitleText, bigram)) {
      totalScore += 22;
      matchedReasons.push(`Khớp cụm chủ đề "${bigram}"`);
    }
  }

  // 5. So khớp với Nội dung giải thích (Content) theo ranh giới từ (chỉ cộng thưởng khi đã có khớp chủ đề rõ ràng)
  const hasCoreMatch =
    hasSampleMatch ||
    hasAliasPhraseMatch ||
    titleTokenMatches >= 2 ||
    aliasSingleTokenMatches >= 2;

  if (hasCoreMatch) {
    const contentTokenSet = new Set(extractMeaningfulTokens(cleanSearchQuery(item.content)));
    let contentMatches = 0;
    for (const token of queryTokens) {
      if (contentTokenSet.has(token)) {
        contentMatches++;
      }
    }
    if (contentMatches > 0) {
      const contentPoints = Math.min(Math.round((contentMatches / queryTokens.length) * 20), 20);
      totalScore += contentPoints;
    }
  }

  // 6. Nhận diện chủ đề chuyên sâu (Topic Boost) — chỉ cộng khi đã có tín hiệu khớp với bài viết
  const detectedTopic = detectQueryTopic(cleanedQuery);
  if (
    detectedTopic &&
    (hasCoreMatch || titleTokenMatches >= 1 || aliasSingleTokenMatches >= 1) &&
    (item.category === detectedTopic ||
      (detectedTopic === 'html' && item.category === 'html_css') ||
      (detectedTopic === 'css' && item.category === 'html_css'))
  ) {
    totalScore += 15;
    matchedReasons.push(`Trùng chủ đề nhận diện: ${detectedTopic}`);
  }

  // 7. Xử lý các từ đồng nghĩa đặc biệt (Bàn phù phép Minecraft)
  const isEnchantQuery =
    cleanedQuery.includes('phu phep') ||
    cleanedQuery.includes('enchant') ||
    cleanedQuery.includes('enchanting') ||
    cleanedQuery.includes('me hoac');
  const isMcQuery =
    containsWholePhrase(cleanedQuery, 'minecraft') ||
    containsWholePhrase(cleanedQuery, 'mc') ||
    cleanedQuery.includes('tao ban phu phep');

  if (item.id === 'mc-enchanting-table' && isEnchantQuery && isMcQuery) {
    totalScore += 45;
    hasAliasPhraseMatch = true;
    matchedReasons.push('Đặc thù: Chế tạo Bàn Phù Phép trong Minecraft');
  }

  // 8. Cổng kiểm soát nghiêm ngặt: Chặn tuyệt đối các trường hợp trùng ngẫu nhiên 1 từ chung chung hoặc câu hỏi dài chỉ trùng 1 cụm từ rộng
  const totalDistinctSubjectMatches = new Set([
    ...queryTokens.filter((t) => titleTokenSet.has(t)),
    ...matchedAliasTokens,
    ...allAliases
      .map((a) => extractMeaningfulTokens(cleanSearchQuery(a)))
      .filter((toks) => toks.length > 0 && containsWholePhrase(cleanedQuery, toks.join(' ')))
      .flat(),
  ]).size;

  const subjectCoverage = totalDistinctSubjectMatches / Math.max(queryTokens.length, 1);

  if (!hasSampleMatch && !hasAliasPhraseMatch) {
    // Nếu câu hỏi có từ 2 từ chủ đề trở lên mà chỉ khớp đúng 1 từ (hoặc độ phủ < 45%), loại bỏ
    if (queryTokens.length >= 2 && (totalDistinctSubjectMatches < 2 || subjectCoverage < 0.45)) {
      totalScore = Math.min(totalScore, 20);
    }
  } else if (!hasSampleMatch && queryTokens.length >= 5 && subjectCoverage < 0.35) {
    // Câu hỏi dài (>= 5 từ chủ đề) mà chỉ trùng < 35% từ khóa (vd: chỉ trùng cụm rộng "vũ trụ"), loại bỏ để AI trả lời
    totalScore = Math.min(totalScore, 28);
  }

  return { score: totalScore, matchedReasons };
}

// Tìm kiếm kiến thức thông minh trong danh sách KnowledgeItem
export function searchKnowledgeBase(
  query: string,
  items: KnowledgeItem[],
  minConfidenceScore: number = 45
): KnowledgeSearchResult | null {
  const trimmed = query.trim();
  if (!trimmed || items.length === 0) return null;

  const results: KnowledgeSearchResult[] = [];

  for (const item of items) {
    const { score, matchedReasons } = scoreKnowledgeItem(trimmed, item);
    if (score >= minConfidenceScore) {
      let confidence: 'high' | 'medium' | 'low' = 'low';
      if (score >= 70) {
        confidence = 'high';
      } else if (score >= 50) {
        confidence = 'medium';
      }

      results.push({
        item,
        score,
        confidence,
        matchedReasons,
      });
    }
  }

  if (results.length === 0) {
    return null;
  }

  // Sắp xếp giảm dần theo điểm số
  results.sort((a, b) => b.score - a.score);

  const topResult = results[0];

  // Phát hiện các mục liên quan (Related Matches / Ambiguity Handling)
  const relatedCandidates = results
    .slice(1)
    .filter((r) => r.score >= minConfidenceScore && r.item.id !== topResult.item.id)
    .slice(0, 3)
    .map((r) => r.item);

  return {
    ...topResult,
    relatedMatches: relatedCandidates.length > 0 ? relatedCandidates : undefined,
  };
}

// Tìm kiếm danh sách các mục liên quan để làm ngữ cảnh tham chiếu cho Gemini AI hoặc gợi ý
export function searchRelatedKnowledgeItems(
  query: string,
  items: KnowledgeItem[],
  excludeId?: string,
  limit: number = 3
): KnowledgeItem[] {
  const trimmed = query.trim();
  if (!trimmed) return [];

  const scored = items
    .filter((item) => item.id !== excludeId)
    .map((item) => ({
      item,
      score: scoreKnowledgeItem(trimmed, item).score,
    }))
    .filter((entry) => entry.score >= 22)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((entry) => entry.item);

  return scored;
}
