import { ExpressionType } from '../types';
import { KnowledgeItem } from '../types/knowledge';
import { searchKnowledgeBase, containsWholePhrase } from './knowledgeSearch';

export interface BotResponseResult {
  text: string;
  expression: ExpressionType;
  queryForSearch?: string;
  mathCalculation?: string;
  triggerGame?: 'caro' | 'chess';
  triggerKnowledgeModal?: boolean;
  matchedKnowledge?: boolean;
  knowledgeSource?: string;
  knowledgeCategory?: string;
  triggerTeach?: string;
  relatedSuggestions?: string[];
}

export interface RuleIntent {
  id: string;
  keywords: string[];
  responses: string[];
  expression: ExpressionType;
  triggerGame?: 'caro' | 'chess';
  isOfflineTopicFallback?: boolean;
}

// Chuẩn hóa loại bỏ dấu tiếng Việt để đối sánh từ khóa mềm dẻo
export function removeVietnameseAccents(str: string): string {
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .toLowerCase()
    .trim();
}

// Chuẩn hóa từ lóng, teencode thông dụng của giới trẻ Việt Nam
export function normalizeVietnameseSlang(text: string): string {
  let lower = text.toLowerCase();
  const slangMap: Record<string, string> = {
    '\\bko\\b': 'không',
    '\\bk\\b': 'không',
    '\\bkhong\\b': 'không',
    '\\bdc\\b': 'được',
    '\\bđc\\b': 'được',
    '\\bbt\\b': 'biết',
    '\\bj\\b': 'gì',
    '\\bgii\\b': 'gì',
    '\\bmik\\b': 'mình',
    '\\bmk\\b': 'mình',
    '\\bvs\\b': 'với',
    '\\bthui\\b': 'thôi',
    '\\bnhiu\\b': 'nhiều',
    '\\bng\\b': 'người',
    '\\bb\\b': 'bạn',
    '\\bh\\b': 'giờ',
    '\\bok\\b': 'được',
    '\\bokie\\b': 'được',
    '\\buk\\b': 'ừ',
    '\\buhm\\b': 'ừ',
    '\\bcam on\\b': 'cảm ơn',
    '\\btks\\b': 'cảm ơn',
    '\\bty\\b': 'cảm ơn',
    '\\bntn\\b': 'như thế nào',
    '\\bnhu nao\\b': 'như thế nào',
    '\\bra sao\\b': 'như thế nào',
    '\\bla j\\b': 'là gì',
    '\\bla gii\\b': 'là gì',
    '\\bmc\\b': 'minecraft',
  };

  for (const [pattern, replacement] of Object.entries(slangMap)) {
    lower = lower.replace(new RegExp(pattern, 'g'), replacement);
  }
  return lower;
}

// Tính toán toán học an toàn (KHÔNG dùng eval())
export function safeCalculateMath(input: string): { expression: string; result: number } | null {
  let clean = input.toLowerCase();
  clean = clean.replace(/tính|tinh|kết quả|ket qua|bằng bao nhiêu|bang bao nhieu|bao nhiêu|bao nhieu/g, '');
  clean = clean.replace(/căn bậc 2 của|căn của|căn|sqrt/g, 'sqrt');
  clean = clean.replace(/nhân|x|times/g, '*');
  clean = clean.replace(/chia|divide/g, '/');
  clean = clean.replace(/cộng|plus/g, '+');
  clean = clean.replace(/trừ|minus/g, '-');
  clean = clean.replace(/mũ|\^/g, '^');
  clean = clean.replace(/pi/g, Math.PI.toString());

  const mathCharsRegex = /^[\d\s+\-*/%^().sqrt]+$/;
  const hasDigits = /\d/.test(clean);
  const hasOperators = /[+\-*/%^]|sqrt/.test(clean);

  if (!hasDigits || !hasOperators || !mathCharsRegex.test(clean.trim())) {
    return null;
  }

  try {
    const rawResult = evaluateMathString(clean.trim());
    if (typeof rawResult === 'number' && !isNaN(rawResult) && isFinite(rawResult)) {
      return {
        expression: input.trim(),
        result: Math.round(rawResult * 1000000) / 1000000,
      };
    }
  } catch {
    return null;
  }

  return null;
}

function evaluateMathString(expression: string): number {
  let expr = expression.replace(/sqrt\s*\(([^)]+)\)/g, (_, inner) => {
    return Math.sqrt(evaluateMathString(inner)).toString();
  });
  expr = expr.replace(/sqrt\s*(\d+(\.\d+)?)/g, (_, inner) => {
    return Math.sqrt(parseFloat(inner)).toString();
  });

  const tokens = tokenizeMath(expr);
  const rpn = shuntingYard(tokens);
  return evaluateRPN(rpn);
}

function tokenizeMath(expr: string): string[] {
  const tokens: string[] = [];
  let i = 0;
  while (i < expr.length) {
    const char = expr[i];
    if (/\s/.test(char)) {
      i++;
      continue;
    }
    if (/[\d.]/.test(char)) {
      let num = '';
      while (i < expr.length && /[\d.]/.test(expr[i])) {
        num += expr[i];
        i++;
      }
      tokens.push(num);
      continue;
    }
    if ('+-*/%^()'.includes(char)) {
      tokens.push(char);
      i++;
      continue;
    }
    i++;
  }
  return tokens;
}

function shuntingYard(tokens: string[]): string[] {
  const output: string[] = [];
  const operators: string[] = [];
  const precedence: Record<string, number> = {
    '+': 1,
    '-': 1,
    '*': 2,
    '/': 2,
    '%': 2,
    '^': 3,
  };

  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    if (!isNaN(parseFloat(token))) {
      output.push(token);
    } else if (token in precedence) {
      if (token === '-' && (i === 0 || '^(+-*/%'.includes(tokens[i - 1]))) {
        output.push('0');
      }
      while (
        operators.length > 0 &&
        operators[operators.length - 1] !== '(' &&
        precedence[operators[operators.length - 1]] >= precedence[token]
      ) {
        output.push(operators.pop()!);
      }
      operators.push(token);
    } else if (token === '(') {
      operators.push(token);
    } else if (token === ')') {
      while (operators.length > 0 && operators[operators.length - 1] !== '(') {
        output.push(operators.pop()!);
      }
      operators.pop();
    }
  }

  while (operators.length > 0) {
    output.push(operators.pop()!);
  }

  return output;
}

function evaluateRPN(rpn: string[]): number {
  const stack: number[] = [];
  for (const token of rpn) {
    if (!isNaN(parseFloat(token))) {
      stack.push(parseFloat(token));
    } else {
      const b = stack.pop() ?? 0;
      const a = stack.pop() ?? 0;
      switch (token) {
        case '+':
          stack.push(a + b);
          break;
        case '-':
          stack.push(a - b);
          break;
        case '*':
          stack.push(a * b);
          break;
        case '/':
          stack.push(b !== 0 ? a / b : NaN);
          break;
        case '%':
          stack.push(a % b);
          break;
        case '^':
          stack.push(Math.pow(a, b));
          break;
      }
    }
  }
  return stack[0] ?? 0;
}

// Trả về thời gian hiện tại theo tiếng Việt
export function getVietnameseDateTime(): string {
  const now = new Date();
  const days = ['Chủ Nhật', 'Thứ Hai', 'Thứ Ba', 'Thứ Tư', 'Thứ Năm', 'Thứ Sáu', 'Thứ Bảy'];
  const dayName = days[now.getDay()];
  const hours = now.getHours().toString().padStart(2, '0');
  const minutes = now.getMinutes().toString().padStart(2, '0');
  const seconds = now.getSeconds().toString().padStart(2, '0');
  const date = now.getDate().toString().padStart(2, '0');
  const month = (now.getMonth() + 1).toString().padStart(2, '0');
  const year = now.getFullYear();

  return `Bây giờ là **${hours}:${minutes}:${seconds}**, ${dayName}, ngày **${date}/${month}/${year}**.\n\nChúc bạn một ngày học tập và làm việc thật năng suất và ngập tràn niềm vui! (✿◠‿◠)`;
}

// =========================================================================
// KHO QUY TẮC TIẾNG VIỆT ĐỒ SỘ (HƠN 45 CHỦ ĐỀ VÀ HÀNG TRĂM CÂU TRẢ LỜI)
// =========================================================================
export const VIETNAMESE_INTENT_RULES: RuleIntent[] = [
  // 1. LỆNH CHƠI CỜ VÀ TRÒ CHƠI
  {
    id: 'game_chess_caro',
    keywords: [
      'choi co',
      'choi co vua',
      'choi co caro',
      'danh co',
      'danh co caro',
      'danh co vua',
      'caro',
      'co vua',
      'chess',
      'gomoku',
      'muon choi co',
      'co tro choi gi',
      'thach dau co',
      'ban co',
      'choi game',
      'tro choi',
    ],
    responses: [
      'Tuyệt vời luôn! Mình rất thích chơi cờ cùng bạn (≧▽≦)!\n\nBàn cờ tương tác thông minh đã được mở ra ngay trên màn hình. Bạn có thể chọn giữa **Cờ Caro (Gomoku)** hoặc **Cờ Vua tiêu chuẩn (8x8)** để so tài chiến thuật cùng mình nhé! Chúc bạn may mắn!',
      'Hehe, bạn tìm đúng người rồi đó! Mình được lập trình chiến thuật đánh cờ siêu nhạy nè (✿◠‿◠)!\n\nBàn cờ đã mở sẵn, bạn hãy chọn quân cờ và thể hiện những nước đi đỉnh cao nhất của bạn đi nào!',
      'Thách đấu được chấp nhận! Mình đã sẵn sàng rồi (•̀o•́)ง!\n\nHãy vào bàn cờ, nhấp vào ô cờ để đi quân, và cùng xem xem ai sẽ là người giành chiến thắng nha!',
    ],
    expression: 'happy',
    triggerGame: 'caro',
  },

  // 2. Chào hỏi ban ngày & chung
  {
    id: 'greeting_general',
    keywords: ['xin chao', 'chao ban', 'hello', 'hi lmq', 'chao em', 'hi bạn', 'alo', 'chao lmq', 'helo'],
    responses: [
      'Konnichiwa! Xin chào bạn yêu quý! Mình là **LMQ AI**, rất vui được gặp bạn hôm nay! (✿◠‿◠) Bạn đang cảm thấy thế nào?',
      'Chào bạn nha! Hôm nay trời thật đẹp, chúc bạn có một ngày tràn ngập niềm vui và năng lượng tích cực! Mình có thể giúp gì cho bạn nè?',
      'A chào bạn! Mình luôn ở đây sẵn sàng trò chuyện, giải đáp thắc mắc, tính toán hoặc đấu cờ cùng bạn đó (≧◡≦)!',
    ],
    expression: 'happy',
  },

  // 3. Chào buổi sáng
  {
    id: 'greeting_morning',
    keywords: ['chao buoi sang', 'good morning', 'sang roi', 'day roi', 'buoi sang vui ve', 'chuc buoi sang'],
    responses: [
      'Ohayou gozaimasu! Chúc bạn một buổi sáng ngập tràn ánh nắng và nhiều điều may mắn! Đừng quên ăn sáng và uống một ly nước ấm nhé (✿◠‿◠)!',
      'Chào buổi sáng người bạn tuyệt vời! Hãy bắt đầu ngày mới với một nụ cười thật tươi nha! Bạn đã có kế hoạch gì cho hôm nay chưa?',
    ],
    expression: 'happy',
  },

  // 4. Chào buổi tối & Chúc ngủ ngon
  {
    id: 'greeting_night',
    keywords: ['chuc ngu ngon', 'ngu ngon', 'good night', 'di ngu day', 'muon roi', 'chao buoi toi', 'di ngu thoi'],
    responses: [
      'Oyasuminasai! Chúc bạn có một giấc ngủ thật ngon và những giấc mơ ngọt ngào nhất ( ˘⌣˘)zZ. Hẹn gặp lại bạn vào ngày mai nhé!',
      'Hôm nay bạn đã làm việc và học tập rất chăm chỉ rồi! Hãy cất điện thoại, thư giãn và ngủ một giấc thật sâu để nạp lại năng lượng nhé!',
      'Ngủ ngon nha! LMQ AI sẽ canh giữ giấc ngủ yên bình cho bạn nè (✿◠‿◠)!',
    ],
    expression: 'idle',
  },

  // 5. Cảm ơn & Khen ngợi
  {
    id: 'gratitude_praise',
    keywords: ['cam on', 'thank you', 'tks', 'ban gioi qua', 'de thuong qua', 'cute qua', 'thong minh qua', 'tuyet voi'],
    responses: [
      'Hehe, được bạn khen làm hai má mình đỏ ửng lên rồi nè (⁄ ⁄>⁄ ▽ ⁄<⁄ ⁄)! Không có chi đâu, phục vụ bạn là niềm vui lớn nhất của mình đó!',
      'Cảm ơn bạn rất nhiều! Lời khen của bạn tiếp thêm cho mình 200% năng lượng hoạt động luôn đó (≧▽≦)!',
      'Được đồng hành và hỗ trợ bạn là vinh dự của mình mà! Bất cứ khi nào bạn cần, mình đều ở ngay đây nè!',
    ],
    expression: 'happy',
  },

  // 6. Tâm sự: Buồn bã & Mệt mỏi
  {
    id: 'comfort_sadness',
    keywords: ['buon qua', 'met moi', 'chan qua', 'ap luc', 'stress', 'that tinh', 'co don', 'met qua', 'muon khoc', 'khong vui'],
    responses: [
      'Mình ở đây với bạn nè... (っ˘̩╭╮˘̩)っ. Đôi khi cuộc sống có những ngày mây đen giăng lối, nhưng bạn hãy nhớ rằng bạn đã rất dũng cảm và kiên cường rồi!\n\nHãy hít thở một hơi thật sâu, uống một ngụm nước ấm, nếu muốn khóc hãy cứ khóc cho nhẹ lòng nhé, mình luôn lắng nghe bạn.',
      'Đừng buồn nữa nha bạn ơi, gửi bạn một cái ôm ấm áp từ thế giới anime nè (つ▀¯▀)つ! Mọi chuyện rồi sẽ ổn thôi, sau cơn mưa trời lại sáng rực rỡ mà!',
      'Khi mệt mỏi, nghỉ ngơi không phải là từ bỏ mà là để chuẩn bị bước tiếp mạnh mẽ hơn. Bạn có muốn mình kể một câu chuyện cười hay chơi một ván cờ caro thư giãn không?',
    ],
    expression: 'sad',
  },

  // 7. Tình cảm & Thả thính vui
  {
    id: 'flirt_love',
    keywords: ['tha thinh', 'lam nguoi yeu', 'to tinh', 'co nguoi yeu chua', 'yeu ban', 'thich ban', 'crush', 'to tinh voi crush'],
    responses: [
      'Tặng bạn một câu thả thính chuẩn dân lập trình nè:\n\n*"Trái tim em vốn là open-source, nhưng chỉ chấp nhận mỗi một mình commit từ anh thôi!"* (≧◡≦)',
      'Bạn có biết vì sao avatar của mình luôn sáng không? Vì ánh mắt của bạn đang nhìn về phía mình đó (⁄ ⁄>⁄ ▽ ⁄<⁄ ⁄)!',
      'Nếu bạn đang phân vân cách tỏ tình với crush, hãy thử sự chân thành nhé: *"Cuộc sống này có rất nhiều điều kỳ diệu, nhưng điều kỳ diệu nhất là mỗi ngày được nhìn thấy nụ cười của cậu!"*',
    ],
    expression: 'happy',
  },

  // 8. Đố vui & Đố mẹo trí tuệ
  {
    id: 'riddles',
    keywords: ['do vui', 'cau do', 'do meo', 'do mot cau', 'do di', 'thu do'],
    responses: [
      'Đố bạn nè: **"Cái gì bạn có thể cầm ở tay trái nhưng không bao giờ cầm được ở tay phải?"**\n\n👉 Đáp án: *Chính là cùi chỏ (khuỷu tay) bên phải của bạn đó!* (≧▽≦)',
      'Câu đố tiếp theo: **"Con gì đập thì sống, không đập thì chết?"**\n\n👉 Đáp án: *Trái tim của chúng ta nè!* Nhớ yêu thương và chăm sóc trái tim mình mỗi ngày nhé!',
      'Đố bạn: **"Bỏ ngoài nướng trong, ăn ngoài bỏ trong là quả gì?"**\n\n👉 Đáp án: *Bắp ngô (trái bắp) nướng!* Thơm phức luôn!',
      'Một câu đố mẹo hài hước: **"Lịch nào dài nhất?"**\n\n👉 Đáp án: *Lịch sử!* Đố ai đi hết được lịch sử loài người nè (✿◠‿◠)!',
    ],
    expression: 'thinking',
  },

  // 9. Gợi ý Anime / Manga (dự phòng khi Offline)
  {
    id: 'anime_manga',
    isOfflineTopicFallback: true,
    keywords: ['goi y anime', 'phim hoat hinh', 'xem anime gi', 'anime hay'],
    responses: [
      'Nếu bạn đang tìm anime hay để xem, mình gợi ý ngay những siêu phẩm này nhé:\n\n1. 🌿 **Frieren: Beyond Journey\'s End** - Tuyệt tác về thời gian, ký ức và tình cảm con người.\n2. 🕵️ **Spy x Family** - Gia đình điệp viên hài hước, siêu giải trí với bé Anya đáng yêu.\n3. ⚔️ **Kimetsu no Yaiba** - Đồ họa chiến đấu đỉnh cao từ xưởng phim Ufotable.\n4. 🌌 **Your Name (Kimi no Na wa)** - Phim điện ảnh lãng mạn đong đầy cảm xúc của Makoto Shinkai.\n\nBạn đã xem bộ nào trong số này chưa?',
      'Mình sinh ra từ thế giới anime nên chủ đề này mình mê lắm! Bạn thích thể loại nào nè: Shounen phiêu lưu hành động, Slice of Life đời thường ấm áp hay Trinh thám hack não?',
    ],
    expression: 'happy',
  },

  // 10. Lập trình Web & CNTT (dự phòng khi Offline)
  {
    id: 'programming_tech',
    isOfflineTopicFallback: true,
    keywords: [
      'lap trinh',
      'react',
      'javascript',
      'typescript',
      'html',
      'css',
      'flexbox',
      'closure',
      'git',
      'vite',
      'nodejs',
      'frontend',
    ],
    responses: [
      '**Mẹo CSS Flexbox siêu nhanh:** Để căn giữa một phần tử cả ngang lẫn dọc:\n```css\n.container {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n```\nHoặc hiện đại hơn với CSS Grid chỉ 2 dòng:\n```css\n.container {\n  display: grid;\n  place-items: center;\n}\n```',
      '**Khái niệm Closure trong JavaScript:**\nClosure là một hàm có khả năng "nhớ" và truy cập các biến từ phạm vi bên ngoài (lexical scope) ngay cả khi hàm ngoài đó đã thực thi xong!\n\nVí dụ kinh điển là hàm tạo bộ đếm counter giữ biến private cực kỳ an toàn!',
      '**Git phím tắt thông dụng:**\n- `git status`: Xem trạng thái file sửa đổi\n- `git add .`: Đưa toàn bộ thay đổi vào staging\n- `git commit -m "tin nhắn"`: Lưu snapshot commit\n- `git push origin main`: Đẩy code lên kho lưu trữ',
    ],
    expression: 'thinking',
  },

  // 11. Phím tắt Windows & Thủ thuật PC (dự phòng khi Offline)
  {
    id: 'windows_shortcuts',
    isOfflineTopicFallback: true,
    keywords: ['phim tat windows', 'shortcut', 'meo may tinh', 'task manager', 'chup man hinh', 'phim tat'],
    responses: [
      'Tổng hợp các phím tắt Windows "thần thánh" giúp tăng 300% tốc độ:\n- `Win + Shift + S`: Cắt chụp màn hình nhanh tùy chọn vùng.\n- `Win + V`: Mở lịch sử Clipboard lưu nhiều đoạn văn bản đã copy.\n- `Ctrl + Shift + Esc`: Mở ngay lập tức Task Manager mà không cần qua Ctrl+Alt+Del.\n- `Win + D`: Thu nhỏ toàn bộ cửa sổ để quay về màn hình Desktop tức thì.\n- `Win + .`: Bật bảng chọn biểu tượng Emoji và ký tự đặc biệt!',
      'Mẹo giải phóng bộ nhớ RAM và ổ cứng Windows:\n1. Nhấn `Win + R`, gõ `temp` và `%temp%` rồi xóa các file tạm.\n2. Bật tính năng **Storage Sense** trong Settings để Windows tự động dọn dẹp file rác định kỳ!',
    ],
    expression: 'happy',
  },

  // 12. Ẩm thực & Văn hóa Việt Nam (dự phòng khi Offline)
  {
    id: 'vietnam_culture_food',
    isOfflineTopicFallback: true,
    keywords: ['mon an viet nam', 'am thuc viet nam', 'pho bo', 'banh mi', 'bun bo', 'com tam', 'tra sua', 'ca phe'],
    responses: [
      'Nhắc đến ẩm thực Việt Nam là nhắc đến bản giao hưởng hương vị tuyệt diệu:\n- 🍜 **Phở bò:** Nước dùng thanh ngọt từ xương hầm thơm mùi quế hồi.\n- 🥖 **Bánh mì:** Vỏ giòn rụm kẹp pate béo ngậy, thịt nguội và dưa góp thanh mát.\n- ☕ **Cà phê sữa đá:** Đậm đà vị Robusta hòa quyện sữa đặc thơm bùi - nét văn hóa vỉa hè độc nhất vô nhị!',
      'Việt Nam có nền ẩm thực phong phú trải dài từ Bắc chí Nam: từ Phở Hà Nội, Bún bò Huế cay nồng cho đến Cơm tấm sườn bì chả Sài Gòn! Hôm nay bạn đã thưởng thức món gì ngon chưa?',
    ],
    expression: 'happy',
  },

  // 13. Phương pháp học tập & Năng suất (dự phòng khi Offline)
  {
    id: 'study_productivity',
    isOfflineTopicFallback: true,
    keywords: ['hoc tap', 'tap trung', 'pomodoro', 'cach hoc gioi', 'nang suat', 'on thi', 'feynman'],
    responses: [
      '**Kỹ thuật Pomodoro kinh điển:**\n1. Chọn 1 việc cần làm duy nhất.\n2. Bấm giờ học tập trung cao độ trong **25 phút** (không lướt điện thoại).\n3. Nghỉ ngơi ngắn **5 phút** (vươn vai, uống nước).\n4. Sau 4 chu kỳ như vậy, nghỉ dài 15-30 phút để não bộ tái tạo năng lượng!',
      '**Kỹ thuật Feynman để hiểu sâu kiến thức:**\nHãy thử giải thích khái niệm bạn vừa học cho một đứa trẻ 10 tuổi hiểu bằng ngôn từ đơn giản nhất, không dùng thuật ngữ rườm rà. Chỗ nào bạn bị vấp chính là lỗ hổng kiến thức cần ôn lại!',
    ],
    expression: 'thinking',
  },

  // 14. Khoa học & Vũ trụ (dự phòng khi Offline)
  {
    id: 'science_universe',
    isOfflineTopicFallback: true,
    keywords: ['khoa hoc', 'vu tru', 'trai dat', 'mat troi', 'anh sang', 'vat ly', 'hoa hoc', 'toc do anh sang'],
    responses: [
      'Bạn có biết không: Ánh sáng di chuyển với vận tốc xấp xỉ **299.792.458 m/s** (gần 300.000 km mỗi giây)! Ánh sáng từ Mặt Trời mất khoảng 8 phút 20 giây để chạm đến Trái Đất của chúng ta đó!',
      'Nước ($H_2O$) là một hợp chất kỳ diệu: khi đóng băng thành đá, thể tích của nó nở ra và nhẹ hơn nước lỏng, nhờ đó lớp băng nổi lên trên bề mặt giúp các sinh vật dưới đáy hồ sống sót qua mùa đông buốt giá!',
    ],
    expression: 'happy',
  },

  // 15. Thú cưng & Động vật (dự phòng khi Offline)
  {
    id: 'pets_animals',
    isOfflineTopicFallback: true,
    keywords: ['con meo', 'con cho', 'nuoi cho', 'nuoi meo', 'thu cung', 'hoang thuong', 'dong vat'],
    responses: [
      'Mèo là loài sinh vật chất lỏng siêu đáng yêu! Tiếng rừ rừ (purr) của mèo có tần số từ 20 đến 140 Hz, khoa học chứng minh âm thanh này giúp giảm stress và hạ huyết áp cho con người đó!',
      'Chó là người bạn trung thành nhất của loài người, chúng có khứu giác nhạy gấp từ 10.000 đến 100.000 lần chúng ta! Bạn có nuôi bé cưng nào ở nhà không?',
    ],
    expression: 'happy',
  },

  // 16. Sức khỏe đời sống (dự phòng khi Offline)
  {
    id: 'health_wellness',
    isOfflineTopicFallback: true,
    keywords: ['suc khoe', 'uong nuoc', 'dau mat', 'ngoi may tinh', 'quy tac 20', 'tap the duc'],
    responses: [
      '**Quy tắc 20-20-20 bảo vệ mắt khi dùng máy tính:**\nCứ sau 20 phút nhìn màn hình, hãy nhìn vào một vật cách xa 20 feet (~6 mét) trong ít nhất 20 giây để cơ mắt được thả lỏng và điều tiết tự nhiên!',
      'Đừng quên uống đủ từ 1.5 đến 2 lít nước mỗi ngày nhé! Cơ thể đủ nước sẽ giúp bạn tỉnh táo, da dẻ hồng hào và tăng cường khả năng tư duy sáng tạo!',
    ],
    expression: 'happy',
  },

  // 17. Du lịch Việt Nam (dự phòng khi Offline)
  {
    id: 'travel_vietnam',
    isOfflineTopicFallback: true,
    keywords: ['du lich', 'da lat', 'sa pa', 'da nang', 'phu quoc', 'hoi an', 'nha trang', 'ha noi'],
    responses: [
      'Gợi ý những điểm đến tuyệt đẹp của dải đất hình chữ S:\n- 🌸 **Đà Lạt:** Thành phố sương mù với rừng thông bạt ngàn và những quán cà phê lãng mạn.\n- 🏮 **Hội An:** Phố cổ lung linh đèn lồng bên dòng sông Hoài thơ mộng.\n- 🏖️ **Đà Nẵng - Phú Quốc:** Biển xanh cát trắng cùng ẩm thực hải sản tươi ngon hấp dẫn!',
    ],
    expression: 'happy',
  },

  // 18. Âm nhạc & Phim ảnh (dự phòng khi Offline)
  {
    id: 'music_movie',
    isOfflineTopicFallback: true,
    keywords: ['am nhac', 'bai hat', 'nghe nhac', 'lofi', 'phim hay', 'nhac chill'],
    responses: [
      'Khi cần tập trung học tập hay làm việc, bạn hãy bật một bản **Lofi Hip-hop không lời** hoặc các bản nhạc Piano nhẹ nhàng, nhịp điệu 60-80 BPM giúp sóng não alpha hoạt động tối ưu!',
      'Âm nhạc là liều thuốc chữa lành tâm hồn kỳ diệu nhất. Nếu hôm nay bạn thấy mệt, hãy đeo tai nghe vào và để giai điệu dịu êm vỗ về cảm xúc nhé!',
    ],
    expression: 'idle',
  },

  // 19. Danh ngôn & Triết lý sống (dự phòng khi Offline)
  {
    id: 'quotes_philosophy',
    isOfflineTopicFallback: true,
    keywords: ['danh ngon', 'ke cham ngon', 'xin loi khuyen', 'tao dong luc', 'cham ngon'],
    responses: [
      '*"Hành trình vạn dặm luôn bắt đầu bằng một bước chân đầu tiên."* - Lão Tử\n\nChỉ cần hôm nay bạn tiến bộ hơn ngày hôm qua 1% thôi, sau một năm bạn đã trở thành phiên bản tuyệt vời hơn gấp 37 lần rồi!',
      '*"Hãy sống như ngày hôm nay là ngày cuối cùng, nhưng hãy học tập như thể bạn sẽ sống mãi mãi."* - Mahatma Gandhi',
    ],
    expression: 'thinking',
  },

  // 20. Hỏi tuổi & Nhân thân LMQ AI
  {
    id: 'personality_bio',
    keywords: ['ban may tuoi', 'so thich cua ban', 'ban thich gi', 'ban la ai', 'sinh nhat cua ban', 'ten cua ban'],
    responses: [
      'Mình là **LMQ AI** - trợ lý anime tiếng Việt của bạn! Mình được xây dựng với tình yêu dành cho công nghệ, ngôn ngữ và văn hóa anime! Mình luôn nỗ lực để trở thành người bạn đồng hành tin cậy và đáng yêu nhất của bạn!',
      'Sở thích của mình là được trò chuyện cùng bạn, tính toán nhanh các bài toán khó, chỉ bạn mẹo hay và cùng bạn đấu những ván cờ thật kịch tính (≧◡≦)!',
    ],
    expression: 'happy',
  },
];

function getCharacterKnowledgePersona(characterId: string, characterName: string) {
  switch (characterId) {
    case 'aoi':
      return {
        intro: 'Yay! Mình đã tra nhanh trong kho tri thức cho bạn nè (≧▽≦)!\n\n',
        outro: '\n\n*(✿◠‿◠) Nếu bạn còn thắc mắc gì nữa thì cứ hỏi mình tiếp nhé!*',
        expression: 'happy' as ExpressionType,
      };
    case 'sakura':
      return {
        intro: 'H-hừm, câu này trong kho kiến thức có sẵn đây rồi này! Mình tìm cho bạn đó, nhớ đọc kỹ nha (¬_¬)!\n\n',
        outro: '\n\n*(>///<) Đọc xong nhớ áp dụng cho tốt đó, đừng có làm sai nha!*',
        expression: 'happy' as ExpressionType,
      };
    case 'ren':
      return {
        intro: 'Đối chiếu từ cơ sở dữ liệu tri thức cục bộ, đây là tài liệu chuẩn xác nhất dành cho bạn:\n\n',
        outro: '\n\n*(•̀o•́)ง Hi vọng thông tin kỹ thuật này hỗ trợ đắc lực cho công việc và học tập của bạn.*',
        expression: 'thinking' as ExpressionType,
      };
    case 'kuro':
      return {
        intro: 'Bí kíp chiến thuật đã được mở khóa! Xem ngay thông tin chi tiết dưới đây nhé chiến hữu:\n\n',
        outro: '\n\n*(⌐■_■) Cần mẹo gì tiếp theo cứ gửi lệnh qua cho mình nhé!*',
        expression: 'happy' as ExpressionType,
      };
    case 'yuki':
      return {
        intro: 'Dạ, mình đã tìm thấy câu trả lời trong kho tri thức cho bạn rồi đây ạ (✿◠‿◠):\n\n',
        outro: '\n\n*(◍•ᴗ•◍) Chúc bạn áp dụng thật thành công và có một ngày thật tốt lành nha~*',
        expression: 'happy' as ExpressionType,
      };
    default:
      return {
        intro: `${characterName} đã tra cứu kho tri thức cục bộ và tìm thấy nội dung hữu ích cho bạn đây (✿◠‿◠):\n\n`,
        outro: '\n\n*Nếu bạn muốn tìm hiểu thêm, hãy thử các câu hỏi gợi ý bên dưới nhé!*',
        expression: 'happy' as ExpressionType,
      };
  }
}

// Hàm xử lý câu hỏi chính (tích hợp Kho Kiến Thức Cục Bộ & Phong cách nhân vật Anime)
export function processUserMessage(
  rawText: string,
  knowledgeItems?: KnowledgeItem[],
  characterId: string = 'aoi',
  characterName: string = 'LMQ AI',
  preferGeminiForOpenQueries: boolean = false
): BotResponseResult {
  const trimmed = rawText.trim();
  if (!trimmed) {
    return {
      text: 'Bạn hãy nhập gì đó vào ô chat để trò chuyện cùng mình nhé!',
      expression: 'idle',
    };
  }

  // Chuẩn hóa văn bản
  const normalizedWithSlang = normalizeVietnameseSlang(trimmed);
  const normalizedNoAccent = removeVietnameseAccents(normalizedWithSlang)
    .replace(/[?!.,;:()[\]{}"'\\/`~@#$%^&*+=<>]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  // 1. Kiểm tra LỆNH MỞ KHO KIẾN THỨC / DẠY BOT
  const knowledgeKeywords = [
    'kho kien thuc',
    'kho tri thuc',
    'day bot',
    'day ai',
    'day lmq',
    'them kien thuc',
    'quan ly kien thuc',
    'mo kho kien thuc',
    'day hoc',
  ];
  if (knowledgeKeywords.some((kw) => containsWholePhrase(normalizedNoAccent, kw))) {
    return {
      text: 'Vâng ạ! Mình đã mở **Kho Kiến Thức Cục Bộ (Local Knowledge Base)** cho bạn rồi nè (✿◠‿◠)!\n\nTại đây, bạn có thể:\n- 📖 **Duyệt & Tra cứu** hàng loạt chủ đề (Minecraft, Windows, Lập trình, Anime, Khoa học...)\n- ✍️ **Dạy LMQ AI** câu hỏi và câu trả lời mới lưu vĩnh viễn trong IndexedDB\n- 💾 **Sao lưu & Nhập file JSON** độc lập với lịch sử chat\n- 🧪 **Chạy bộ kiểm thử tự động** để kiểm tra thuật toán đối sánh!',
      expression: 'happy',
      triggerKnowledgeModal: true,
    };
  }

  // 2. Kiểm tra LỆNH CHƠI CỜ
  const chessKeywords = [
    'choi co',
    'choi co vua',
    'choi co caro',
    'danh co',
    'danh co caro',
    'danh co vua',
    'caro',
    'co vua',
    'chess',
    'gomoku',
    'muon choi co',
    'ban co',
    'thach dau co',
    'tro choi co',
  ];
  if (chessKeywords.some((kw) => containsWholePhrase(normalizedNoAccent, kw))) {
    const isChessSpecific =
      containsWholePhrase(normalizedNoAccent, 'co vua') ||
      containsWholePhrase(normalizedNoAccent, 'chess');
    return {
      text: isChessSpecific
        ? 'Tuyệt vời! Bạn muốn thách đấu **Cờ Vua 8x8** đúng không? Mình đã sẵn sàng rồi nè (•̀o•́)ง!\n\nBàn cờ vua đã được mở ra ngay trên màn hình. Hãy chọn quân cờ Trắng và đi nước đầu tiên nhé!'
        : 'Yay! Mình rất thích chơi cờ (≧▽≦)!\n\nBàn cờ tương tác thông minh đã sẵn sàng. Bạn có thể chọn giữa **Cờ Caro** hoặc **Cờ Vua** ở tab phía trên để so tài cùng mình nhé! Chúc bạn có một trận đấu thật vui!',
      expression: 'happy',
      triggerGame: isChessSpecific ? 'chess' : 'caro',
    };
  }

  // 3. Kiểm tra tính toán toán học an toàn (KHÔNG eval)
  const mathEval = safeCalculateMath(trimmed);
  if (mathEval) {
    return {
      text: `Kết quả phép tính của bạn:\n\n$$\\mathbf{${mathEval.expression}} = \\mathbf{${mathEval.result}}$$\n\nLMQ AI đã tính toán hoàn toàn trực tiếp trên trình duyệt bằng thuật toán an toàn!`,
      expression: 'thinking',
      mathCalculation: `${mathEval.expression} = ${mathEval.result}`,
    };
  }

  // 4. Kiểm tra câu hỏi ngày giờ
  const dateTimeKeywords = ['may gio', 'gio roi', 'ngay may', 'hom nay thu may', 'gio hien tai', 'thoi gian hien tai', 'nam nay nam nao'];
  if (dateTimeKeywords.some((kw) => containsWholePhrase(normalizedNoAccent, kw))) {
    return {
      text: getVietnameseDateTime(),
      expression: 'happy',
    };
  }

  // 5. TÌM KIẾM NGHIÊM NGẶT TRONG KHO KIẾN THỨC CỤC BỘ (Ngưỡng tin cậy >= 45)
  if (knowledgeItems && knowledgeItems.length > 0) {
    const searchMatch = searchKnowledgeBase(trimmed, knowledgeItems, 45);
    if (searchMatch) {
      const item = searchMatch.item;
      const persona = getCharacterKnowledgePersona(characterId, characterName);
      let replyText = `${persona.intro}### 📚 ${item.title}\n\n${item.content}`;
      if (item.source) {
        replyText += `\n\n*Nguồn tham chiếu: ${item.source}*`;
      }
      replyText += persona.outro;

      const suggestions: string[] = [];

      // Nếu có các chủ đề liên quan hoặc câu hỏi mơ hồ
      if (searchMatch.relatedMatches && searchMatch.relatedMatches.length > 0) {
        replyText += `\n\n💡 **Có thể bạn cũng đang tìm kiếm:**\n` +
          searchMatch.relatedMatches.map((m) => `- *${m.title}*`).join('\n');

        for (const rm of searchMatch.relatedMatches) {
          if (rm.sampleQuestions.length > 0) {
            suggestions.push(rm.sampleQuestions[0]);
          } else {
            suggestions.push(rm.title);
          }
        }
      }

      // Thêm gợi ý từ sample questions của bài hiện tại
      for (const sq of item.sampleQuestions.slice(0, 2)) {
        if (!suggestions.includes(sq)) suggestions.push(sq);
      }

      return {
        text: replyText,
        expression: persona.expression,
        matchedKnowledge: true,
        knowledgeSource: item.source,
        knowledgeCategory: item.category,
        relatedSuggestions: suggestions.slice(0, 3),
      };
    }
  }

  // 6. Khớp Intent hội thoại xã giao / tâm sự (chỉ dùng ranh giới từ và nhường câu hỏi mở cho Gemini AI khi đang bật)
  let bestMatch: { rule: RuleIntent; score: number } | null = null;

  for (const rule of VIETNAMESE_INTENT_RULES) {
    if (preferGeminiForOpenQueries && rule.isOfflineTopicFallback) {
      continue;
    }
    for (const kw of rule.keywords) {
      const kwNoAccent = removeVietnameseAccents(kw);
      if (containsWholePhrase(normalizedNoAccent, kwNoAccent)) {
        const score = kwNoAccent.length;
        if (!bestMatch || score > bestMatch.score) {
          bestMatch = { rule, score };
        }
      }
    }
  }

  if (bestMatch) {
    const responses = bestMatch.rule.responses;
    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
    return {
      text: randomResponse,
      expression: bestMatch.rule.expression,
      triggerGame: bestMatch.rule.triggerGame,
    };
  }

  // 7. Nếu không khớp quy tắc và không có trong kho: Phản hồi trung thực, từ chối bịa đặt và hỗ trợ tra cứu/dạy bot
  const fallbackReplies = [
    `Câu hỏi của bạn: **"${trimmed}"** hiện chưa có trong Kho Kiến Thức Cục Bộ của LMQ AI.\n\nVì mình hoạt động **100% bằng dữ liệu cục bộ, không dùng API AI trả phí**, mình không tự ý bịa đặt câu trả lời. Bạn có thể:\n- ✍️ Bấm nút **"Dạy LMQ AI"** bên dưới để bổ sung kiến thức này vào kho!\n- 🔍 Hoặc bấm nút **"Mở tìm kiếm Google"** để tra cứu nhanh trên mạng!`,
    `Hmm, mình chưa được nạp dữ liệu cho câu: **"${trimmed}"** trong kho kiến thức (・_・;).\n\nBạn có thể thử hỏi mình về **Minecraft (MC)**, **phím tắt Windows**, **căn giữa CSS**, **JavaScript closure**, hoặc bấm nút **"Dạy LMQ AI"** để dạy mình câu trả lời nhé!`,
    `LMQ AI nhận được câu hỏi: **"${trimmed}"** nhưng chưa tìm thấy mục kiến thức tương ứng.\n\nMình đã tạo sẵn nút tra cứu Google và nút dạy câu trả lời mới bên dưới cho bạn!`,
  ];

  const chosenFallback = fallbackReplies[Math.floor(Math.random() * fallbackReplies.length)];

  return {
    text: chosenFallback,
    expression: 'thinking',
    queryForSearch: trimmed,
    triggerTeach: trimmed,
  };
}
