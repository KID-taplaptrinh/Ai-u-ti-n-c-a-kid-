import { KnowledgeItem } from '../types/knowledge';
import { DEFAULT_KNOWLEDGE_BASE } from '../data/defaultKnowledge';
import { searchKnowledgeBase, scoreKnowledgeItem } from './knowledgeSearch';
import {
  saveKnowledgeItem,
  deleteKnowledgeItem,
  importKnowledgeFromJSON,
  exportKnowledgeToJSON,
  getCustomKnowledgeItems,
} from './knowledgeStorage';

export interface TestResult {
  id: string;
  name: string;
  category: string;
  passed: boolean;
  message: string;
  details?: string;
  durationMs: number;
}

export async function runAllKnowledgeTests(): Promise<{
  total: number;
  passedCount: number;
  failedCount: number;
  results: TestResult[];
}> {
  const results: TestResult[] = [];
  const testItems = [...DEFAULT_KNOWLEDGE_BASE];

  // Test 1: Câu hỏi CÓ DẤU và KHÔNG DẤU đều tìm ra cùng một mục kiến thức
  {
    const start = performance.now();
    const queryAccented = 'Cách chế tạo bàn phù phép trong minecraft';
    const queryUnaccented = 'cach che tao ban phu phep trong minecraft';

    const res1 = searchKnowledgeBase(queryAccented, testItems);
    const res2 = searchKnowledgeBase(queryUnaccented, testItems);

    const passed =
      res1 !== null &&
      res2 !== null &&
      res1.item.id === 'mc-enchanting-table' &&
      res2.item.id === 'mc-enchanting-table';

    results.push({
      id: 'test-1-accents',
      name: 'Kiểm thử câu hỏi có dấu và không dấu',
      category: 'Chuẩn hóa tiếng Việt',
      passed,
      message: passed
        ? 'Cả câu hỏi có dấu và không dấu đều trả về chính xác "Bàn Phù Phép Minecraft"'
        : `Thất bại: res1=${res1?.item.id}, res2=${res2?.item.id}`,
      details: `Có dấu (Score: ${res1?.score}) · Không dấu (Score: ${res2?.score})`,
      durationMs: Math.round(performance.now() - start),
    });
  }

  // Test 2: Câu hỏi dùng TEENCODE thông dụng của giới trẻ Việt
  {
    const start = performance.now();
    const queryTeencode = 'lam enchanting table trong mc ntn mik ko bt';
    const res = searchKnowledgeBase(queryTeencode, testItems);
    const passed = res !== null && res.item.id === 'mc-enchanting-table';

    results.push({
      id: 'test-2-teencode',
      name: 'Kiểm thử câu hỏi dùng Teencode và từ viết tắt (mc, ntn, mik, ko, bt)',
      category: 'Xử lý tiếng lóng & từ viết tắt',
      passed,
      message: passed
        ? 'Nhận diện chuẩn xác teencode "mc, ntn, mik, ko, bt" khớp với Bàn Phù Phép'
        : `Thất bại: kết quả trả về ${res?.item.id || 'null'}`,
      details: `Câu hỏi: "${queryTeencode}" -> Điểm số: ${res?.score || 0}`,
      durationMs: Math.round(performance.now() - start),
    });
  }

  // Test 3: Một câu hỏi được diễn đạt theo nhiều cách khác nhau
  {
    const start = performance.now();
    const variations = [
      'Minecraft chế tạo bàn phù phép như nào',
      'làm enchanting table trong MC ra sao',
      'cần nguyên liệu gì để tạo bàn phù phép',
    ];

    let allPassed = true;
    const scores: number[] = [];

    for (const v of variations) {
      const match = searchKnowledgeBase(v, testItems);
      if (!match || match.item.id !== 'mc-enchanting-table') {
        allPassed = false;
      }
      scores.push(match?.score || 0);
    }

    results.push({
      id: 'test-3-variations',
      name: 'Kiểm thử các cách diễn đạt khác nhau cùng một ý nghĩa',
      category: 'Đối sánh ngữ nghĩa',
      passed: allPassed,
      message: allPassed
        ? 'Cả 3 biến thể câu hỏi khác nhau đều tìm đúng "Bàn Phù Phép"'
        : 'Có biến thể không tìm ra mục tương ứng',
      details: `Điểm số tương ứng: ${scores.join('đ, ')}đ`,
      durationMs: Math.round(performance.now() - start),
    });
  }

  // Test 4: Nhiều mục kiến thức có từ khóa tương đồng (phân biệt chính xác)
  {
    const start = performance.now();
    const query1 = 'cách xây cổng địa ngục nether portal';
    const query2 = 'tọa độ đào kim cương diamond mc';

    const res1 = searchKnowledgeBase(query1, testItems);
    const res2 = searchKnowledgeBase(query2, testItems);

    const passed =
      res1?.item.id === 'mc-nether-portal' && res2?.item.id === 'mc-find-diamond';

    results.push({
      id: 'test-4-disambiguation',
      name: 'Kiểm thử phân biệt giữa các mục có từ khóa Minecraft giống nhau',
      category: 'Xếp hạng & Trọng số',
      passed,
      message: passed
        ? 'Phân biệt chính xác giữa Cổng Địa Ngục (Nether Portal) và Tọa độ Kim Cương'
        : 'Nhầm lẫn giữa các bài viết có từ khóa tương đồng',
      details: `Query 1 -> ${res1?.item.title.slice(0, 30)}... | Query 2 -> ${res2?.item.title.slice(0, 30)}...`,
      durationMs: Math.round(performance.now() - start),
    });
  }

  // Test 5: Câu hỏi chưa có trong kho dữ liệu (Thừa nhận và không bịa đặt)
  {
    const start = performance.now();
    const unknownQuery = 'Ai là người phát minh ra tàu vũ trụ chở người lên sao Diêm Vương năm 1820';
    const res = searchKnowledgeBase(unknownQuery, testItems, 35);
    const passed = res === null;

    results.push({
      id: 'test-5-unknown',
      name: 'Kiểm thử câu hỏi ngoài kho dữ liệu (Chống bịa đặt)',
      category: 'Tính trung thực & Ngưỡng tin cậy',
      passed,
      message: passed
        ? 'Hệ thống trả về null an toàn, thừa nhận chưa có dữ liệu và kích hoạt tìm kiếm Google'
        : `Cảnh báo: Trả về kết quả không liên quan (ID: ${res?.item.id})`,
      details: `Ngưỡng tin cậy tối thiểu = 35đ`,
      durationMs: Math.round(performance.now() - start),
    });
  }

  // Test 6: Thêm, sửa, xóa kiến thức trong IndexedDB
  {
    const start = performance.now();
    let passed = false;
    let message = '';
    const tempId = `test-temp-${Date.now()}`;

    try {
      const newItem: KnowledgeItem = {
        id: tempId,
        category: 'custom',
        title: 'Thử nghiệm Kiến thức Tự động',
        content: 'Nội dung kiểm tra lưu trữ IndexedDB',
        keywords: ['kiem thu', 'test item'],
        synonyms: ['test unit'],
        sampleQuestions: ['đây là bài test phải không'],
        verified: true,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };

      // 1. Thêm
      await saveKnowledgeItem(newItem);
      let customList = await getCustomKnowledgeItems();
      const added = customList.some((i) => i.id === tempId);

      // 2. Sửa
      newItem.title = 'Thử nghiệm Đã Cập Nhật';
      await saveKnowledgeItem(newItem);
      customList = await getCustomKnowledgeItems();
      const updated = customList.find((i) => i.id === tempId)?.title === 'Thử nghiệm Đã Cập Nhật';

      // 3. Xóa
      await deleteKnowledgeItem(tempId);
      customList = await getCustomKnowledgeItems();
      const deleted = !customList.some((i) => i.id === tempId);

      passed = added && updated && deleted;
      message = passed
        ? 'Quy trình Thêm -> Cập nhật -> Xóa trên IndexedDB hoạt động hoàn hảo'
        : `Lỗi: added=${added}, updated=${updated}, deleted=${deleted}`;
    } catch (e: any) {
      message = `Lỗi thực thi IndexedDB: ${e.message}`;
    }

    results.push({
      id: 'test-6-crud-storage',
      name: 'Kiểm thử quy trình CRUD (Thêm, Sửa, Xóa) trên IndexedDB',
      category: 'Lưu trữ bền vững',
      passed,
      message,
      details: `Kiểm tra giao dịch đọc/ghi IndexedDB`,
      durationMs: Math.round(performance.now() - start),
    });
  }

  // Test 7: Xuất và Nhập JSON hợp lệ
  {
    const start = performance.now();
    let passed = false;
    let message = '';

    try {
      const exportedJson = await exportKnowledgeToJSON();
      const parsed = JSON.parse(exportedJson);
      const isExportValid =
        typeof parsed === 'object' &&
        Array.isArray(parsed.items) &&
        parsed.items.length >= DEFAULT_KNOWLEDGE_BASE.length;

      const testImportPayload = JSON.stringify({
        version: '2.0.0',
        items: [
          {
            id: `import-sample-${Date.now()}`,
            category: 'programming',
            title: 'Mẫu Nhập File JSON',
            content: 'Nội dung import thử nghiệm',
            keywords: ['import json'],
            synonyms: [],
            sampleQuestions: ['test import'],
            verified: true,
          },
        ],
      });

      const importResult = await importKnowledgeFromJSON(testImportPayload);

      passed = isExportValid && importResult.success && importResult.count === 1;
      message = passed
        ? 'Xuất dữ liệu chuẩn Schema và Nhập JSON thành công'
        : `Lỗi: exportValid=${isExportValid}, importSuccess=${importResult.success}`;

      // Xóa mục tạm đã import
      if (importResult.success) {
        const custom = await getCustomKnowledgeItems();
        const found = custom.find((i) => i.title === 'Mẫu Nhập File JSON');
        if (found) await deleteKnowledgeItem(found.id);
      }
    } catch (e: any) {
      message = `Lỗi JSON: ${e.message}`;
    }

    results.push({
      id: 'test-7-json-backup',
      name: 'Kiểm thử Sao lưu (Export) và Khôi phục (Import) tệp JSON',
      category: 'Sao lưu & Phục hồi',
      passed,
      message,
      details: `Xác thực Schema JSON`,
      durationMs: Math.round(performance.now() - start),
    });
  }

  // Test 8: Nhập JSON lỗi hoặc dữ liệu rỗng (Bảo vệ an toàn hệ thống)
  {
    const start = performance.now();
    const invalidJson1 = '{"malformed_json: 123';
    const invalidJson2 = '{"items": []}';

    const res1 = await importKnowledgeFromJSON(invalidJson1);
    const res2 = await importKnowledgeFromJSON(invalidJson2);

    const passed = !res1.success && !res2.success;

    results.push({
      id: 'test-8-invalid-json',
      name: 'Kiểm thử xử lý JSON không hợp lệ và mảng rỗng',
      category: 'Khả năng phục hồi & Xử lý lỗi',
      passed,
      message: passed
        ? 'Hệ thống bắt lỗi cú pháp an toàn, không gây crash ứng dụng'
        : 'Không bắt được ngoại lệ JSON lỗi',
      details: `res1=${res1.error?.slice(0, 30)}...`,
      durationMs: Math.round(performance.now() - start),
    });
  }

  // Test 9: So khớp CSS căn giữa và JavaScript Closure
  {
    const start = performance.now();
    const queryCss = 'cách căn giữa một thẻ div bằng flexbox';
    const queryJs = 'khái niệm closure trong javascript là gì';

    const matchCss = searchKnowledgeBase(queryCss, testItems);
    const matchJs = searchKnowledgeBase(queryJs, testItems);

    const passed =
      matchCss?.item.id === 'css-center-div' && matchJs?.item.id === 'js-closure-concept';

    results.push({
      id: 'test-9-programming-queries',
      name: 'Kiểm thử câu hỏi kỹ thuật Lập trình Web (CSS & JavaScript)',
      category: 'Kiến thức Lập trình',
      passed,
      message: passed
        ? 'Tìm kiếm chính xác bài viết "Căn giữa thẻ div" và "Closure JS"'
        : 'Không tìm thấy bài viết lập trình tương ứng',
      details: `CSS: ${matchCss?.score}đ · JS: ${matchJs?.score}đ`,
      durationMs: Math.round(performance.now() - start),
    });
  }

  // Test 10: Phân biệt kho kiến thức với lịch sử chat (Không xóa lẫn nhau)
  {
    const start = performance.now();
    // Giả lập kiểm tra: Xóa lịch sử chat không chạm tới IndexedDB
    const chatKey = 'lmq_ai_chat_history_v2';
    const originalChat = localStorage.getItem(chatKey);

    localStorage.setItem(chatKey, JSON.stringify([{ id: 'test', text: 'hello' }]));
    localStorage.removeItem(chatKey); // Xóa chat

    const knowledgeItems = await getCustomKnowledgeItems();
    const passed = Array.isArray(knowledgeItems); // IndexedDB không bị ảnh hưởng

    if (originalChat) {
      localStorage.setItem(chatKey, originalChat);
    }

    results.push({
      id: 'test-10-separation',
      name: 'Kiểm thử tính độc lập giữa Kho kiến thức và Lịch sử trò chuyện',
      category: 'Kiến trúc dữ liệu',
      passed,
      message: passed
        ? 'Xóa lịch sử chat hoàn toàn không làm mất hay ảnh hưởng đến kho kiến thức'
        : 'Có sự phụ thuộc chéo giữa chat và kiến thức',
      details: `Chat lưu ở localStorage riêng · Kiến thức lưu IndexedDB độc lập`,
      durationMs: Math.round(performance.now() - start),
    });
  }

  // Test 11: Chống khớp nhầm câu hỏi mở ngoài chủ đề (ví dụ: "ý nghĩa của cuộc sống là gì")
  {
    const start = performance.now();
    const falsePositiveTraps = [
      'ý nghĩa của cuộc sống là gì',
      'làm sao để hạnh phúc mỗi ngày',
      'tại sao bầu trời lại có màu xanh',
    ];
    const falseMatches = falsePositiveTraps
      .map((q) => ({ q, res: searchKnowledgeBase(q, testItems, 45) }))
      .filter((entry) => entry.res !== null);

    const passed = falseMatches.length === 0;

    results.push({
      id: 'test-11-no-false-positives',
      name: 'Kiểm thử chống trả lời lạc đề với câu hỏi triết lý / câu hỏi mở',
      category: 'Độ chính xác & Định tuyến AI',
      passed,
      message: passed
        ? 'Các câu hỏi ngoài kho như "ý nghĩa của cuộc sống là gì" không bị khớp nhầm và được chuyển đúng cho Gemini AI'
        : `Phát hiện khớp nhầm: ${falseMatches.map((m) => `${m.q} -> ${m.res?.item.id} (${m.res?.score}đ)`).join('; ')}`,
      details: 'Kiểm tra lọc từ dừng mở rộng & ngưỡng tin cậy nghiêm ngặt (>= 45đ)',
      durationMs: Math.round(performance.now() - start),
    });
  }

  const passedCount = results.filter((r) => r.passed).length;
  const failedCount = results.length - passedCount;

  return {
    total: results.length,
    passedCount,
    failedCount,
    results,
  };
}
