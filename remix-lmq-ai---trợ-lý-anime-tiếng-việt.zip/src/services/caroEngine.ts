// Caro (Gomoku) Engine: Board generation, win checking, heuristic AI

export type CaroCell = 'X' | 'O' | null;
export type CaroBoard = CaroCell[][];

export const CARO_BOARD_SIZE = 12;

export interface CaroWinResult {
  winner: 'X' | 'O' | 'draw' | null;
  line?: [number, number][];
}

// Khởi tạo bàn cờ Caro rỗng
export function createEmptyCaroBoard(size: number = CARO_BOARD_SIZE): CaroBoard {
  const board: CaroBoard = [];
  for (let r = 0; r < size; r++) {
    board.push(new Array(size).fill(null));
  }
  return board;
}

// Kiểm tra thắng thua 5 quân thẳng hàng (ngang, dọc, 2 đường chéo)
export function checkCaroWin(board: CaroBoard, size: number = CARO_BOARD_SIZE): CaroWinResult {
  const directions = [
    [0, 1],  // Ngang
    [1, 0],  // Dọc
    [1, 1],  // Chéo chính
    [1, -1], // Chéo phụ
  ];

  let hasEmpty = false;

  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      const player = board[r][c];
      if (!player) {
        hasEmpty = true;
        continue;
      }

      for (const [dr, dc] of directions) {
        const line: [number, number][] = [[r, c]];
        let count = 1;

        for (let step = 1; step < 5; step++) {
          const nr = r + dr * step;
          const nc = c + dc * step;
          if (nr >= 0 && nr < size && nc >= 0 && nc < size && board[nr][nc] === player) {
            count++;
            line.push([nr, nc]);
          } else {
            break;
          }
        }

        if (count >= 5) {
          return { winner: player, line };
        }
      }
    }
  }

  if (!hasEmpty) {
    return { winner: 'draw' };
  }

  return { winner: null };
}

// Đánh giá điểm chuỗi quân cờ để AI lựa chọn nước đi tối ưu (Tấn công & Phòng thủ)
function evaluateDirection(
  board: CaroBoard,
  r: number,
  c: number,
  dr: number,
  dc: number,
  player: 'X' | 'O',
  size: number
): number {
  let count = 0;
  let openEnds = 0;

  // Đi về phía trước
  let step = 1;
  while (step <= 4) {
    const nr = r + dr * step;
    const nc = c + dc * step;
    if (nr < 0 || nr >= size || nc < 0 || nc >= size) break;
    if (board[nr][nc] === player) {
      count++;
      step++;
    } else if (board[nr][nc] === null) {
      openEnds++;
      break;
    } else {
      break;
    }
  }

  // Đi về phía sau
  step = 1;
  while (step <= 4) {
    const nr = r - dr * step;
    const nc = c - dc * step;
    if (nr < 0 || nr >= size || nc < 0 || nc >= size) break;
    if (board[nr][nc] === player) {
      count++;
      step++;
    } else if (board[nr][nc] === null) {
      openEnds++;
      break;
    } else {
      break;
    }
  }

  // Thang điểm đánh giá độ nguy hiểm / cơ hội
  if (count >= 4) return 100000; // 5 quân -> Thắng
  if (count === 3 && openEnds === 2) return 10000; // 4 mở 2 đầu -> Cực nguy hiểm
  if (count === 3 && openEnds === 1) return 1500;  // 4 chặn 1 đầu
  if (count === 2 && openEnds === 2) return 800;   // 3 mở 2 đầu
  if (count === 2 && openEnds === 1) return 150;   // 3 chặn 1 đầu
  if (count === 1 && openEnds === 2) return 50;    // 2 mở 2 đầu
  if (count === 1 && openEnds === 1) return 10;
  return 1;
}

// Thuật toán AI tính toán nước đi tốt nhất cho Bot (O)
export function getBestCaroMove(board: CaroBoard, size: number = CARO_BOARD_SIZE): [number, number] {
  let bestScore = -Infinity;
  let bestMoves: [number, number][] = [];

  const directions = [
    [0, 1],
    [1, 0],
    [1, 1],
    [1, -1],
  ];

  // Nếu bàn cờ còn trống hoặc mới đi 1 nước ở trung tâm
  let totalPieces = 0;
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (board[r][c] !== null) totalPieces++;
    }
  }

  if (totalPieces === 0) {
    const center = Math.floor(size / 2);
    return [center, center];
  }

  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (board[r][c] !== null) continue;

      // Chỉ xét các ô gần quân đã đánh trong bán kính 2 ô để tối ưu tốc độ
      let nearPiece = false;
      for (let dr = -2; dr <= 2 && !nearPiece; dr++) {
        for (let dc = -2; dc <= 2; dc++) {
          const nr = r + dr;
          const nc = c + dc;
          if (nr >= 0 && nr < size && nc >= 0 && nc < size && board[nr][nc] !== null) {
            nearPiece = true;
            break;
          }
        }
      }

      if (!nearPiece && totalPieces > 0) continue;

      // Điểm tấn công của Bot ('O')
      let attackScore = 0;
      for (const [dr, dc] of directions) {
        attackScore += evaluateDirection(board, r, c, dr, dc, 'O', size);
      }

      // Điểm phòng thủ (chặn người chơi 'X')
      let defenseScore = 0;
      for (const [dr, dc] of directions) {
        defenseScore += evaluateDirection(board, r, c, dr, dc, 'X', size);
      }

      // Hệ số: Ưu tiên chặn hiểm của người chơi và chớp thời cơ thắng
      const totalScore = attackScore * 1.15 + defenseScore;

      // Thưởng nhẹ cho các ô ở trung tâm bàn cờ
      const centerDist = Math.abs(r - size / 2) + Math.abs(c - size / 2);
      const positionBonus = (size - centerDist) * 2;

      const finalScore = totalScore + positionBonus;

      if (finalScore > bestScore) {
        bestScore = finalScore;
        bestMoves = [[r, c]];
      } else if (finalScore === bestScore) {
        bestMoves.push([r, c]);
      }
    }
  }

  if (bestMoves.length === 0) {
    // Trường hợp dự phòng nếu không tìm được ô lân cận
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        if (board[r][c] === null) return [r, c];
      }
    }
    return [0, 0];
  }

  // Chọn ngẫu nhiên trong nhóm các nước đi có điểm tối ưu bằng nhau
  return bestMoves[Math.floor(Math.random() * bestMoves.length)];
}
