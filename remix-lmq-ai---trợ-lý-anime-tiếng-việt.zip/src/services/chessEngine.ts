// Chess Engine: 8x8 standard chessboard, move generation, check/checkmate calculation, and AI bot

export type ChessColor = 'white' | 'black';

export type PieceType = 'p' | 'n' | 'b' | 'r' | 'q' | 'k';

export interface ChessPiece {
  type: PieceType;
  color: ChessColor;
}

export type ChessBoard = (ChessPiece | null)[][];

export interface ChessMove {
  fromRow: number;
  fromCol: number;
  toRow: number;
  toCol: number;
  captured?: ChessPiece | null;
  promotion?: PieceType;
}

// Ký hiệu Unicode quân cờ sắc nét
export const CHESS_SYMBOLS: Record<ChessColor, Record<PieceType, string>> = {
  white: {
    k: '♔',
    q: '♕',
    r: '♖',
    b: '♗',
    n: '♘',
    p: '♙',
  },
  black: {
    k: '♚',
    q: '♛',
    r: '♜',
    b: '♝',
    n: '♞',
    p: '♟',
  },
};

// Điểm giá trị cơ bản của từng quân cờ
export const PIECE_VALUES: Record<PieceType, number> = {
  p: 100,
  n: 320,
  b: 330,
  r: 500,
  q: 900,
  k: 20000,
};

// Bảng điểm vị trí khuyến khích chiếm trung tâm bàn cờ
const PAWN_TABLE_WHITE = [
  [0, 0, 0, 0, 0, 0, 0, 0],
  [50, 50, 50, 50, 50, 50, 50, 50],
  [10, 10, 20, 30, 30, 20, 10, 10],
  [5, 5, 10, 25, 25, 10, 5, 5],
  [0, 0, 0, 20, 20, 0, 0, 0],
  [5, -5, -10, 0, 0, -10, -5, 5],
  [5, 10, 10, -20, -20, 10, 10, 5],
  [0, 0, 0, 0, 0, 0, 0, 0],
];

const KNIGHT_TABLE = [
  [-50, -40, -30, -30, -30, -30, -40, -50],
  [-40, -20, 0, 0, 0, 0, -20, -40],
  [-30, 0, 10, 15, 15, 10, 0, -30],
  [-30, 5, 15, 20, 20, 15, 5, -30],
  [-30, 0, 15, 20, 20, 15, 0, -30],
  [-30, 5, 10, 15, 15, 10, 5, -30],
  [-40, -20, 0, 5, 5, 0, -20, -40],
  [-50, -40, -30, -30, -30, -30, -40, -50],
];

// Khởi tạo bàn cờ vua tiêu chuẩn
export function createInitialChessBoard(): ChessBoard {
  const board: ChessBoard = Array(8)
    .fill(null)
    .map(() => Array(8).fill(null));

  // Quân Đen (Bot) - Hàng 0 và 1
  const backRowBlack: PieceType[] = ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'];
  for (let c = 0; c < 8; c++) {
    board[0][c] = { type: backRowBlack[c], color: 'black' };
    board[1][c] = { type: 'p', color: 'black' };
  }

  // Quân Trắng (Người chơi) - Hàng 6 và 7
  const backRowWhite: PieceType[] = ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'];
  for (let c = 0; c < 8; c++) {
    board[6][c] = { type: 'p', color: 'white' };
    board[7][c] = { type: backRowWhite[c], color: 'white' };
  }

  return board;
}

// Sao chép bàn cờ để tính toán
export function cloneChessBoard(board: ChessBoard): ChessBoard {
  return board.map((row) => row.map((cell) => (cell ? { ...cell } : null)));
}

// Tìm vị trí của quân Vua
export function findKing(board: ChessBoard, color: ChessColor): [number, number] | null {
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (piece && piece.type === 'k' && piece.color === color) {
        return [r, c];
      }
    }
  }
  return null;
}

// Kiểm tra xem một ô có đang bị quân của đối phương tấn công không
export function isSquareAttacked(board: ChessBoard, row: number, col: number, byColor: ChessColor): boolean {
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (!piece || piece.color !== byColor) continue;

      const rawMoves = getRawMoves(board, r, c);
      if (rawMoves.some(([tr, tc]) => tr === row && tc === col)) {
        return true;
      }
    }
  }
  return false;
}

// Kiểm tra xem Vua của màu này có đang bị chiếu hay không
export function isKingInCheck(board: ChessBoard, color: ChessColor): boolean {
  const kingPos = findKing(board, color);
  if (!kingPos) return false;
  const opponentColor: ChessColor = color === 'white' ? 'black' : 'white';
  return isSquareAttacked(board, kingPos[0], kingPos[1], opponentColor);
}

// Tính toán các nước đi hình học thô (chưa lọc trường hợp tự đặt Vua vào thế chiếu)
export function getRawMoves(board: ChessBoard, r: number, c: number): [number, number][] {
  const piece = board[r][c];
  if (!piece) return [];

  const moves: [number, number][] = [];
  const color = piece.color;
  const forward = color === 'white' ? -1 : 1;

  if (piece.type === 'p') {
    // Tốt đi thẳng 1 bước
    const nextRow = r + forward;
    if (nextRow >= 0 && nextRow < 8 && !board[nextRow][c]) {
      moves.push([nextRow, c]);
      // Tốt đi 2 bước từ vạch xuất phát
      const startRow = color === 'white' ? 6 : 1;
      const doubleNextRow = r + forward * 2;
      if (r === startRow && !board[doubleNextRow][c]) {
        moves.push([doubleNextRow, c]);
      }
    }
    // Tốt ăn chéo
    for (const dc of [-1, 1]) {
      const diagCol = c + dc;
      if (nextRow >= 0 && nextRow < 8 && diagCol >= 0 && diagCol < 8) {
        const target = board[nextRow][diagCol];
        if (target && target.color !== color) {
          moves.push([nextRow, diagCol]);
        }
      }
    }
  } else if (piece.type === 'n') {
    // Mã đi chữ L
    const knightOffsets = [
      [-2, -1], [-2, 1], [-1, -2], [-1, 2],
      [1, -2], [1, 2], [2, -1], [2, 1],
    ];
    for (const [dr, dc] of knightOffsets) {
      const nr = r + dr;
      const nc = c + dc;
      if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
        const target = board[nr][nc];
        if (!target || target.color !== color) {
          moves.push([nr, nc]);
        }
      }
    }
  } else if (piece.type === 'b' || piece.type === 'r' || piece.type === 'q') {
    // Tượng (chéo), Xe (ngang dọc), Hậu (cả hai)
    const dirs: [number, number][] = [];
    if (piece.type === 'b' || piece.type === 'q') {
      dirs.push([-1, -1], [-1, 1], [1, -1], [1, 1]);
    }
    if (piece.type === 'r' || piece.type === 'q') {
      dirs.push([-1, 0], [1, 0], [0, -1], [0, 1]);
    }

    for (const [dr, dc] of dirs) {
      let step = 1;
      while (true) {
        const nr = r + dr * step;
        const nc = c + dc * step;
        if (nr < 0 || nr >= 8 || nc < 0 || nc >= 8) break;
        const target = board[nr][nc];
        if (!target) {
          moves.push([nr, nc]);
        } else {
          if (target.color !== color) {
            moves.push([nr, nc]);
          }
          break; // Bị cản
        }
        step++;
      }
    }
  } else if (piece.type === 'k') {
    // Vua đi 1 ô bất kỳ hướng nào
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        if (dr === 0 && dc === 0) continue;
        const nr = r + dr;
        const nc = c + dc;
        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
          const target = board[nr][nc];
          if (!target || target.color !== color) {
            moves.push([nr, nc]);
          }
        }
      }
    }
  }

  return moves;
}

// Lấy danh sách nước đi hợp lệ hoàn toàn (đã kiểm tra không tự đưa Vua vào thế bị chiếu)
export function getLegalMoves(board: ChessBoard, r: number, c: number): [number, number][] {
  const piece = board[r][c];
  if (!piece) return [];

  const rawMoves = getRawMoves(board, r, c);
  const legalMoves: [number, number][] = [];

  for (const [tr, tc] of rawMoves) {
    const tempBoard = cloneChessBoard(board);
    // Đi thử nước đi
    tempBoard[tr][tc] = piece;
    tempBoard[r][c] = null;

    // Phong hậu tạm thời nếu tốt chạm biên để kiểm tra thế cờ chính xác
    if (piece.type === 'p' && (tr === 0 || tr === 7)) {
      tempBoard[tr][tc] = { type: 'q', color: piece.color };
    }

    // Nếu sau nước đi vua không bị chiếu thì nước đi hợp lệ
    if (!isKingInCheck(tempBoard, piece.color)) {
      legalMoves.push([tr, tc]);
    }
  }

  return legalMoves;
}

// Kiểm tra toàn bộ nước đi hợp lệ của một bên
export function getAllLegalMovesForColor(board: ChessBoard, color: ChessColor): ChessMove[] {
  const allMoves: ChessMove[] = [];
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (piece && piece.color === color) {
        const targets = getLegalMoves(board, r, c);
        for (const [tr, tc] of targets) {
          allMoves.push({
            fromRow: r,
            fromCol: c,
            toRow: tr,
            toCol: tc,
            captured: board[tr][tc],
          });
        }
      }
    }
  }
  return allMoves;
}

// Đánh giá thế trận bàn cờ theo góc nhìn của quân Đen (Bot)
function evaluateChessBoard(board: ChessBoard): number {
  let score = 0;

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (!piece) continue;

      let pieceVal = PIECE_VALUES[piece.type];

      // Thưởng vị trí chiếm trung tâm
      if (piece.type === 'p') {
        const tableScore = piece.color === 'white' ? PAWN_TABLE_WHITE[r][c] : PAWN_TABLE_WHITE[7 - r][c];
        pieceVal += tableScore;
      } else if (piece.type === 'n') {
        pieceVal += KNIGHT_TABLE[r][c];
      }

      if (piece.color === 'black') {
        score += pieceVal;
      } else {
        score -= pieceVal;
      }
    }
  }

  return score;
}

// Thuật toán AI chọn nước đi thông minh cho Bot (Quân Đen)
export function getBestChessMove(board: ChessBoard): ChessMove | null {
  const possibleMoves = getAllLegalMovesForColor(board, 'black');
  if (possibleMoves.length === 0) return null;

  let bestMove: ChessMove | null = null;
  let maxScore = -Infinity;

  // Xáo trộn nhẹ để bot không đánh lặp khuôn
  const shuffledMoves = [...possibleMoves].sort(() => Math.random() - 0.5);

  for (const move of shuffledMoves) {
    const tempBoard = cloneChessBoard(board);
    const movingPiece = tempBoard[move.fromRow][move.fromCol]!;

    tempBoard[move.toRow][move.toCol] = movingPiece;
    tempBoard[move.fromRow][move.fromCol] = null;

    // Tự động phong Hậu cho bot khi tốt tới đáy
    if (movingPiece.type === 'p' && move.toRow === 7) {
      tempBoard[move.toRow][move.toCol] = { type: 'q', color: 'black' };
    }

    // Đánh giá thế cờ cơ bản + xem đối phương phản đòn tốt nhất như thế nào (Minimax 1.5 ply)
    let moveScore = evaluateChessBoard(tempBoard);

    // Ưu tiên ăn quân
    if (move.captured) {
      moveScore += PIECE_VALUES[move.captured.type] * 1.5;
    }

    // Thưởng điểm nếu chiếu tướng đối phương
    if (isKingInCheck(tempBoard, 'white')) {
      moveScore += 80;
    }

    // Trừ điểm nếu nước đi này đặt quân vào ô bị trắng tấn công (tránh cúng quân)
    if (isSquareAttacked(tempBoard, move.toRow, move.toCol, 'white')) {
      moveScore -= PIECE_VALUES[movingPiece.type] * 0.8;
    }

    if (moveScore > maxScore) {
      maxScore = moveScore;
      bestMove = move;
    }
  }

  return bestMove || possibleMoves[0];
}

// Âm thanh cờ mô phỏng bằng Web Audio API (Zero external assets, không delay)
export function playBoardSound(type: 'place' | 'capture' | 'check' | 'win' | 'lose') {
  if (typeof window === 'undefined') return;
  const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
  if (!AudioContext) return;

  try {
    const ctx = new AudioContext();

    if (type === 'place') {
      // Tiếng gõ quân cờ thanh gọn
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(140, ctx.currentTime + 0.08);

      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.09);
    } else if (type === 'capture') {
      // Tiếng ăn quân cờ dứt khoát
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(450, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(180, ctx.currentTime + 0.12);

      gain.gain.setValueAtTime(0.35, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.13);
    } else if (type === 'check') {
      // Tiếng cảnh báo chiếu tướng
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, ctx.currentTime);
      osc.frequency.setValueAtTime(800, ctx.currentTime + 0.08);

      gain.gain.setValueAtTime(0.4, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.26);
    } else if (type === 'win') {
      // Giai điệu chiến thắng 3 nốt
      const notes = [523.25, 659.25, 783.99]; // C5, E5, G5
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.1);

        gain.gain.setValueAtTime(0, ctx.currentTime + idx * 0.1);
        gain.gain.linearRampToValueAtTime(0.3, ctx.currentTime + idx * 0.1 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.1 + 0.3);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.1);
        osc.stop(ctx.currentTime + idx * 0.1 + 0.32);
      });
    } else if (type === 'lose') {
      // Âm thanh trầm buồn khi thua
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(260, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(120, ctx.currentTime + 0.4);

      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.42);
    }
  } catch (err) {
    console.warn('Web Audio error:', err);
  }
}
