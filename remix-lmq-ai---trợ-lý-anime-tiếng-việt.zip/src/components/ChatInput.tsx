import React, { useState, useEffect, useRef } from 'react';
import { Send, Mic, MicOff, Volume2, VolumeX, Trash2, Sparkles, AlertCircle, Swords, BookOpen } from 'lucide-react';

interface ChatInputProps {
  onSendMessage: (text: string) => void;
  onClearChat: () => void;
  autoSpeak: boolean;
  onToggleAutoSpeak: () => void;
  onOpenGameModal?: () => void;
  onOpenKnowledgeModal?: () => void;
  disabled?: boolean;
}

const SUGGESTED_PROMPTS = [
  'Minecraft chế tạo bàn phù phép như nào',
  'Cách dọn rác ổ C bị đầy Windows',
  'Căn giữa một thẻ div trong CSS',
  'Closure trong JavaScript là gì',
  'Vận tốc ánh sáng là bao nhiêu',
  'Chơi cờ Caro',
  'Chơi cờ Vua',
  'Kỹ thuật học Pomodoro',
];

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  onClearChat,
  autoSpeak,
  onToggleAutoSpeak,
  onOpenGameModal,
  onOpenKnowledgeModal,
  disabled = false,
}) => {
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(true);
  const [speechNotification, setSpeechNotification] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Kiểm tra hỗ trợ Web Speech API
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      try {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'vi-VN'; // Nhận diện tiếng Việt

        recognition.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          if (transcript) {
            setInputText((prev) => (prev ? `${prev} ${transcript}` : transcript));
          }
          setIsListening(false);
        };

        recognition.onerror = (event: any) => {
          console.warn('Speech Recognition error:', event.error);
          setIsListening(false);
          if (event.error === 'not-allowed') {
            setSpeechNotification('Vui lòng cấp quyền truy cập Microphone trong trình duyệt!');
          }
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognitionRef.current = recognition;
      } catch (e) {
        console.warn('Không thể khởi tạo Speech Recognition', e);
        setSpeechSupported(false);
      }
    } else {
      setSpeechSupported(false);
    }
  }, []);

  const handleToggleVoice = () => {
    if (!speechSupported || !recognitionRef.current) {
      setSpeechNotification(
        'Trình duyệt này chưa tích hợp Speech Recognition. Hãy sử dụng Google Chrome hoặc Microsoft Edge trên Windows để nói tiếng Việt!'
      );
      setTimeout(() => setSpeechNotification(null), 5000);
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      setSpeechNotification(null);
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch (err) {
        console.warn('Lỗi bật nhận diện giọng nói:', err);
      }
    }
  };

  const handleSend = () => {
    const text = inputText.trim();
    if (!text || disabled) return;
    onSendMessage(text);
    setInputText('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="w-full space-y-3">
      {/* Thông báo tính năng Micro nếu không hỗ trợ */}
      {speechNotification && (
        <div className="p-2.5 bg-purple-950/80 border border-purple-500/40 rounded-xl text-xs text-purple-200 flex items-center justify-between gap-2 animate-fadeIn">
          <div className="flex items-center gap-1.5">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{speechNotification}</span>
          </div>
          <button
            onClick={() => setSpeechNotification(null)}
            className="text-slate-400 hover:text-white text-xs px-1"
          >
            ✕
          </button>
        </div>
      )}

      {/* Danh sách gợi ý câu hỏi nhanh (Suggested Prompts) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        <span className="text-[11px] text-purple-400/80 font-medium shrink-0 flex items-center gap-1">
          <Sparkles className="w-3 h-3" /> Gợi ý:
        </span>
        {SUGGESTED_PROMPTS.map((prompt, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => onSendMessage(prompt)}
            disabled={disabled}
            className="text-xs px-2.5 py-1 rounded-full bg-[#1b1238] hover:bg-purple-800/60 border border-purple-500/25 hover:border-purple-400 text-slate-300 hover:text-white transition-all whitespace-nowrap shrink-0 shadow-sm"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Khung nhập văn bản chính */}
      <div className="relative flex items-center bg-[#150e2a] border border-purple-500/35 rounded-2xl shadow-xl shadow-purple-950/40 focus-within:border-purple-400 transition-all p-1.5">
        {/* Nút Micro */}
        <button
          type="button"
          onClick={handleToggleVoice}
          className={`p-2.5 rounded-xl transition-all ${
            isListening
              ? 'bg-red-500 text-white animate-pulse shadow-md shadow-red-500/40'
              : 'text-purple-300 hover:text-white hover:bg-purple-900/40'
          }`}
          title={isListening ? 'Đang nghe... bấm để dừng' : 'Nói bằng giọng nói tiếng Việt'}
        >
          {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
        </button>

        {/* Nút Chơi Cờ nhanh */}
        {onOpenGameModal && (
          <button
            type="button"
            onClick={onOpenGameModal}
            className="p-2.5 rounded-xl text-purple-300 hover:text-white hover:bg-purple-900/40 transition-all shrink-0"
            title="Mở Bàn cờ Caro & Cờ Vua đấu cùng Bot"
          >
            <Swords className="w-4 h-4 text-pink-400" />
          </button>
        )}

        {/* Nút Mở Kho Kiến Thức Cục Bộ */}
        {onOpenKnowledgeModal && (
          <button
            type="button"
            onClick={onOpenKnowledgeModal}
            className="p-2.5 rounded-xl text-cyan-400 hover:text-white hover:bg-cyan-950/40 transition-all shrink-0"
            title="Mở Kho Kiến Thức Cục Bộ (Local Knowledge Base)"
          >
            <BookOpen className="w-4 h-4" />
          </button>
        )}

        {/* Input Text */}
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={isListening ? 'Đang lắng nghe bạn nói...' : 'Nhắn tin với LMQ AI bằng tiếng Việt (Enter để gửi)...'}
          disabled={disabled}
          className="flex-1 bg-transparent px-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none"
        />

        {/* Nút Gửi */}
        <button
          type="button"
          onClick={handleSend}
          disabled={!inputText.trim() || disabled}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
            inputText.trim() && !disabled
              ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white shadow-lg shadow-purple-900/50 scale-[1.02]'
              : 'bg-slate-800 text-slate-500 cursor-not-allowed'
          }`}
        >
          <span>Gửi</span>
          <Send className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Thanh điều khiển phụ dưới ô nhập: Tự động đọc giọng nói + Xóa đoạn chat */}
      <div className="flex items-center justify-between text-xs text-slate-400 px-1">
        <button
          type="button"
          onClick={onToggleAutoSpeak}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition-colors border ${
            autoSpeak
              ? 'bg-purple-950/60 border-purple-500/40 text-purple-300 font-medium'
              : 'border-transparent hover:bg-purple-950/30 text-slate-400'
          }`}
          title="Tự động đọc to bằng giọng tiếng Việt khi LMQ AI trả lời"
        >
          {autoSpeak ? <Volume2 className="w-3.5 h-3.5 text-pink-400" /> : <VolumeX className="w-3.5 h-3.5 text-slate-500" />}
          <span>Tự động đọc: {autoSpeak ? 'Bật' : 'Tắt'}</span>
        </button>

        <button
          type="button"
          onClick={onClearChat}
          className="flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-red-950/40 hover:text-red-300 border border-transparent hover:border-red-500/30 transition-colors"
          title="Xóa toàn bộ lịch sử đoạn chat"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Xóa đoạn chat</span>
        </button>
      </div>
    </div>
  );
};
