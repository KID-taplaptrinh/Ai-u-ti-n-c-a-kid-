import React, { useState, useEffect } from 'react';
import {
  KnowledgeItem,
  KnowledgeCategory,
  KNOWLEDGE_CATEGORIES,
} from '../types/knowledge';
import {
  getAllKnowledgeItems,
  saveKnowledgeItem,
  deleteKnowledgeItem,
  resetKnowledgeBase,
  exportKnowledgeToJSON,
  importKnowledgeFromJSON,
} from '../services/knowledgeStorage';
import { runAllKnowledgeTests, TestResult } from '../services/knowledgeTests';
import {
  BookOpen,
  Search,
  PlusCircle,
  Download,
  Upload,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Trash2,
  Edit3,
  X,
  Play,
  Sparkles,
  ShieldCheck,
  FileText,
  HelpCircle,
  Layers,
  ChevronRight,
  Filter,
} from 'lucide-react';

interface KnowledgeBaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  botName: string;
  initialTab?: 'browse' | 'teach' | 'backup' | 'test';
  initialQuery?: string;
  onKnowledgeUpdated?: () => void;
}

export const KnowledgeBaseModal: React.FC<KnowledgeBaseModalProps> = ({
  isOpen,
  onClose,
  botName,
  initialTab = 'browse',
  initialQuery = '',
  onKnowledgeUpdated,
}) => {
  const [activeTab, setActiveTab] = useState<'browse' | 'teach' | 'backup' | 'test'>(initialTab);
  const [items, setItems] = useState<KnowledgeItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchFilter, setSearchFilter] = useState(initialQuery);
  const [selectedCategory, setSelectedCategory] = useState<KnowledgeCategory | 'all'>('all');
  const [selectedItem, setSelectedItem] = useState<KnowledgeItem | null>(null);

  // Form State for "Dạy LMQ AI"
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formCategory, setFormCategory] = useState<KnowledgeCategory>('minecraft');
  const [formTitle, setFormTitle] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formKeywords, setFormKeywords] = useState('');
  const [formSynonyms, setFormSynonyms] = useState('');
  const [formQuestions, setFormQuestions] = useState('');
  const [formSource, setFormSource] = useState('');
  const [formVerified, setFormVerified] = useState(true);
  const [formStatus, setFormStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Backup & Import state
  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Test Suite state
  const [testResults, setTestResults] = useState<{
    total: number;
    passedCount: number;
    failedCount: number;
    results: TestResult[];
  } | null>(null);
  const [isRunningTests, setIsRunningTests] = useState(false);

  // Tải danh sách kiến thức từ IndexedDB
  const loadKnowledge = async () => {
    setLoading(true);
    try {
      const data = await getAllKnowledgeItems();
      setItems(data);
    } catch (e) {
      console.warn('Lỗi tải kho kiến thức:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadKnowledge();
      if (initialTab) setActiveTab(initialTab);
      if (initialQuery) {
        setSearchFilter(initialQuery);
        if (initialTab === 'teach') {
          setEditingId(null);
          setFormTitle(initialQuery);
          setFormQuestions(initialQuery);
          setFormKeywords(initialQuery.toLowerCase());
          setFormStatus(null);
        }
      }
    }
  }, [isOpen, initialTab, initialQuery]);

  // Reset form khi chuyển sang tab Dạy học mới
  const resetForm = () => {
    setEditingId(null);
    setFormCategory('minecraft');
    setFormTitle('');
    setFormContent('');
    setFormKeywords('');
    setFormSynonyms('');
    setFormQuestions('');
    setFormSource('');
    setFormVerified(true);
    setFormStatus(null);
  };

  // Nạp dữ liệu vào form để chỉnh sửa
  const handleEditItem = (item: KnowledgeItem) => {
    setEditingId(item.id);
    setFormCategory(item.category);
    setFormTitle(item.title);
    setFormContent(item.content);
    setFormKeywords(item.keywords.join(', '));
    setFormSynonyms(item.synonyms.join(', '));
    setFormQuestions(item.sampleQuestions.join('\n'));
    setFormSource(item.source || '');
    setFormVerified(item.verified);
    setFormStatus(null);
    setActiveTab('teach');
  };

  // Lưu mục kiến thức vào IndexedDB
  const handleSaveForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formContent.trim()) {
      setFormStatus({ type: 'error', message: 'Vui lòng nhập đầy đủ tiêu đề và nội dung kiến thức!' });
      return;
    }

    const keywords = formKeywords
      .split(',')
      .map((k) => k.trim())
      .filter((k) => k.length > 0);

    const synonyms = formSynonyms
      .split(',')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    const sampleQuestions = formQuestions
      .split('\n')
      .map((q) => q.trim())
      .filter((q) => q.length > 0);

    const itemToSave: KnowledgeItem = {
      id: editingId || `custom-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      category: formCategory,
      title: formTitle.trim(),
      content: formContent.trim(),
      keywords: keywords.length > 0 ? keywords : [formTitle.trim().toLowerCase()],
      synonyms,
      sampleQuestions: sampleQuestions.length > 0 ? sampleQuestions : [formTitle.trim()],
      source: formSource.trim() || 'Người dùng đóng góp (Cục bộ)',
      verified: formVerified,
      isCustom: true,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    try {
      await saveKnowledgeItem(itemToSave);
      await loadKnowledge();
      onKnowledgeUpdated?.();
      setFormStatus({
        type: 'success',
        message: editingId
          ? 'Đã cập nhật mục kiến thức thành công trong IndexedDB!'
          : 'Đã lưu kiến thức mới vào bộ nhớ cục bộ! Giờ bạn có thể hỏi bot về nội dung này.',
      });
      if (!editingId) {
        resetForm();
      }
    } catch (err: any) {
      setFormStatus({ type: 'error', message: `Lỗi lưu dữ liệu: ${err.message}` });
    }
  };

  // Xóa mục kiến thức
  const handleDeleteItem = async (id: string, title: string) => {
    if (window.confirm(`Bạn có chắc chắn muốn xóa mục "${title}" khỏi kho kiến thức không?`)) {
      await deleteKnowledgeItem(id);
      await loadKnowledge();
      onKnowledgeUpdated?.();
      if (selectedItem?.id === id) setSelectedItem(null);
    }
  };

  // Xuất file JSON
  const handleExportJSON = async () => {
    const jsonStr = await exportKnowledgeToJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lmq_ai_knowledge_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Nhập file JSON
  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportStatus('Đang đọc tệp tin...');
    const reader = new FileReader();
    reader.onload = async (evt) => {
      const content = evt.target?.result as string;
      const res = await importKnowledgeFromJSON(content);
      if (res.success) {
        await loadKnowledge();
        onKnowledgeUpdated?.();
        setImportStatus(`Đã nhập thành công ${res.count} mục kiến thức vào kho!`);
      } else {
        setImportStatus(`Lỗi: ${res.error}`);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Khôi phục mặc định
  const handleResetDefault = async () => {
    if (
      window.confirm(
        'Bạn có chắc chắn muốn xóa các kiến thức tự thêm và khôi phục kho kiến thức về mặc định ban đầu?'
      )
    ) {
      await resetKnowledgeBase();
      await loadKnowledge();
      onKnowledgeUpdated?.();
      alert('Đã khôi phục kho kiến thức mặc định!');
    }
  };

  // Chạy bài kiểm thử tự động
  const handleRunTests = async () => {
    setIsRunningTests(true);
    try {
      const res = await runAllKnowledgeTests();
      setTestResults(res);
    } catch (err) {
      console.error('Lỗi chạy kiểm thử:', err);
    } finally {
      setIsRunningTests(false);
    }
  };

  if (!isOpen) return null;

  // Lọc danh sách theo từ khóa tìm kiếm và chuyên mục
  const filteredItems = items.filter((item) => {
    const matchCategory = selectedCategory === 'all' || item.category === selectedCategory;
    if (!matchCategory) return false;

    if (!searchFilter.trim()) return true;
    const q = searchFilter.toLowerCase();
    return (
      item.title.toLowerCase().includes(q) ||
      item.content.toLowerCase().includes(q) ||
      item.keywords.some((k) => k.toLowerCase().includes(q)) ||
      item.sampleQuestions.some((sq) => sq.toLowerCase().includes(q))
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-[#120b24] border border-purple-500/40 rounded-3xl w-full max-w-5xl max-h-[94vh] flex flex-col shadow-2xl shadow-purple-950/80 overflow-hidden">
        {/* Header Modal */}
        <div className="px-5 py-4 border-b border-purple-500/20 flex items-center justify-between bg-[#190f33]/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-600 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-cyan-950/50">
              <BookOpen className="w-5 h-5 text-cyan-200" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>Kho Kiến Thức Cục Bộ (Local Knowledge Base)</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 font-mono">
                  Offline · 0đ API
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Tra cứu, quản lý và dạy thêm tri thức cho {botName} lưu trữ bền vững trên trình duyệt
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-purple-950/50 hover:bg-red-950/60 border border-purple-500/30 hover:border-red-500/40 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs (Top Bar) */}
        <div className="px-5 py-2.5 bg-[#0f0920] border-b border-purple-500/15 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 p-1 bg-[#1a1033] rounded-xl border border-purple-500/20">
            <button
              onClick={() => setActiveTab('browse')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'browse'
                  ? 'bg-gradient-to-r from-purple-600 to-cyan-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Search className="w-3.5 h-3.5" />
              <span>Duyệt Tri Thức ({items.length})</span>
            </button>

            <button
              onClick={() => {
                resetForm();
                setActiveTab('teach');
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'teach'
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>Dạy LMQ AI</span>
            </button>

            <button
              onClick={() => setActiveTab('backup')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'backup'
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Download className="w-3.5 h-3.5" />
              <span>Sao Lưu / Nhập JSON</span>
            </button>

            <button
              onClick={() => setActiveTab('test')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'test'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Play className="w-3.5 h-3.5" />
              <span>Kiểm Thử (10 Tests)</span>
            </button>
          </div>

          <div className="text-[11px] text-slate-400 font-mono">
            <span>IndexedDB: </span>
            <span className="text-emerald-400 font-bold">Hoạt động bình thường</span>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#0c071a]">
          {/* ===================== TAB 1: DUYỆT & TRA CỨU TRI THỨC ===================== */}
          {activeTab === 'browse' && (
            <div className="space-y-4">
              {/* Thanh lọc & tìm kiếm */}
              <div className="flex flex-col sm:flex-row gap-2.5">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-purple-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={searchFilter}
                    onChange={(e) => setSearchFilter(e.target.value)}
                    placeholder="Tìm kiếm theo tiêu đề, câu hỏi, từ khóa (Minecraft, Flexbox, Windows...)"
                    className="w-full bg-[#160f2e] border border-purple-500/30 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                  {searchFilter && (
                    <button
                      onClick={() => setSearchFilter('')}
                      className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-white"
                    >
                      ✕
                    </button>
                  )}
                </div>

                {/* Chọn chuyên mục */}
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value as any)}
                  className="bg-[#160f2e] border border-purple-500/30 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-400"
                >
                  <option value="all">Tất cả chủ đề ({items.length})</option>
                  {Object.values(KNOWLEDGE_CATEGORIES).map((cat) => {
                    const count = items.filter((i) => i.category === cat.id).length;
                    return (
                      <option key={cat.id} value={cat.id}>
                        {cat.name} ({count})
                      </option>
                    );
                  })}
                </select>
              </div>

              {/* Danh sách các mục kiến thức */}
              {loading ? (
                <div className="text-center py-12 text-purple-300 text-xs animate-pulse">
                  Đang tải kho dữ liệu IndexedDB...
                </div>
              ) : filteredItems.length === 0 ? (
                <div className="text-center py-12 p-6 bg-[#150e2a] border border-purple-500/20 rounded-2xl">
                  <AlertCircle className="w-8 h-8 text-amber-400 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-white">Không tìm thấy kiến thức phù hợp!</p>
                  <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                    Bạn có thể tự thêm mục này vào kho bằng cách bấm vào tab <strong>"Dạy LMQ AI"</strong> phía trên!
                  </p>
                  <button
                    onClick={() => {
                      resetForm();
                      setFormTitle(searchFilter);
                      setFormQuestions(searchFilter);
                      setActiveTab('teach');
                    }}
                    className="mt-3 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all inline-flex items-center gap-1.5"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>Dạy câu này cho LMQ AI ngay</span>
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {filteredItems.map((item) => {
                    const catInfo = KNOWLEDGE_CATEGORIES[item.category] || KNOWLEDGE_CATEGORIES.general;
                    const isExpanded = selectedItem?.id === item.id;

                    return (
                      <div
                        key={item.id}
                        className={`p-4 rounded-2xl border transition-all duration-200 flex flex-col justify-between ${
                          isExpanded
                            ? 'bg-[#1b1238] border-cyan-500/60 shadow-lg shadow-cyan-950/40 md:col-span-2'
                            : 'bg-[#150e2a] hover:bg-[#181030] border-purple-500/25 hover:border-purple-500/50'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between gap-2 mb-2">
                            <span className={`text-[10px] px-2 py-0.5 rounded-full border font-medium ${catInfo.badgeColor}`}>
                              {catInfo.name}
                            </span>
                            <div className="flex items-center gap-1 text-[11px]">
                              {item.isCustom ? (
                                <span className="px-1.5 py-0.2 rounded bg-rose-950/60 border border-rose-500/30 text-rose-300 text-[10px]">
                                  Tự thêm
                                </span>
                              ) : (
                                <span className="flex items-center gap-0.5 text-emerald-400 text-[10px]">
                                  <ShieldCheck className="w-3 h-3" /> Đã kiểm chứng
                                </span>
                              )}
                            </div>
                          </div>

                          <h3 className="text-sm font-bold text-white leading-snug">{item.title}</h3>

                          {/* Nội dung thu gọn hoặc mở rộng */}
                          <div className="mt-2 text-xs text-slate-300 leading-relaxed font-sans">
                            {isExpanded ? (
                              <div className="p-3 bg-[#0e071c] rounded-xl border border-purple-500/20 whitespace-pre-line text-slate-200 max-h-96 overflow-y-auto">
                                {item.content}
                              </div>
                            ) : (
                              <p className="line-clamp-2 text-slate-400">{item.content}</p>
                            )}
                          </div>

                          {/* Chi tiết từ khóa và câu hỏi mẫu khi mở rộng */}
                          {isExpanded && (
                            <div className="mt-3 pt-3 border-t border-purple-500/20 space-y-2 text-xs">
                              <div>
                                <span className="text-purple-300 font-semibold">Các câu hỏi mẫu nhận diện:</span>
                                <ul className="list-disc list-inside text-slate-300 pl-1 mt-1 space-y-0.5">
                                  {item.sampleQuestions.map((q, idx) => (
                                    <li key={idx} className="italic text-slate-300">
                                      "{q}"
                                    </li>
                                  ))}
                                </ul>
                              </div>

                              <div className="flex flex-wrap gap-1 items-center pt-1">
                                <span className="text-purple-300 font-semibold mr-1">Từ khóa:</span>
                                {item.keywords.map((kw, idx) => (
                                  <span
                                    key={idx}
                                    className="px-1.5 py-0.5 bg-purple-950/80 border border-purple-500/30 rounded text-[10px] text-purple-200 font-mono"
                                  >
                                    {kw}
                                  </span>
                                ))}
                              </div>

                              {item.source && (
                                <div className="text-[11px] text-slate-400 pt-1">
                                  <span>Nguồn tham chiếu: </span>
                                  <span className="text-cyan-300 font-medium">{item.source}</span>
                                </div>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Thanh công cụ mỗi thẻ */}
                        <div className="flex items-center justify-between pt-3 mt-3 border-t border-purple-500/15 text-xs">
                          <button
                            onClick={() => setSelectedItem(isExpanded ? null : item)}
                            className="text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1"
                          >
                            <span>{isExpanded ? 'Thu gọn' : 'Xem chi tiết'}</span>
                            <ChevronRight className={`w-3.5 h-3.5 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                          </button>

                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => handleEditItem(item)}
                              className="p-1.5 rounded-lg bg-purple-900/40 hover:bg-purple-800 text-purple-200 hover:text-white transition-colors"
                              title="Sửa mục kiến thức này"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteItem(item.id, item.title)}
                              className="p-1.5 rounded-lg bg-red-950/40 hover:bg-red-900/60 text-red-300 hover:text-white transition-colors"
                              title="Xóa mục kiến thức này"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ===================== TAB 2: DẠY LMQ AI (THÊM / SỬA KIẾN THỨC) ===================== */}
          {activeTab === 'teach' && (
            <div className="max-w-3xl mx-auto space-y-4">
              <div className="p-4 bg-gradient-to-r from-purple-950/60 via-[#180f33] to-purple-950/60 border border-purple-500/30 rounded-2xl">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <Sparkles className="w-4 h-4 text-pink-400" />
                  <span>{editingId ? 'Chỉnh sửa Mục Kiến Thức' : 'Dạy Kiến Thức Mới Cho LMQ AI'}</span>
                </div>
                <p className="text-xs text-slate-300 mt-1">
                  Nhập thông tin bên dưới để bot học câu trả lời mới. Dữ liệu được lưu vĩnh viễn trong IndexedDB của trình duyệt, không tốn phí API nào!
                </p>
              </div>

              {formStatus && (
                <div
                  className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                    formStatus.type === 'success'
                      ? 'bg-emerald-950/70 border-emerald-500/40 text-emerald-300'
                      : 'bg-rose-950/70 border-rose-500/40 text-rose-300'
                  }`}
                >
                  {formStatus.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 shrink-0" />
                  )}
                  <span>{formStatus.message}</span>
                </div>
              )}

              <form onSubmit={handleSaveForm} className="space-y-4 bg-[#140d28] p-5 rounded-2xl border border-purple-500/25">
                {/* Chủ đề & Tiêu đề */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-purple-300 mb-1">Chủ đề (Category)</label>
                    <select
                      value={formCategory}
                      onChange={(e) => setFormCategory(e.target.value as KnowledgeCategory)}
                      className="w-full bg-[#1b1236] border border-purple-500/30 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                    >
                      {Object.values(KNOWLEDGE_CATEGORIES).map((cat) => (
                        <option key={cat.id} value={cat.id}>
                          {cat.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-purple-300 mb-1">
                      Tiêu đề kiến thức <span className="text-rose-400">*</span>
                    </label>
                    <input
                      type="text"
                      value={formTitle}
                      onChange={(e) => setFormTitle(e.target.value)}
                      placeholder="Ví dụ: Cách chế tạo xe mỏ gắn lò nung trong Minecraft"
                      required
                      className="w-full bg-[#1b1236] border border-purple-500/30 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                {/* Các câu hỏi tương tự */}
                <div>
                  <label className="block text-xs font-semibold text-purple-300 mb-1">
                    Các biến thể câu hỏi người dùng có thể hỏi (mỗi câu một dòng)
                  </label>
                  <textarea
                    rows={3}
                    value={formQuestions}
                    onChange={(e) => setFormQuestions(e.target.value)}
                    placeholder="Chế tạo xe mỏ lò nung minecraft như thế nào&#10;Làm furnace minecart mc ra sao&#10;Công thức xe mỏ chở than"
                    className="w-full bg-[#1b1236] border border-purple-500/30 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">
                    Càng nhiều cách hỏi khác nhau, bot càng nhận diện chính xác kể cả khi dùng teencode hay không dấu!
                  </p>
                </div>

                {/* Nội dung câu trả lời */}
                <div>
                  <label className="block text-xs font-semibold text-purple-300 mb-1">
                    Nội dung giải thích / Câu trả lời hoàn chỉnh (Hỗ trợ Markdown) <span className="text-rose-400">*</span>
                  </label>
                  <textarea
                    rows={6}
                    value={formContent}
                    onChange={(e) => setFormContent(e.target.value)}
                    placeholder="Viết câu trả lời chi tiết tại đây. Bạn có thể dùng **in đậm**, gạch đầu dòng -, hoặc đoạn code ```..."
                    required
                    className="w-full bg-[#1b1236] border border-purple-500/30 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>

                {/* Từ khóa & Từ đồng nghĩa */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-purple-300 mb-1">
                      Từ khóa cốt lõi (phân tách bằng dấu phẩy)
                    </label>
                    <input
                      type="text"
                      value={formKeywords}
                      onChange={(e) => setFormKeywords(e.target.value)}
                      placeholder="xe mo, lo nung, minecraft, minecart"
                      className="w-full bg-[#1b1236] border border-purple-500/30 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-purple-300 mb-1">
                      Từ đồng nghĩa / Tên tiếng Anh
                    </label>
                    <input
                      type="text"
                      value={formSynonyms}
                      onChange={(e) => setFormSynonyms(e.target.value)}
                      placeholder="furnace minecart, xe mo chay than"
                      className="w-full bg-[#1b1236] border border-purple-500/30 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                {/* Nguồn tài liệu & Đã xác minh */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-center pt-1">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-purple-300 mb-1">Nguồn thông tin / Tài liệu tham khảo</label>
                    <input
                      type="text"
                      value={formSource}
                      onChange={(e) => setFormSource(e.target.value)}
                      placeholder="Ví dụ: Minecraft Wiki, MDN Web Docs, Sách giáo khoa..."
                      className="w-full bg-[#1b1236] border border-purple-500/30 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div className="flex items-center gap-2 pt-4">
                    <input
                      type="checkbox"
                      id="verifiedCheck"
                      checked={formVerified}
                      onChange={(e) => setFormVerified(e.target.checked)}
                      className="w-4 h-4 rounded text-purple-600 focus:ring-purple-500 bg-[#1b1236] border-purple-500/40"
                    />
                    <label htmlFor="verifiedCheck" className="text-xs text-slate-200 font-medium cursor-pointer">
                      Xác nhận đã kiểm chứng
                    </label>
                  </div>
                </div>

                {/* Nút hành động */}
                <div className="flex items-center justify-end gap-2 pt-3 border-t border-purple-500/20">
                  {editingId && (
                    <button
                      type="button"
                      onClick={resetForm}
                      className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-all"
                    >
                      Hủy bỏ sửa
                    </button>
                  )}
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white text-xs font-bold transition-all shadow-md shadow-purple-950/50 flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{editingId ? 'Cập nhật Kiến thức' : 'Lưu vào Kho Kiến Thức'}</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* ===================== TAB 3: SAO LƯU & NHẬP JSON ===================== */}
          {activeTab === 'backup' && (
            <div className="max-w-2xl mx-auto space-y-5">
              <div className="p-4 bg-[#140d28] rounded-2xl border border-purple-500/25 space-y-2">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Download className="w-4 h-4 text-cyan-400" />
                  <span>Xuất dữ liệu Sao lưu (Export JSON)</span>
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Tải toàn bộ kho kiến thức hiện tại (bao gồm các mục mặc định và mục bạn tự dạy) về máy tính dưới dạng tệp tin <code>.json</code> để lưu trữ an toàn hoặc chia sẻ cho bạn bè.
                </p>
                <div className="pt-2">
                  <button
                    onClick={handleExportJSON}
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold transition-all flex items-center gap-2 shadow-md shadow-cyan-950/40"
                  >
                    <Download className="w-4 h-4" />
                    <span>Tải về tệp Sao lưu JSON</span>
                  </button>
                </div>
              </div>

              <div className="p-4 bg-[#140d28] rounded-2xl border border-purple-500/25 space-y-2">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Upload className="w-4 h-4 text-purple-400" />
                  <span>Nhập dữ liệu Kiến thức (Import JSON)</span>
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Chọn tệp JSON sao lưu từ máy tính để thêm nhanh hàng loạt kiến thức mới vào bộ nhớ IndexedDB của LMQ AI.
                </p>
                <div className="pt-2">
                  <label className="cursor-pointer px-4 py-2.5 rounded-xl bg-purple-900/60 hover:bg-purple-800 border border-purple-500/40 text-purple-200 hover:text-white text-xs font-bold transition-all inline-flex items-center gap-2">
                    <Upload className="w-4 h-4 text-pink-400" />
                    <span>Chọn tệp JSON từ máy tính</span>
                    <input type="file" accept=".json" onChange={handleImportFile} className="hidden" />
                  </label>
                </div>
                {importStatus && (
                  <p className="text-xs text-emerald-400 font-medium pt-1 animate-fadeIn">{importStatus}</p>
                )}
              </div>

              <div className="p-4 bg-red-950/20 rounded-2xl border border-red-500/30 space-y-2">
                <h3 className="text-sm font-bold text-rose-300 flex items-center gap-2">
                  <RotateCcw className="w-4 h-4 text-rose-400" />
                  <span>Khôi phục Kho Kiến Thức Mặc Định</span>
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Xóa các bài viết do người dùng chỉnh sửa/thêm mới và đưa toàn bộ kho kiến thức về trạng thái ban đầu của hệ thống.
                </p>
                <div className="pt-2">
                  <button
                    onClick={handleResetDefault}
                    className="px-4 py-2 rounded-xl bg-red-950/60 hover:bg-red-900 border border-red-500/40 text-red-200 text-xs font-semibold transition-all flex items-center gap-1.5"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Khôi phục cài đặt gốc</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ===================== TAB 4: BỘ KIỂM THỬ HỆ THỐNG (TEST SUITE) ===================== */}
          {activeTab === 'test' && (
            <div className="space-y-4 max-w-3xl mx-auto">
              <div className="p-4 bg-[#140d28] rounded-2xl border border-emerald-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Play className="w-4 h-4 text-emerald-400" />
                    <span>Bộ Kiểm Thử Tự Động Kho Kiến Thức (10 Bài Test)</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Kiểm tra trực tiếp thuật toán đối sánh tiếng Việt, teencode, biến thể câu hỏi, CRUD IndexedDB và xử lý lỗi.
                  </p>
                </div>

                <button
                  onClick={handleRunTests}
                  disabled={isRunningTests}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-white text-xs font-bold transition-all flex items-center gap-2 shadow-md shadow-emerald-950/50 shrink-0"
                >
                  <Play className={`w-3.5 h-3.5 ${isRunningTests ? 'animate-spin' : ''}`} />
                  <span>{isRunningTests ? 'Đang kiểm tra...' : 'Chạy kiểm thử ngay'}</span>
                </button>
              </div>

              {/* Kết quả tổng quan */}
              {testResults && (
                <div className="p-3 bg-[#170f2f] rounded-xl border border-purple-500/25 flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-300">Tổng bài test: <strong>{testResults.total}</strong></span>
                  <span className="text-emerald-400 font-bold">Thành công: {testResults.passedCount}</span>
                  <span className={testResults.failedCount > 0 ? 'text-rose-400 font-bold' : 'text-slate-500'}>
                    Thất bại: {testResults.failedCount}
                  </span>
                </div>
              )}

              {/* Danh sách từng test case */}
              <div className="space-y-2.5">
                {testResults?.results.map((test) => (
                  <div
                    key={test.id}
                    className={`p-3.5 rounded-xl border text-xs transition-all ${
                      test.passed
                        ? 'bg-[#101b24] border-emerald-500/35 text-slate-200'
                        : 'bg-[#241014] border-rose-500/35 text-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 font-semibold">
                        {test.passed ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                        )}
                        <span className="text-white">{test.name}</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-900/40 text-purple-300 font-mono">
                          {test.category}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono shrink-0">{test.durationMs}ms</span>
                    </div>

                    <p className={`mt-1.5 pl-6 ${test.passed ? 'text-emerald-300' : 'text-rose-300'}`}>
                      {test.message}
                    </p>

                    {test.details && (
                      <p className="mt-0.5 pl-6 text-[10px] text-slate-400 font-mono">{test.details}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-[#170f2f] border-t border-purple-500/20 flex items-center justify-between text-xs text-slate-400">
          <span>Kho lưu trữ: IndexedDB & LocalStorage (Trình duyệt)</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-purple-900/60 hover:bg-purple-800 text-purple-200 hover:text-white font-semibold transition-all"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
