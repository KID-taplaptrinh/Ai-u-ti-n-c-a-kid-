import React, { useState } from 'react';
import { PRESET_CHARACTERS } from '../data/presetCharacters';
import { CustomCharacterData, ExpressionType } from '../types';
import { X, Upload, Check, Trash2, RotateCcw, Image, Sparkles, Smile, Frown, Sparkle, Volume2, Meh } from 'lucide-react';

interface CharacterSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeCharacterId: string;
  onSelectCharacter: (id: string) => void;
  customCharacter: CustomCharacterData | null;
  onSaveCustomCharacter: (data: CustomCharacterData) => void;
  onClearCustomCharacter: () => void;
}

const EXPRESSION_SLOTS: { key: ExpressionType; label: string; icon: React.ReactNode; desc: string }[] = [
  { key: 'idle', label: 'Bình thường (Mặc định)', icon: <Meh className="w-4 h-4 text-slate-300" />, desc: 'Ảnh chính hiển thị khi bot ở trạng thái chờ' },
  { key: 'happy', label: 'Vui vẻ', icon: <Smile className="w-4 h-4 text-pink-400" />, desc: 'Hiển thị khi bot khen ngợi, cảm ơn hoặc đùa vui' },
  { key: 'sad', label: 'Xúc động / Buồn', icon: <Frown className="w-4 h-4 text-blue-400" />, desc: 'Hiển thị khi bot an ủi hoặc chia sẻ tâm sự' },
  { key: 'thinking', label: 'Đang suy nghĩ', icon: <Sparkle className="w-4 h-4 text-amber-400" />, desc: 'Hiển thị khi bot tính toán hoặc tra cứu' },
  { key: 'speaking', label: 'Đang nói', icon: <Volume2 className="w-4 h-4 text-purple-400" />, desc: 'Hiển thị trong lúc phát âm thanh giọng nói' },
];

export const CharacterSelectorModal: React.FC<CharacterSelectorModalProps> = ({
  isOpen,
  onClose,
  activeCharacterId,
  onSelectCharacter,
  customCharacter,
  onSaveCustomCharacter,
  onClearCustomCharacter,
}) => {
  const [activeTab, setActiveTab] = useState<'presets' | 'custom'>('presets');
  const [customName, setCustomName] = useState(customCharacter?.name || 'Trợ lý tùy chỉnh');
  const [tempImages, setTempImages] = useState<Partial<Record<ExpressionType, string>>>(
    customCharacter?.images || {}
  );
  const [uploadError, setUploadError] = useState<string | null>(null);

  if (!isOpen) return null;

  // Xử lý đọc file ảnh PNG, JPG, WebP thành Base64 để lưu vào localStorage
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, slot: ExpressionType) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadError(null);
    const validTypes = ['image/png', 'image/jpeg', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      setUploadError('Chỉ hỗ trợ định dạng PNG, JPG hoặc WebP!');
      return;
    }

    if (file.size > 3 * 1024 * 1024) {
      setUploadError('Kích thước ảnh nên nhỏ hơn 3MB để lưu mượt mà trong trình duyệt!');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setTempImages((prev) => ({
        ...prev,
        [slot]: result,
      }));
    };
    reader.onerror = () => {
      setUploadError('Không thể đọc file ảnh. Vui lòng thử lại.');
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveSlotImage = (slot: ExpressionType) => {
    setTempImages((prev) => {
      const copy = { ...prev };
      delete copy[slot];
      return copy;
    });
  };

  const handleApplyCustom = () => {
    if (Object.keys(tempImages).length === 0) {
      setUploadError('Vui lòng tải lên ít nhất 1 ảnh đại diện mặc định!');
      return;
    }

    const newCustomData: CustomCharacterData = {
      id: 'custom',
      name: customName.trim() || 'Trợ lý tùy chỉnh',
      images: tempImages,
      updatedAt: Date.now(),
    };

    onSaveCustomCharacter(newCustomData);
    onSelectCharacter('custom');
    onClose();
  };

  const handleResetToDefault = () => {
    onClearCustomCharacter();
    onSelectCharacter('aoi');
    setTempImages({});
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-3xl max-h-[90vh] bg-[#120b24] border border-purple-500/30 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-slate-100">
        {/* Header Modal */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-purple-500/20 bg-[#160e2e]">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-5 h-5 text-purple-400" />
            <div>
              <h2 className="text-lg font-bold text-white tracking-wide">Nhân vật của tôi</h2>
              <p className="text-xs text-purple-300/80">Chọn trợ lý anime có sẵn hoặc tùy biến tải ảnh riêng</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-purple-900/40 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center px-6 pt-3 border-b border-purple-500/15 gap-4">
          <button
            onClick={() => setActiveTab('presets')}
            className={`pb-2.5 text-sm font-semibold transition-all relative ${
              activeTab === 'presets'
                ? 'text-purple-300 after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-purple-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Thư viện có sẵn ({PRESET_CHARACTERS.length})
          </button>
          <button
            onClick={() => setActiveTab('custom')}
            className={`pb-2.5 text-sm font-semibold transition-all relative flex items-center gap-1.5 ${
              activeTab === 'custom'
                ? 'text-purple-300 after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-purple-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Tự tải ảnh tùy chỉnh</span>
            {customCharacter && (
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            )}
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {uploadError && (
            <div className="p-3 bg-red-950/60 border border-red-500/40 rounded-xl text-xs text-red-200 flex items-center justify-between">
              <span>{uploadError}</span>
              <button onClick={() => setUploadError(null)} className="text-red-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {activeTab === 'presets' ? (
            /* Tab 1: Danh sách nhân vật anime có sẵn */
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {PRESET_CHARACTERS.map((char) => {
                const isSelected = activeCharacterId === char.id;
                return (
                  <div
                    key={char.id}
                    onClick={() => onSelectCharacter(char.id)}
                    className={`group relative p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'bg-[#231545] border-purple-400 shadow-lg shadow-purple-900/40 scale-[1.01]'
                        : 'bg-[#180f33]/70 border-purple-500/20 hover:border-purple-400/50 hover:bg-[#1f133f]'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      {/* Avatar preview nhỏ */}
                      <div
                        className="w-14 h-14 rounded-xl flex items-center justify-center font-bold text-lg text-white shadow-md shrink-0"
                        style={{ backgroundColor: `${char.accentColor}25`, border: `1.5px solid ${char.accentColor}` }}
                      >
                        {char.name.charAt(0)}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h3 className="font-bold text-white text-base truncate">{char.name}</h3>
                          <span
                            className="text-[11px] font-medium px-2 py-0.5 rounded-full"
                            style={{ backgroundColor: `${char.accentColor}20`, color: char.accentColor }}
                          >
                            {char.tag}
                          </span>
                        </div>
                        <p className="text-xs text-purple-200/90 font-medium mt-0.5">{char.subtitle}</p>
                        <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                          {char.description}
                        </p>
                      </div>
                    </div>

                    <div className="mt-3 pt-3 border-t border-purple-500/15 flex items-center justify-between">
                      <span className="text-[11px] text-slate-400">
                        Tính cách: <span className="text-purple-300 font-medium">{char.personality}</span>
                      </span>
                      {isSelected ? (
                        <span className="flex items-center gap-1 text-xs font-semibold text-emerald-400 bg-emerald-950/40 px-2.5 py-1 rounded-full border border-emerald-500/30">
                          <Check className="w-3.5 h-3.5" /> Đang dùng
                        </span>
                      ) : (
                        <button
                          type="button"
                          className="text-xs font-medium text-purple-300 group-hover:text-white px-2.5 py-1 rounded-lg bg-purple-900/30 group-hover:bg-purple-700/60 transition-colors"
                        >
                          Chọn nhân vật
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            /* Tab 2: Tùy biến nhân vật tự tải */
            <div className="space-y-6">
              {/* Tên nhân vật */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Tên nhân vật của bạn
                </label>
                <input
                  type="text"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  placeholder="Ví dụ: Sakura, Trợ lý của tôi..."
                  className="w-full px-3.5 py-2 rounded-xl bg-[#1b1236] border border-purple-500/30 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-purple-400"
                />
              </div>

              {/* Thông tin giải thích quy tắc ảnh biểu cảm */}
              <div className="p-3.5 rounded-xl bg-purple-950/40 border border-purple-500/30 text-xs text-purple-200/90 leading-relaxed space-y-1">
                <p className="font-semibold text-purple-300 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-pink-400" />
                  Nguyên tắc xử lý ảnh biểu cảm thông minh:
                </p>
                <p>
                  • Bạn chỉ cần tải ít nhất <strong>1 ảnh đại diện mặc định</strong> (Bình thường). Nếu chưa có đủ ảnh các cảm xúc khác, hệ thống sẽ giữ nguyên ảnh đại diện trang trọng kèm nhãn tâm trạng thay vì làm méo mó khuôn mặt!
                </p>
                <p>• Hỗ trợ định dạng: <strong>PNG, JPG, WebP</strong>. Ảnh được lưu an toàn trong trình duyệt (LocalStorage).</p>
              </div>

              {/* Danh sách 5 slot biểu cảm */}
              <div className="space-y-3">
                <span className="text-xs font-semibold text-slate-300">
                  Tải lên ảnh biểu cảm (5 trạng thái):
                </span>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {EXPRESSION_SLOTS.map((slot) => {
                    const hasImage = Boolean(tempImages[slot.key]);
                    return (
                      <div
                        key={slot.key}
                        className={`p-3 rounded-xl border flex items-center justify-between gap-3 ${
                          hasImage
                            ? 'bg-[#1d133b] border-purple-500/40'
                            : 'bg-[#150d2b] border-purple-500/20'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          {/* Khung thumbnail */}
                          <div className="w-12 h-12 rounded-lg bg-[#0e081f] border border-purple-500/30 flex items-center justify-center overflow-hidden shrink-0">
                            {hasImage ? (
                              <img
                                src={tempImages[slot.key]}
                                alt={slot.label}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <Image className="w-5 h-5 text-purple-400/50" />
                            )}
                          </div>

                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5">
                              {slot.icon}
                              <span className="text-xs font-semibold text-white truncate">
                                {slot.label}
                              </span>
                            </div>
                            <p className="text-[10px] text-slate-400 truncate mt-0.5">{slot.desc}</p>
                          </div>
                        </div>

                        {/* Nút upload hoặc xóa */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          <label className="cursor-pointer px-2.5 py-1.5 rounded-lg bg-purple-900/40 hover:bg-purple-700/60 border border-purple-500/40 text-purple-200 text-xs font-medium flex items-center gap-1 transition-colors">
                            <Upload className="w-3.5 h-3.5" />
                            <span>{hasImage ? 'Đổi' : 'Tải lên'}</span>
                            <input
                              type="file"
                              accept="image/png, image/jpeg, image/webp"
                              className="hidden"
                              onChange={(e) => handleFileUpload(e, slot.key)}
                            />
                          </label>

                          {hasImage && (
                            <button
                              type="button"
                              onClick={() => handleRemoveSlotImage(slot.key)}
                              className="p-1.5 rounded-lg bg-red-950/40 hover:bg-red-800/60 text-red-300 border border-red-500/30 transition-colors"
                              title="Xóa ảnh này"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Nút hành động cho Custom */}
              <div className="pt-4 border-t border-purple-500/20 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={handleResetToDefault}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1.5 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Quay về mặc định (Aoi)</span>
                </button>

                <div className="flex items-center gap-2">
                  {customCharacter && (
                    <button
                      type="button"
                      onClick={() => {
                        onClearCustomCharacter();
                        setTempImages({});
                      }}
                      className="px-3.5 py-2 rounded-xl bg-red-950/40 hover:bg-red-900/60 text-red-300 text-xs font-medium border border-red-500/40 flex items-center gap-1.5 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Xóa nhân vật tùy chỉnh</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={handleApplyCustom}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white text-xs font-bold shadow-lg shadow-purple-900/40 flex items-center gap-1.5 transition-all"
                  >
                    <Check className="w-4 h-4" />
                    <span>Lưu & Sử dụng nhân vật này</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
