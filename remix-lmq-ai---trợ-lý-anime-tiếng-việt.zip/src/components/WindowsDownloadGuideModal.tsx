import React from 'react';
import { X, Monitor, Download, Chrome, CheckCircle2, Copy, Check } from 'lucide-react';

interface WindowsDownloadGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WindowsDownloadGuideModal: React.FC<WindowsDownloadGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!isOpen) return null;

  const handleCopyShortcut = () => {
    navigator.clipboard.writeText('Ctrl + S');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-[#120b24] border border-purple-500/35 rounded-2xl shadow-2xl overflow-hidden text-slate-100 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-purple-500/20 bg-[#160e2e]">
          <div className="flex items-center gap-2.5">
            <Monitor className="w-5 h-5 text-cyan-400" />
            <div>
              <h2 className="text-base font-bold text-white">Hướng dẫn chạy LMQ AI trên Windows</h2>
              <p className="text-xs text-purple-300/80">Chạy trực tiếp trên trình duyệt, không cần cài đặt phức tạp</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-purple-900/40 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 overflow-y-auto">
          {/* Cách 1: Cài đặt như ứng dụng Windows độc lập (PWA / App Mode) */}
          <div className="p-4 rounded-xl bg-[#180f33] border border-purple-500/25 space-y-2">
            <div className="flex items-center gap-2 text-purple-300 font-bold text-sm">
              <Chrome className="w-4 h-4 text-cyan-400" />
              <span>Cách 1: Ghim thành Ứng dụng Desktop trên Windows (Khuyên dùng)</span>
            </div>
            <ol className="list-decimal pl-5 space-y-1.5 text-xs text-slate-300 leading-relaxed">
              <li>Mở trang web này trên <strong>Google Chrome</strong> hoặc <strong>Microsoft Edge</strong> trên máy tính Windows.</li>
              <li>Bấm vào biểu tượng menu ba chấm <code>⋮</code> ở góc trên cùng bên phải trình duyệt.</li>
              <li>
                Chọn <strong>Lưu và chia sẻ (Save and share)</strong> &gt; chọn <strong>Cài đặt trang này làm ứng dụng (Install this site as an app)</strong>.
              </li>
              <li>
                Bấm <strong>Cài đặt</strong>. Ngay lập tức LMQ AI sẽ mở ra trong một cửa sổ riêng biệt không có thanh địa chỉ trình duyệt, có icon trên Desktop và Taskbar Windows hệt như một phần mềm Windows nguyên bản!
              </li>
            </ol>
          </div>

          {/* Cách 2: Tải và lưu ngoại tuyến (Offline) */}
          <div className="p-4 rounded-xl bg-[#180f33] border border-purple-500/25 space-y-2">
            <div className="flex items-center gap-2 text-purple-300 font-bold text-sm">
              <Download className="w-4 h-4 text-pink-400" />
              <span>Cách 2: Lưu trang để sử dụng ngoại tuyến (Offline)</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Vì LMQ AI là ứng dụng 100% dựa trên quy tắc JavaScript chạy tại client (không phụ thuộc vào API server AI):
            </p>
            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-[#0e081f] border border-purple-500/30 text-xs">
              <span className="text-purple-300 font-mono">Bấm phím tắt trên Windows:</span>
              <button
                type="button"
                onClick={handleCopyShortcut}
                className="px-2 py-1 rounded bg-purple-900/60 text-white font-mono font-bold flex items-center gap-1 hover:bg-purple-700/60"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>Ctrl + S</span>
              </button>
              <span className="text-slate-400">và chọn lưu định dạng <strong>Webpage, Complete</strong>.</span>
            </div>
            <p className="text-xs text-slate-300">
              Sau khi tải về, bạn có thể nhấp đúp vào tệp <code>index.html</code> để mở trò chuyện mọi lúc kể cả khi mất kết nối mạng Internet!
            </p>
          </div>

          {/* Các điểm đảm bảo an toàn & quyền riêng tư */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div className="p-3 rounded-lg bg-emerald-950/30 border border-emerald-500/30 flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div className="text-xs">
                <span className="font-semibold text-emerald-300">100% Miễn phí & Cục bộ</span>
                <p className="text-slate-400 mt-0.5">Không cần khóa API, không quảng cáo, không tốn phí duy trì.</p>
              </div>
            </div>

            <div className="p-3 rounded-lg bg-purple-950/30 border border-purple-500/30 flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
              <div className="text-xs">
                <span className="font-semibold text-purple-300">Bảo mật dữ liệu tuyệt đối</span>
                <p className="text-slate-400 mt-0.5">Tin nhắn và ảnh nhân vật chỉ lưu trong bộ nhớ máy tính bạn.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-purple-500/20 bg-[#160e2e] flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-colors"
          >
            Đã hiểu
          </button>
        </div>
      </div>
    </div>
  );
};
