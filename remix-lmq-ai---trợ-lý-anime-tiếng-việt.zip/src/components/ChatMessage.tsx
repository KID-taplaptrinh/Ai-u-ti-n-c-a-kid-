import React, { useState } from 'react';
import { Message } from '../types';
import { MarkdownMathRenderer } from './MarkdownMathRenderer';
import {
  Volume2,
  VolumeX,
  ExternalLink,
  Copy,
  Check,
  Sparkles,
  Swords,
  BookOpen,
  PlusCircle,
} from 'lucide-react';

interface ChatMessageProps {
  message: Message;
  botName: string;
  onSpeak: (text: string, messageId: string) => void;
  isSpeaking: boolean;
  onStopSpeak: () => void;
  onOpenGame?: (gameType: 'caro' | 'chess') => void;
  onOpenKnowledge?: () => void;
  onTeach?: (question: string) => void;
  onSelectPrompt?: (text: string) => void;
  onAskGemini?: (question: string) => void;
  geminiAvailable?: boolean;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({
  message,
  botName,
  onSpeak,
  isSpeaking,
  onStopSpeak,
  onOpenGame,
  onOpenKnowledge,
  onTeach,
  onSelectPrompt,
  onAskGemini,
  geminiAvailable = false,
}) => {
  const [copied, setCopied] = useState(false);
  const isUser = message.sender === 'user';

  const handleCopy = () => {
    navigator.clipboard.writeText(message.text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenGoogleSearch = () => {
    if (!message.queryForSearch) return;
    const url = `https://www.google.com/search?q=${encodeURIComponent(message.queryForSearch)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'} group animate-fadeIn`}>
      {/* Bot Avatar Icon */}
      {!isUser && (
        <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-600 to-pink-500 flex items-center justify-center text-white text-xs font-bold shadow-md shadow-purple-900/50 shrink-0 mt-1">
          <Sparkles className="w-4 h-4 text-white" />
        </div>
      )}

      {/* Bong bóng tin nhắn */}
      <div className={`max-w-[85%] sm:max-w-[75%] flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
        {/* Header tin nhắn (Tên + Giờ) */}
        <div className="flex items-center gap-2 mb-1 text-[11px] text-slate-400 px-1">
          <span className="font-medium text-slate-300">{isUser ? 'Bạn' : botName}</span>
          {message.matchedKnowledge && (
            <span className="px-1.5 py-0.2 rounded bg-cyan-950/80 border border-cyan-500/40 text-[10px] text-cyan-300 font-mono flex items-center gap-1">
              <BookOpen className="w-2.5 h-2.5 text-cyan-400" /> Kho Tri Thức
            </span>
          )}
          {message.isGeminiAi && (
            <span className="px-1.5 py-0.2 rounded bg-indigo-950/80 border border-indigo-400/40 text-[10px] text-indigo-300 font-mono flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5 text-indigo-400" /> Gemini AI
            </span>
          )}
          <span>·</span>
          <span>{message.timestamp}</span>
        </div>

        {/* Khung nội dung */}
        <div
          className={`p-3.5 rounded-2xl text-sm transition-all duration-200 relative ${
            isUser
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-tr-sm shadow-lg shadow-purple-900/20'
              : 'bg-[#181030] text-slate-100 rounded-tl-sm border border-purple-500/25 shadow-md shadow-purple-950/30'
          }`}
        >
          <MarkdownMathRenderer text={message.text} />

          {/* Nút hành động mở Kho Kiến Thức khi có lệnh */}
          {message.triggerKnowledgeModal && onOpenKnowledge && (
            <div className="mt-3 pt-2.5 border-t border-purple-500/20">
              <button
                type="button"
                onClick={onOpenKnowledge}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-md shadow-cyan-950/50 hover:scale-[1.02]"
              >
                <BookOpen className="w-4 h-4 text-cyan-200" />
                <span>Mở Kho Kiến Thức Cục Bộ</span>
              </button>
            </div>
          )}

          {/* Nút hành động mở Bàn cờ khi có lệnh hoặc lời mời chơi cờ */}
          {message.triggerGame && onOpenGame && (
            <div className="mt-3 pt-2.5 border-t border-purple-500/20">
              <button
                type="button"
                onClick={() => onOpenGame(message.triggerGame || 'caro')}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-md shadow-purple-950/50 hover:scale-[1.02]"
              >
                <Swords className="w-4 h-4" />
                <span>
                  {message.triggerGame === 'chess'
                    ? 'Mở Bàn Cờ Vua đấu cùng Bot'
                    : 'Mở Bàn Cờ Caro đấu cùng Bot'}
                </span>
              </button>
            </div>
          )}

          {/* Nút hành động fallback: Hỏi Gemini AI, Dạy câu trả lời hoặc Tra cứu Google */}
          {(message.queryForSearch || message.triggerTeach) && (
            <div className="mt-3 pt-2.5 border-t border-purple-500/20 flex flex-wrap gap-2 items-center">
              {geminiAvailable && message.triggerTeach && onAskGemini && (
                <button
                  type="button"
                  onClick={() => onAskGemini(message.triggerTeach || '')}
                  className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-md shadow-indigo-950/40"
                >
                  <Sparkles className="w-3.5 h-3.5 text-cyan-200" />
                  <span>Hỏi Gemini AI (Miễn phí)</span>
                </button>
              )}

              {message.triggerTeach && onTeach && (
                <button
                  type="button"
                  onClick={() => onTeach(message.triggerTeach || '')}
                  className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-md shadow-purple-950/40"
                >
                  <PlusCircle className="w-3.5 h-3.5 text-pink-200" />
                  <span>Dạy câu này cho LMQ AI</span>
                </button>
              )}

              {message.queryForSearch && (
                <button
                  type="button"
                  onClick={handleOpenGoogleSearch}
                  className="px-3 py-1.5 rounded-xl bg-purple-900/50 hover:bg-purple-800 text-purple-200 hover:text-white border border-purple-500/40 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all shadow-sm"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Tra cứu Google</span>
                </button>
              )}
            </div>
          )}
          {/* Danh sách các câu hỏi gợi ý liên quan / tiếp theo */}
          {message.relatedSuggestions && message.relatedSuggestions.length > 0 && onSelectPrompt && (
            <div className="mt-3 pt-2.5 border-t border-purple-500/20">
              <div className="text-[11px] font-semibold text-cyan-300 mb-1.5 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-cyan-400" />
                <span>Gợi ý câu hỏi tiếp theo:</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {message.relatedSuggestions.map((sug, sIdx) => (
                  <button
                    key={sIdx}
                    type="button"
                    onClick={() => onSelectPrompt(sug)}
                    className="text-left text-xs px-2.5 py-1 rounded-lg bg-purple-950/80 hover:bg-purple-800 border border-purple-500/35 text-purple-200 hover:text-white transition-all shadow-sm hover:scale-[1.02]"
                  >
                    💬 {sug}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Thanh công cụ phụ dưới tin nhắn: Đọc to (TTS), Sao chép */}
        <div className="flex items-center gap-2 mt-1 px-1 opacity-0 group-hover:opacity-100 transition-opacity text-slate-400">
          {!isUser && (
            <button
              type="button"
              onClick={() => {
                if (isSpeaking) {
                  onStopSpeak();
                } else {
                  onSpeak(message.text, message.id);
                }
              }}
              className={`p-1 rounded hover:text-white transition-colors flex items-center gap-1 text-[11px] ${
                isSpeaking ? 'text-pink-400' : 'hover:bg-purple-900/40'
              }`}
              title={isSpeaking ? 'Dừng đọc' : 'Đọc câu này bằng giọng tiếng Việt'}
            >
              {isSpeaking ? <VolumeX className="w-3.5 h-3.5 animate-pulse" /> : <Volume2 className="w-3.5 h-3.5" />}
              <span>{isSpeaking ? 'Dừng' : 'Nghe'}</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleCopy}
            className="p-1 rounded hover:text-white hover:bg-purple-900/40 transition-colors flex items-center gap-1 text-[11px]"
            title="Sao chép nội dung"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Đã chép' : 'Sao chép'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
