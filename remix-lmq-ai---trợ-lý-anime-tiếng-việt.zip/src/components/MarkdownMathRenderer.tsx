import React from 'react';
import katex from 'katex';

interface MarkdownMathRendererProps {
  text: string;
}

function renderKatexHtml(expr: string, displayMode: boolean): string {
  try {
    return katex.renderToString(expr.trim(), {
      displayMode,
      throwOnError: false,
      strict: false,
    });
  } catch {
    return expr;
  }
}

/**
 * Scanner inline Markdown + LaTeX (tương thích mọi trình duyệt, không phụ thuộc lookbehind).
 * Thứ tự ưu tiên: `code` -> $$display math$$ -> $inline math$ -> ***bold italic*** -> **bold** -> *italic* -> [link](url)
 */
function renderInlineTokens(input: string, keyPrefix = 'in'): React.ReactNode[] {
  const nodes: React.ReactNode[] = [];
  let i = 0;
  let textBuffer = '';
  let tokenIdx = 0;

  const flushText = () => {
    if (textBuffer) {
      nodes.push(<React.Fragment key={`${keyPrefix}-t-${tokenIdx++}`}>{textBuffer}</React.Fragment>);
      textBuffer = '';
    }
  };

  while (i < input.length) {
    // 1. Inline code: `...`
    if (input[i] === '`') {
      const end = input.indexOf('`', i + 1);
      if (end !== -1) {
        flushText();
        const codeText = input.slice(i + 1, end);
        nodes.push(
          <code
            key={`${keyPrefix}-c-${tokenIdx++}`}
            className="px-1.5 py-0.5 rounded bg-purple-950/80 border border-purple-500/40 text-purple-200 text-[11px] font-mono"
          >
            {codeText}
          </code>
        );
        i = end + 1;
        continue;
      }
    }

    // 2. Display math inline: $$...$$
    if (input[i] === '$' && input[i + 1] === '$') {
      const end = input.indexOf('$$', i + 2);
      if (end !== -1) {
        flushText();
        const mathExpr = input.slice(i + 2, end);
        const html = renderKatexHtml(mathExpr, true);
        nodes.push(
          <span
            key={`${keyPrefix}-dm-${tokenIdx++}`}
            className="block my-2 px-3 py-2 rounded-xl bg-purple-950/50 border border-purple-500/35 text-cyan-200 overflow-x-auto text-center"
            dangerouslySetInnerHTML={{ __html: html }}
          />
        );
        i = end + 2;
        continue;
      }
    }

    // 3. Inline math: $...$ (không bắt đầu/kết thúc bằng khoảng trắng, không xuống dòng)
    if (input[i] === '$' && (i === 0 || input[i - 1] !== '\\')) {
      const nextChar = input[i + 1];
      if (nextChar && nextChar !== ' ' && nextChar !== '\n' && nextChar !== '$') {
        let end = i + 1;
        let found = -1;
        while (end < input.length) {
          if (input[end] === '\n') break;
          if (input[end] === '$' && input[end - 1] !== '\\') {
            if (input[end - 1] !== ' ') {
              found = end;
            }
            break;
          }
          end++;
        }
        if (found !== -1) {
          flushText();
          const mathExpr = input.slice(i + 1, found);
          const html = renderKatexHtml(mathExpr, false);
          nodes.push(
            <span
              key={`${keyPrefix}-m-${tokenIdx++}`}
              className="inline-block align-middle text-cyan-200 px-0.5"
              dangerouslySetInnerHTML={{ __html: html }}
            />
          );
          i = found + 1;
          continue;
        }
      }
    }

    // 4. Bold + Italic: ***...***
    if (input.startsWith('***', i)) {
      const end = input.indexOf('***', i + 3);
      if (end !== -1 && end > i + 3) {
        flushText();
        const inner = input.slice(i + 3, end);
        nodes.push(
          <strong key={`${keyPrefix}-bi-${tokenIdx++}`} className="font-semibold italic text-white">
            {renderInlineTokens(inner, `${keyPrefix}-bi-${tokenIdx}`)}
          </strong>
        );
        i = end + 3;
        continue;
      }
    }

    // 5. Bold: **...**
    if (input.startsWith('**', i)) {
      const end = input.indexOf('**', i + 2);
      if (end !== -1 && end > i + 2) {
        flushText();
        const inner = input.slice(i + 2, end);
        nodes.push(
          <strong key={`${keyPrefix}-b-${tokenIdx++}`} className="font-semibold text-white">
            {renderInlineTokens(inner, `${keyPrefix}-b-${tokenIdx}`)}
          </strong>
        );
        i = end + 2;
        continue;
      }
    }

    // 6. Italic: *...* (chỉ khớp khi không có khoảng trắng ngay sau * mở và trước * đóng)
    if (input[i] === '*' && input[i + 1] !== '*' && input[i + 1] && input[i + 1] !== ' ') {
      let searchIdx = i + 1;
      let end = -1;
      while (searchIdx < input.length) {
        if (input[searchIdx] === '\n') break;
        if (input[searchIdx] === '*' && input[searchIdx + 1] !== '*' && input[searchIdx - 1] !== ' ') {
          end = searchIdx;
          break;
        }
        searchIdx++;
      }
      if (end !== -1) {
        flushText();
        const inner = input.slice(i + 1, end);
        nodes.push(
          <em key={`${keyPrefix}-i-${tokenIdx++}`} className="italic text-purple-100/95">
            {renderInlineTokens(inner, `${keyPrefix}-i-${tokenIdx}`)}
          </em>
        );
        i = end + 1;
        continue;
      }
    }

    // 7. Markdown links: [text](https://...)
    if (input[i] === '[') {
      const closeBracket = input.indexOf(']', i + 1);
      if (closeBracket !== -1 && input[closeBracket + 1] === '(') {
        const closeParen = input.indexOf(')', closeBracket + 2);
        if (closeParen !== -1) {
          const label = input.slice(i + 1, closeBracket);
          const url = input.slice(closeBracket + 2, closeParen).trim();
          if (/^https?:\/\//i.test(url)) {
            flushText();
            nodes.push(
              <a
                key={`${keyPrefix}-a-${tokenIdx++}`}
                href={url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-cyan-300 hover:text-cyan-200 underline underline-offset-2"
              >
                {renderInlineTokens(label, `${keyPrefix}-a-${tokenIdx}`)}
              </a>
            );
            i = closeParen + 1;
            continue;
          }
        }
      }
    }

    textBuffer += input[i];
    i++;
  }

  flushText();
  return nodes;
}

function renderMarkdownBlocks(markdown: string, keyPrefix = 'blk'): React.ReactNode[] {
  const lines = markdown.replace(/\r\n/g, '\n').split('\n');
  const elements: React.ReactNode[] = [];
  let i = 0;
  let blockIdx = 0;

  while (i < lines.length) {
    const line = lines[i];
    const trimmed = line.trim();

    // Dòng trống
    if (!trimmed) {
      i++;
      continue;
    }

    // 1. Fenced code block: ```...```
    if (trimmed.startsWith('```')) {
      const lang = trimmed.slice(3).trim();
      const codeLines: string[] = [];
      i++;
      while (i < lines.length && !lines[i].trim().startsWith('```')) {
        codeLines.push(lines[i]);
        i++;
      }
      if (i < lines.length) i++; // skip closing ```
      elements.push(
        <div key={`${keyPrefix}-code-${blockIdx++}`} className="my-2 rounded-xl overflow-hidden border border-purple-500/30 bg-[#090514]">
          {lang && (
            <div className="px-3 py-1 bg-purple-950/60 border-b border-purple-500/20 text-[10px] font-mono uppercase tracking-wider text-purple-300">
              {lang}
            </div>
          )}
          <pre className="p-3 text-xs font-mono text-purple-200 overflow-x-auto selection:bg-purple-800">
            <code>{codeLines.join('\n')}</code>
          </pre>
        </div>
      );
      continue;
    }

    // 2. Display math block: $$...$$ (cả 1 dòng hoặc nhiều dòng)
    if (trimmed.startsWith('$$')) {
      if (trimmed.length > 2 && trimmed.endsWith('$$')) {
        const expr = trimmed.slice(2, -2);
        const html = renderKatexHtml(expr, true);
        elements.push(
          <div
            key={`${keyPrefix}-math-${blockIdx++}`}
            className="my-2 px-3 py-2.5 rounded-xl bg-purple-950/50 border border-purple-500/35 text-cyan-200 overflow-x-auto text-center"
            dangerouslySetInnerHTML={{ __html: html }}
          />
        );
        i++;
        continue;
      } else {
        const mathLines: string[] = [trimmed.slice(2)];
        i++;
        while (i < lines.length && !lines[i].trim().endsWith('$$')) {
          mathLines.push(lines[i]);
          i++;
        }
        if (i < lines.length) {
          const last = lines[i].trim();
          mathLines.push(last.slice(0, -2));
          i++;
        }
        const html = renderKatexHtml(mathLines.join('\n'), true);
        elements.push(
          <div
            key={`${keyPrefix}-math-${blockIdx++}`}
            className="my-2 px-3 py-2.5 rounded-xl bg-purple-950/50 border border-purple-500/35 text-cyan-200 overflow-x-auto text-center"
            dangerouslySetInnerHTML={{ __html: html }}
          />
        );
        continue;
      }
    }

    // 3. Horizontal rule: ---, ***, ___
    if (/^([-*_])\1{2,}$/.test(trimmed)) {
      elements.push(
        <hr key={`${keyPrefix}-hr-${blockIdx++}`} className="my-3 border-t border-purple-500/25" />
      );
      i++;
      continue;
    }

    // 4. Headings: # .. ####
    const headingMatch = trimmed.match(/^(#{1,4})\s+(.+)$/);
    if (headingMatch) {
      const level = headingMatch[1].length;
      const content = headingMatch[2];
      const sizeClass =
        level === 1
          ? 'text-base font-extrabold text-white mt-2 mb-1'
          : level === 2
          ? 'text-[15px] font-bold text-cyan-200 mt-2 mb-1'
          : level === 3
          ? 'text-sm font-bold text-purple-200 mt-2 mb-0.5'
          : 'text-xs font-bold text-purple-300 uppercase tracking-wide mt-1.5 mb-0.5';

      elements.push(
        <div key={`${keyPrefix}-h-${blockIdx++}`} className={sizeClass}>
          {renderInlineTokens(content, `${keyPrefix}-h-${blockIdx}`)}
        </div>
      );
      i++;
      continue;
    }

    // 5. Blockquote: > ...
    if (trimmed.startsWith('>')) {
      const quoteLines: string[] = [];
      while (i < lines.length && lines[i].trim().startsWith('>')) {
        quoteLines.push(lines[i].trim().replace(/^>\s?/, ''));
        i++;
      }
      elements.push(
        <blockquote
          key={`${keyPrefix}-bq-${blockIdx++}`}
          className="my-2 pl-3.5 pr-3 py-2 rounded-r-xl border-l-4 border-cyan-400/70 bg-purple-950/45 text-slate-200 space-y-1.5"
        >
          {renderMarkdownBlocks(quoteLines.join('\n'), `${keyPrefix}-bq-${blockIdx}`)}
        </blockquote>
      );
      continue;
    }

    // 6. Markdown Table: | ... |
    if (
      trimmed.startsWith('|') &&
      i + 1 < lines.length &&
      /^\|?[\s:-]+\|[\s|:-]*$/.test(lines[i + 1].trim())
    ) {
      const parseRow = (r: string) =>
        r
          .trim()
          .replace(/^\|/, '')
          .replace(/\|$/, '')
          .split('|')
          .map((c) => c.trim());

      const headers = parseRow(trimmed);
      i += 2; // skip header & separator
      const rows: string[][] = [];
      while (i < lines.length && lines[i].trim().startsWith('|')) {
        rows.push(parseRow(lines[i]));
        i++;
      }

      elements.push(
        <div key={`${keyPrefix}-tbl-${blockIdx++}`} className="my-2 overflow-x-auto rounded-xl border border-purple-500/25">
          <table className="w-full text-xs text-left border-collapse">
            <thead className="bg-purple-950/70 text-cyan-200">
              <tr>
                {headers.map((h, hIdx) => (
                  <th key={hIdx} className="px-3 py-2 font-semibold border-b border-purple-500/25">
                    {renderInlineTokens(h, `${keyPrefix}-th-${blockIdx}-${hIdx}`)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-500/15 bg-[#120b24]/60">
              {rows.map((row, rIdx) => (
                <tr key={rIdx}>
                  {headers.map((_, cIdx) => (
                    <td key={cIdx} className="px-3 py-1.5 text-slate-200">
                      {renderInlineTokens(row[cIdx] || '', `${keyPrefix}-td-${blockIdx}-${rIdx}-${cIdx}`)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
      continue;
    }

    // 7. Unordered list: * item hoặc - item
    if (/^\s*[-*•]\s+/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\s*[-*•]\s+/.test(lines[i])) {
        items.push(lines[i].replace(/^\s*[-*•]\s+/, ''));
        i++;
      }
      elements.push(
        <ul key={`${keyPrefix}-ul-${blockIdx++}`} className="list-disc pl-5 space-y-1 text-slate-100">
          {items.map((item, idx) => (
            <li key={idx} className="leading-relaxed marker:text-purple-400">
              {renderInlineTokens(item, `${keyPrefix}-ul-${blockIdx}-${idx}`)}
            </li>
          ))}
        </ul>
      );
      continue;
    }

    // 8. Ordered list: 1. item
    if (/^\s*\d+[.)]\s+/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\s*\d+[.)]\s+/.test(lines[i])) {
        items.push(lines[i].replace(/^\s*\d+[.)]\s+/, ''));
        i++;
      }
      elements.push(
        <ol key={`${keyPrefix}-ol-${blockIdx++}`} className="list-decimal pl-5 space-y-1 text-slate-100">
          {items.map((item, idx) => (
            <li key={idx} className="leading-relaxed marker:text-cyan-400">
              {renderInlineTokens(item, `${keyPrefix}-ol-${blockIdx}-${idx}`)}
            </li>
          ))}
        </ol>
      );
      continue;
    }

    // 9. Normal paragraph (gom các dòng liên tiếp không phải block đặc biệt)
    const paraLines: string[] = [];
    while (
      i < lines.length &&
      lines[i].trim() !== '' &&
      !lines[i].trim().startsWith('```') &&
      !lines[i].trim().startsWith('$$') &&
      !lines[i].trim().startsWith('>') &&
      !/^([-*_])\1{2,}$/.test(lines[i].trim()) &&
      !/^(#{1,4})\s+/.test(lines[i].trim()) &&
      !/^\s*[-*•]\s+/.test(lines[i]) &&
      !/^\s*\d+[.)]\s+/.test(lines[i])
    ) {
      paraLines.push(lines[i]);
      i++;
    }

    elements.push(
      <p key={`${keyPrefix}-p-${blockIdx++}`} className="leading-relaxed">
        {paraLines.map((pLine, pIdx) => (
          <React.Fragment key={pIdx}>
            {renderInlineTokens(pLine, `${keyPrefix}-p-${blockIdx}-${pIdx}`)}
            {pIdx < paraLines.length - 1 && <br />}
          </React.Fragment>
        ))}
      </p>
    );
  }

  return elements;
}

export const MarkdownMathRenderer: React.FC<MarkdownMathRendererProps> = ({ text }) => {
  return <div className="space-y-2">{renderMarkdownBlocks(text)}</div>;
};
