import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { VRMLoaderPlugin, VRMUtils, VRM } from '@pixiv/three-vrm';
import { Upload, RotateCcw, HelpCircle, Sparkles, AlertCircle, Eye } from 'lucide-react';

interface VrmViewerProps {
  isSpeaking?: boolean;
}

export const VrmViewer: React.FC<VrmViewerProps> = ({ isSpeaking = false }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [currentVrm, setCurrentVrm] = useState<VRM | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [modelName, setModelName] = useState<string>('Mô hình Anime 3D Thủ tục (Demo)');
  const [showGuide, setShowGuide] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  const vrmRef = useRef<VRM | null>(null);
  const proceduralMeshRef = useRef<THREE.Group | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 320;
    const height = container.clientHeight || 320;

    // 1. Khởi tạo Scene & Camera
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0e091e);

    const camera = new THREE.PerspectiveCamera(35, width / height, 0.1, 20);
    camera.position.set(0, 1.25, 1.8);

    // 2. Renderer chuẩn PBR
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    // 3. Hệ thống ánh sáng Studio 3 điểm
    const ambientLight = new THREE.AmbientLight(0x7c3aed, 0.7);
    scene.add(ambientLight);

    const hemiLight = new THREE.HemisphereLight(0x38bdf8, 0x1e1438, 0.9);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff1f2, 1.8);
    keyLight.position.set(1.5, 2.5, 2);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0xec4899, 1.2);
    rimLight.position.set(-1.5, 1.8, -1.5);
    scene.add(rimLight);

    // Sàn và vòng tròn phản quang
    const floorGeo = new THREE.CylinderGeometry(1.2, 1.2, 0.05, 32);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x170f33,
      roughness: 0.35,
      metalness: 0.4,
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.position.y = -0.025;
    floor.receiveShadow = true;
    scene.add(floor);

    // Vòng tròn neon cyber dưới sàn
    const ringGeo = new THREE.RingGeometry(0.85, 0.88, 32);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0xa855f7,
      side: THREE.DoubleSide,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.005;
    scene.add(ring);

    // 4. Tạo mô hình Anime 3D thủ tục nhiều chi tiết (3-12 parts) làm demo ban đầu
    const characterGroup = new THREE.Group();

    // Đầu (Anime Head)
    const headGeo = new THREE.SphereGeometry(0.24, 32, 32);
    const skinMat = new THREE.MeshStandardMaterial({
      color: 0xffe4e6,
      roughness: 0.6,
      metalness: 0.05,
    });
    const head = new THREE.Mesh(headGeo, skinMat);
    head.position.set(0, 1.2, 0);
    head.castShadow = true;
    characterGroup.add(head);

    // Tóc chính (Anime Hair Dome)
    const hairGeo = new THREE.SphereGeometry(0.26, 32, 16, 0, Math.PI * 2, 0, Math.PI * 0.55);
    const hairMat = new THREE.MeshStandardMaterial({
      color: 0x7c3aed,
      roughness: 0.4,
      metalness: 0.2,
    });
    const hair = new THREE.Mesh(hairGeo, hairMat);
    hair.position.set(0, 1.23, -0.02);
    characterGroup.add(hair);

    // Hai lọn tóc hai bên (Twintails)
    const pigtailGeo = new THREE.ConeGeometry(0.08, 0.45, 16);
    const pigtailLeft = new THREE.Mesh(pigtailGeo, hairMat);
    pigtailLeft.position.set(-0.25, 1.05, -0.05);
    pigtailLeft.rotation.z = 0.35;
    characterGroup.add(pigtailLeft);

    const pigtailRight = new THREE.Mesh(pigtailGeo, hairMat);
    pigtailRight.position.set(0.25, 1.05, -0.05);
    pigtailRight.rotation.z = -0.35;
    characterGroup.add(pigtailRight);

    // Mắt Anime (2 Mắt hình elip)
    const eyeCanvas = document.createElement('canvas');
    eyeCanvas.width = 128;
    eyeCanvas.height = 128;
    const ctx = eyeCanvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#1e1b4b';
      ctx.beginPath();
      ctx.arc(64, 64, 55, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(64, 75, 35, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(50, 48, 14, 0, Math.PI * 2);
      ctx.arc(80, 80, 8, 0, Math.PI * 2);
      ctx.fill();
    }
    const eyeTexture = new THREE.CanvasTexture(eyeCanvas);
    eyeTexture.colorSpace = THREE.SRGBColorSpace;
    const eyeMat = new THREE.MeshBasicMaterial({ map: eyeTexture, transparent: true });

    const eyeGeo = new THREE.PlaneGeometry(0.07, 0.09);
    const leftEye = new THREE.Mesh(eyeGeo, eyeMat);
    leftEye.position.set(-0.08, 1.18, 0.22);
    characterGroup.add(leftEye);

    const rightEye = new THREE.Mesh(eyeGeo, eyeMat);
    rightEye.position.set(0.08, 1.18, 0.22);
    characterGroup.add(rightEye);

    // Thân áo Cyberpunk
    const bodyGeo = new THREE.CylinderGeometry(0.12, 0.18, 0.45, 24);
    const clothesMat = new THREE.MeshStandardMaterial({
      color: 0x1e153b,
      roughness: 0.5,
      metalness: 0.3,
    });
    const body = new THREE.Mesh(bodyGeo, clothesMat);
    body.position.set(0, 0.8, 0);
    body.castShadow = true;
    characterGroup.add(body);

    // Viền cổ áo neon
    const collarGeo = new THREE.TorusGeometry(0.13, 0.015, 16, 32);
    const neonMat = new THREE.MeshStandardMaterial({
      color: 0xec4899,
      emissive: 0xec4899,
      emissiveIntensity: 0.6,
    });
    const collar = new THREE.Mesh(collarGeo, neonMat);
    collar.position.set(0, 1.0, 0);
    collar.rotation.x = Math.PI / 2;
    characterGroup.add(collar);

    scene.add(characterGroup);
    proceduralMeshRef.current = characterGroup;

    // 5. Tương tác chuột xoay mô hình (Orbit)
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;
    let rotationY = 0;

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const deltaX = e.clientX - prevMouseX;
      rotationY += deltaX * 0.01;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;

      if (vrmRef.current) {
        vrmRef.current.scene.rotation.y = rotationY;
      } else if (proceduralMeshRef.current) {
        proceduralMeshRef.current.rotation.y = rotationY;
      }
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    container.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    // 6. Vòng lặp Animation Render mượt mà
    const clock = new THREE.Clock();
    let animationFrameId: number;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const delta = clock.getDelta();
      const elapsed = clock.getElapsedTime();

      // Nếu có mô hình VRM chuẩn
      if (vrmRef.current) {
        vrmRef.current.update(delta);

        // Nhịp thở hô hấp cho VRM
        const spine = vrmRef.current.humanoid?.getNormalizedBoneNode('spine');
        if (spine) {
          spine.position.y = Math.sin(elapsed * 2.5) * 0.005;
        }

        // Chớp mắt tự nhiên cho VRM
        const blinkValue = Math.sin(elapsed * 1.5) > 0.96 ? 1 : 0;
        vrmRef.current.expressionManager?.setValue('blink', blinkValue);

        // Khẩu hình khi bot đang nói
        if (isSpeaking) {
          const speakValue = Math.abs(Math.sin(elapsed * 12));
          vrmRef.current.expressionManager?.setValue('aa', speakValue);
        } else {
          vrmRef.current.expressionManager?.setValue('aa', 0);
        }
      } else if (proceduralMeshRef.current) {
        // Nhịp thở cho mô hình thủ tục
        proceduralMeshRef.current.position.y = Math.sin(elapsed * 2.2) * 0.02;
        // Nháy mắt nhẹ
        const eyeScale = Math.sin(elapsed * 1.8) > 0.94 ? 0.1 : 1;
        leftEye.scale.y = eyeScale;
        rightEye.scale.y = eyeScale;
      }

      renderer.render(scene, camera);
    };

    animate();

    // 7. Xử lý Resize
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || 320;
      const h = container.clientHeight || 320;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      container.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('resize', handleResize);

      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
      floorGeo.dispose();
      floorMat.dispose();
      ringGeo.dispose();
      ringMat.dispose();
    };
  }, [isSpeaking]);

  // Hàm nạp file VRM người dùng tải lên từ máy tính
  const handleVrmFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoadError(null);
    setIsLoading(true);

    const blobUrl = URL.createObjectURL(file);
    const loader = new GLTFLoader();

    // Đăng ký Plugin VRM chính thức của Pixiv
    loader.register((parser) => new VRMLoaderPlugin(parser));

    loader.load(
      blobUrl,
      (gltf) => {
        const vrm = gltf.userData.vrm as VRM;
        if (!vrm) {
          setLoadError('File tải lên không chứa cấu trúc VRM hợp lệ!');
          setIsLoading(false);
          URL.revokeObjectURL(blobUrl);
          return;
        }

        // Tối ưu hóa xoay và điều chỉnh trục tọa độ VRM
        VRMUtils.removeUnnecessaryVertices(gltf.scene);
        VRMUtils.removeUnnecessaryJoints(gltf.scene);

        // Ẩn mô hình procedural tạm thời nếu có
        if (proceduralMeshRef.current) {
          proceduralMeshRef.current.visible = false;
        }

        // Gỡ bỏ VRM cũ nếu có
        if (vrmRef.current) {
          VRMUtils.deepDispose(vrmRef.current.scene);
        }

        vrm.scene.rotation.y = Math.PI; // Quay mặt về phía trước
        vrm.scene.position.set(0, 0, 0);

        vrmRef.current = vrm;
        setCurrentVrm(vrm);
        setModelName(file.name.replace(/\.[^/.]+$/, ''));
        setIsLoading(false);
        URL.revokeObjectURL(blobUrl);
      },
      undefined,
      (error) => {
        console.error('Lỗi nạp VRM:', error);
        setLoadError('Không thể nạp tệp VRM. Hãy đảm bảo tệp chuẩn VRM 0.x hoặc 1.0.');
        setIsLoading(false);
        URL.revokeObjectURL(blobUrl);
      }
    );
  };

  const handleResetToDemo = () => {
    if (vrmRef.current) {
      VRMUtils.deepDispose(vrmRef.current.scene);
      vrmRef.current = null;
      setCurrentVrm(null);
    }
    if (proceduralMeshRef.current) {
      proceduralMeshRef.current.visible = true;
    }
    setModelName('Mô hình Anime 3D Thủ tục (Demo)');
    setLoadError(null);
  };

  return (
    <div className="flex flex-col items-center w-full">
      {/* Khung chứa 3D WebGL Canvas */}
      <div className="relative w-64 h-64 md:w-72 md:h-72 rounded-2xl overflow-hidden border border-purple-500/40 bg-[#0e091e] shadow-2xl shadow-purple-950/60 group">
        <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

        {/* Loading Spinner */}
        {isLoading && (
          <div className="absolute inset-0 bg-black/75 backdrop-blur-sm flex flex-col items-center justify-center p-4">
            <Sparkles className="w-8 h-8 text-purple-400 animate-spin mb-2" />
            <span className="text-xs text-purple-200 font-medium">Đang nạp mô hình 3D VRM...</span>
          </div>
        )}

        {/* Nút hỗ trợ & Trạng thái góc trên */}
        <div className="absolute top-2 left-2 right-2 flex items-center justify-between pointer-events-none">
          <span className="text-[10px] bg-purple-950/80 border border-purple-500/30 px-2 py-0.5 rounded-full text-purple-300 font-medium pointer-events-auto">
            3D VRM Three.js
          </span>

          <button
            type="button"
            onClick={() => setShowGuide((prev) => !prev)}
            className="p-1 rounded-full bg-black/60 hover:bg-purple-900/60 text-slate-300 hover:text-white border border-purple-500/30 pointer-events-auto transition-colors"
            title="Hướng dẫn nạp mô hình VRM"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>

        {/* Gợi ý tương tác chuột */}
        <div className="absolute bottom-2 left-2 right-2 text-center pointer-events-none">
          <span className="text-[9px] text-slate-400/80 bg-black/50 px-2 py-0.5 rounded">
            Kéo chuột để xoay 360°
          </span>
        </div>
      </div>

      {/* Thông tin mô hình hiện tại */}
      <div className="mt-2 text-center">
        <p className="text-xs font-semibold text-white flex items-center justify-center gap-1">
          <Eye className="w-3.5 h-3.5 text-cyan-400" />
          <span className="truncate max-w-[200px]">{modelName}</span>
        </p>
      </div>

      {/* Thông báo lỗi nếu có */}
      {loadError && (
        <div className="mt-2 p-2 bg-red-950/60 border border-red-500/40 rounded-lg text-[11px] text-red-200 flex items-center gap-1.5 max-w-xs">
          <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
          <span>{loadError}</span>
        </div>
      )}

      {/* Thanh công cụ nạp file VRM */}
      <div className="mt-3 flex items-center gap-2">
        <label className="cursor-pointer px-3 py-1.5 rounded-xl bg-purple-900/50 hover:bg-purple-700/60 border border-purple-500/40 text-purple-200 text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md">
          <Upload className="w-3.5 h-3.5" />
          <span>Tải file .VRM của bạn</span>
          <input
            type="file"
            accept=".vrm,.glb"
            className="hidden"
            onChange={handleVrmFileUpload}
          />
        </label>

        {currentVrm && (
          <button
            type="button"
            onClick={handleResetToDemo}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
            title="Quay lại mô hình demo"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Hướng dẫn chi tiết cách thêm mô hình VRM (VRoid Hub / Booth) */}
      {showGuide && (
        <div className="mt-3 p-3.5 rounded-xl bg-[#160e2e] border border-purple-500/30 text-xs text-slate-300 max-w-xs space-y-2 leading-relaxed animate-fadeIn">
          <div className="flex items-center justify-between text-purple-300 font-semibold border-b border-purple-500/20 pb-1">
            <span>Cách lấy mô hình VRM miễn phí:</span>
            <button onClick={() => setShowGuide(false)} className="text-slate-400 hover:text-white">✕</button>
          </div>
          <ol className="list-decimal pl-4 space-y-1 text-[11px] text-slate-300">
            <li>
              Truy cập <strong>VRoid Hub</strong> (hub.vroid.com) hoặc <strong>Booth.pm</strong> (tìm kiếm từ khóa <code>VRM free</code>).
            </li>
            <li>Tải file định dạng <strong>.vrm</strong> về máy tính của bạn.</li>
            <li>Bạn cũng có thể tự tạo nhân vật anime 3D độc quyền qua phần mềm miễn phí <strong>VRoid Studio</strong>.</li>
            <li>Bấm nút <strong>"Tải file .VRM của bạn"</strong> ở trên để nạp ngay vào LMQ AI!</li>
          </ol>
        </div>
      )}
    </div>
  );
};
