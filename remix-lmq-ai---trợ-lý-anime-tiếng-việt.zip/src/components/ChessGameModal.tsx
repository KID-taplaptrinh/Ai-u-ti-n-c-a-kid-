import React, { useState, useEffect, useRef } from 'react';
import {
  CaroBoard,
  createEmptyCaroBoard,
  checkCaroWin,
  getBestCaroMove,
  CaroWinResult,
  CARO_BOARD_SIZE,
} from '../services/caroEngine';
import {
  ChessBoard,
  createInitialChessBoard,
  cloneChessBoard,
  getLegalMoves,
  getBestChessMove,
  isKingInCheck,
  findKing,
  CHESS_SYMBOLS,
  playBoardSound,
  ChessColor,
  ChessMove,
} from '../services/chessEngine';
import { ExpressionType } from '../types';
import {
  RotateCcw,
  Volume2,
  VolumeX,
  X,
  Award,
  Sparkles,
  Swords,
  ChevronRight,
  RefreshCw,
  Trophy,
} from 'lucide-react';

interface ChessGameModalProps {
  isOpen: boolean;
  onClose: () => void;
  botName: string;
  initialGameType?: 'caro' | 'chess';
  onBotExpressionChange?: (expr: ExpressionType) => void;
}

export const ChessGameModal: React.FC<ChessGameModalProps> = ({
  isOpen,
  onClose,
  botName,
  initialGameType = 'caro',
  onBotExpressionChange,
}) => {
  // Chế độ chơi: 'caro' hoặc 'chess'
  const [gameMode, setGameMode] = useState<'caro' | 'chess'>(initialGameType);

  // Cấu hình âm thanh
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Lời bình luận của Anime Bot trong bàn cờ
  const [botCommentary, setBotCommentary] = useState<string>(
    'Xin chào bạn! Mình đã sẵn sàng rồi, hãy mở màn bằng một nước cờ thật đẹp nhé! (✿◠‿◠)'
  );

  // Thống kê tỉ số
  const [scores, setScores] = useState({
    caro: { player: 0, bot: 0, draw: 0 },
    chess: { player: 0, bot: 0, draw: 0 },
  });

  // --- STATE CỜ CARO ---
  const [caroBoard, setCaroBoard] = useState<CaroBoard>(() => createEmptyCaroBoard(CARO_BOARD_SIZE));
  const [caroTurn, setCaroTurn] = useState<'player' | 'bot'>('player');
  const [caroWinner, setCaroWinner] = useState<CaroWinResult | null>(null);
  const [caroHistory, setCaroHistory] = useState<CaroBoard[]>([]);
  const [lastCaroMove, setLastCaroMove] = useState<[number, number] | null>(null);

  // --- STATE CỜ VUA ---
  const [chessBoard, setChessBoard] = useState<ChessBoard>(() => createInitialChessBoard());
  const [chessTurn, setChessTurn] = useState<ChessColor>('white');
  const [selectedSquare, setSelectedSquare] = useState<[number, number] | null>(null);
  const [validChessMoves, setValidChessMoves] = useState<[number, number][]>([]);
  const [chessWinner, setChessWinner] = useState<'white' | 'black' | 'draw' | null>(null);
  const [chessHistory, setChessHistory] = useState<ChessBoard[]>([]);
  const [lastChessMove, setLastChessMove] = useState<{ from: [number, number]; to: [number, number] } | null>(null);
  const [isBotThinking, setIsBotThinking] = useState(false);

  // Cập nhật khi modal mở với loại cờ ban đầu
  useEffect(() => {
    if (isOpen && initialGameType) {
      setGameMode(initialGameType);
    }
  }, [isOpen, initialGameType]);

  const playSound = (type: 'place' | 'capture' | 'check' | 'win' | 'lose') => {
    if (soundEnabled) {
      playBoardSound(type);
    }
  };

  // --- XỬ LÝ NƯỚC ĐI CỜ CARO ---
  const handleCaroCellClick = (r: number, c: number) => {
    if (caroTurn !== 'player' || caroWinner?.winner || caroBoard[r][c] !== null || isBotThinking) {
      return;
    }

    playSound('place');
    const newBoard = caroBoard.map((row) => [...row]);
    newBoard[r][c] = 'X';

    setCaroHistory((prev) => [...prev, caroBoard]);
    setCaroBoard(newBoard);
    setLastCaroMove([r, c]);

    // Kiểm tra chiến thắng của người chơi
    const winResult = checkCaroWin(newBoard, CARO_BOARD_SIZE);
    if (winResult.winner === 'X') {
      setCaroWinner(winResult);
      playSound('win');
      setBotCommentary('Oa! Bạn đã tạo được 5 quân liên tiếp rồi! Bạn chơi cờ đỉnh quá đi! (≧◡≦)');
      setScores((s) => ({ ...s, caro: { ...s.caro, player: s.caro.player + 1 } }));
      onBotExpressionChange?.('happy');
      return;
    } else if (winResult.winner === 'draw') {
      setCaroWinner(winResult);
      setBotCommentary('Ván cờ bất phân thắng bại! Cả hai chúng ta đều rất kiên cường!');
      setScores((s) => ({ ...s, caro: { ...s.caro, draw: s.caro.draw + 1 } }));
      return;
    }

    // Chuyển lượt sang Bot
    setCaroTurn('bot');
    setIsBotThinking(true);
    onBotExpressionChange?.('thinking');
    setBotCommentary('Hmm... Nước cờ này khá hiểm, để mình tính toán một chút nha...');

    setTimeout(() => {
      const [botR, botC] = getBestCaroMove(newBoard, CARO_BOARD_SIZE);
      const botBoard = newBoard.map((row) => [...row]);
      botBoard[botR][botC] = 'O';

      setCaroBoard(botBoard);
      setLastCaroMove([botR, botC]);
      playSound('place');
      setIsBotThinking(false);

      const botWinResult = checkCaroWin(botBoard, CARO_BOARD_SIZE);
      if (botWinResult.winner === 'O') {
        setCaroWinner(botWinResult);
        playSound('lose');
        setBotCommentary('Yay! Mình đã nối được 5 quân rồi! Cảm ơn bạn vì một ván cờ tuyệt vời! (✿◠‿◠)');
        setScores((s) => ({ ...s, caro: { ...s.caro, bot: s.caro.bot + 1 } }));
        onBotExpressionChange?.('happy');
      } else if (botWinResult.winner === 'draw') {
        setCaroWinner(botWinResult);
        setBotCommentary('Bàn cờ đã kín rồi, ván này hòa nha!');
        setScores((s) => ({ ...s, caro: { ...s.caro, draw: s.caro.draw + 1 } }));
      } else {
        setCaroTurn('player');
        onBotExpressionChange?.('idle');
        const comments = [
          'Đến lượt bạn rồi đó, cẩn thận đường chặn của mình nha!',
          'Mình đã đáp trả rồi, bạn tính đi đâu tiếp đây?',
          'Ván cờ đang gay cấn quá (≧▽≦)!',
        ];
        setBotCommentary(comments[Math.floor(Math.random() * comments.length)]);
      }
    }, 450);
  };

  const handleResetCaro = () => {
    setCaroBoard(createEmptyCaroBoard(CARO_BOARD_SIZE));
    setCaroTurn('player');
    setCaroWinner(null);
    setCaroHistory([]);
    setLastCaroMove(null);
    setIsBotThinking(false);
    setBotCommentary('Ván cờ Caro mới đã sẵn sàng! Bạn đi trước nhé!');
    onBotExpressionChange?.('idle');
  };

  const handleUndoCaro = () => {
    if (caroHistory.length === 0 || isBotThinking || caroWinner?.winner) return;
    const previous = caroHistory[caroHistory.length - 1];
    setCaroBoard(previous);
    setCaroHistory((prev) => prev.slice(0, -1));
    setCaroTurn('player');
    setLastCaroMove(null);
    setBotCommentary('Đã quay lại nước trước! Bạn cân nhắc lại hướng đi nhé!');
  };

  // --- XỬ LÝ NƯỚC ĐI CỜ VUA ---
  const handleChessSquareClick = (r: number, c: number) => {
    if (chessTurn !== 'white' || chessWinner || isBotThinking) return;

    const piece = chessBoard[r][c];

    // Nếu người chơi bấm vào quân của mình (Màu Trắng)
    if (piece && piece.color === 'white') {
      setSelectedSquare([r, c]);
      const moves = getLegalMoves(chessBoard, r, c);
      setValidChessMoves(moves);
      return;
    }

    // Nếu đã chọn một quân cờ trước đó và nhấp vào ô đích hợp lệ
    if (selectedSquare) {
      const [fromR, fromC] = selectedSquare;
      const isValid = validChessMoves.some(([tr, tc]) => tr === r && tc === c);

      if (isValid) {
        const capturedPiece = chessBoard[r][c];
        const newBoard = cloneChessBoard(chessBoard);
        const movingPiece = newBoard[fromR][fromC]!;

        // Thực hiện di chuyển
        newBoard[r][c] = movingPiece;
        newBoard[fromR][fromC] = null;

        // Phong hậu cho tốt trắng nếu chạm hàng 0
        if (movingPiece.type === 'p' && r === 0) {
          newBoard[r][c] = { type: 'q', color: 'white' };
        }

        setChessHistory((prev) => [...prev, chessBoard]);
        setChessBoard(newBoard);
        setSelectedSquare(null);
        setValidChessMoves([]);
        setLastChessMove({ from: [fromR, fromC], to: [r, c] });

        if (capturedPiece) {
          playSound('capture');
          setBotCommentary(`Oa, bạn vừa ăn quân ${capturedPiece.type.toUpperCase()} của mình rồi! Hay lắm!`);
        } else {
          playSound('place');
        }

        // Kiểm tra xem nước đi có chiếu tướng Đen (Bot) không
        const isBotInCheck = isKingInCheck(newBoard, 'black');
        if (isBotInCheck) {
          playSound('check');
          onBotExpressionChange?.('thinking');
          setBotCommentary('Ái chà! Bạn chiếu tướng mình kìa! Để mình tìm đường thoát hiểm...');
        }

        // Chuyển lượt sang Bot (Đen)
        setChessTurn('black');
        setIsBotThinking(true);

        setTimeout(() => {
          const botMove = getBestChessMove(newBoard);
          if (!botMove) {
            // Không còn nước đi hợp lệ: Hoặc bị chiếu bí (Thua), hoặc Hòa (Stalemate)
            if (isBotInCheck) {
              setChessWinner('white');
              playSound('win');
              setBotCommentary('Chiếu bí rồi! Bạn chơi cờ vua xuất sắc quá, mình xin chịu thua ván này! (✿◠‿◠)');
              setScores((s) => ({ ...s, chess: { ...s.chess, player: s.chess.player + 1 } }));
              onBotExpressionChange?.('happy');
            } else {
              setChessWinner('draw');
              setBotCommentary('Thế cờ Pat (Hòa cờ)! Bot không còn nước đi hợp lệ và không bị chiếu!');
              setScores((s) => ({ ...s, chess: { ...s.chess, draw: s.chess.draw + 1 } }));
            }
            setIsBotThinking(false);
            return;
          }

          const botBoard = cloneChessBoard(newBoard);
          const movingBotPiece = botBoard[botMove.fromRow][botMove.fromCol]!;
          const capturedByBot = botBoard[botMove.toRow][botMove.toCol];

          botBoard[botMove.toRow][botMove.toCol] = movingBotPiece;
          botBoard[botMove.fromRow][botMove.fromCol] = null;

          // Phong hậu cho tốt đen
          if (movingBotPiece.type === 'p' && botMove.toRow === 7) {
            botBoard[botMove.toRow][botMove.toCol] = { type: 'q', color: 'black' };
          }

          setChessBoard(botBoard);
          setLastChessMove({ from: [botMove.fromRow, botMove.fromCol], to: [botMove.toRow, botMove.toCol] });
          setIsBotThinking(false);

          if (capturedByBot) {
            playSound('capture');
          } else {
            playSound('place');
          }

          // Kiểm tra xem Bot có chiếu tướng Người chơi không
          const isPlayerInCheck = isKingInCheck(botBoard, 'white');
          if (isPlayerInCheck) {
            playSound('check');
            onBotExpressionChange?.('happy');
            setBotCommentary('Chiếu tướng nha! Hãy cẩn thận nước đi tiếp theo của Vua nhé! (≧◡≦)');
          } else {
            setBotCommentary('Mình đã đi xong quân cờ rồi, tới lượt bạn trổ tài chiến thuật nè!');
          }

          setChessTurn('white');
        }, 600);
      } else {
        setSelectedSquare(null);
        setValidChessMoves([]);
      }
    }
  };

  const handleResetChess = () => {
    setChessBoard(createInitialChessBoard());
    setChessTurn('white');
    setSelectedSquare(null);
    setValidChessMoves([]);
    setChessWinner(null);
    setChessHistory([]);
    setLastChessMove(null);
    setIsBotThinking(false);
    setBotCommentary('Bàn cờ vua đã được xếp mới! Bạn cầm quân Trắng đi trước nhé!');
    onBotExpressionChange?.('idle');
  };

  const handleUndoChess = () => {
    if (chessHistory.length === 0 || isBotThinking || chessWinner) return;
    const previous = chessHistory[chessHistory.length - 1];
    setChessBoard(previous);
    setChessHistory((prev) => prev.slice(0, -1));
    setChessTurn('white');
    setSelectedSquare(null);
    setValidChessMoves([]);
    setLastChessMove(null);
    setBotCommentary('Đã hoàn lại nước đi cờ vua!');
  };

  if (!isOpen) return null;

  const currentScore = gameMode === 'caro' ? scores.caro : scores.chess;
  const isWhiteKingInCheck = gameMode === 'chess' && isKingInCheck(chessBoard, 'white');
  const isBlackKingInCheck = gameMode === 'chess' && isKingInCheck(chessBoard, 'black');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-[#120b24] border border-purple-500/40 rounded-3xl w-full max-w-4xl max-h-[96vh] flex flex-col shadow-2xl shadow-purple-950/80 overflow-hidden">
        {/* Header bàn cờ: Tabs chuyển đổi & Nút đóng */}
        <div className="px-5 py-4 border-b border-purple-500/20 flex items-center justify-between bg-[#190f33]/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-pink-500 flex items-center justify-center text-white shadow-lg shadow-purple-900/50">
              <Swords className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>Đấu Cờ Trực Tuyến với {botName}</span>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-purple-900/60 border border-purple-500/30 text-purple-300 font-mono">
                  AI Trực Quan
                </span>
              </h2>
              <p className="text-xs text-slate-400">Chọn chế độ cờ Caro hoặc Cờ Vua tiêu chuẩn</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`p-2 rounded-xl border transition-colors ${
                soundEnabled
                  ? 'bg-purple-900/40 border-purple-500/40 text-purple-200'
                  : 'bg-slate-900 border-slate-700 text-slate-500'
              }`}
              title={soundEnabled ? 'Tắt âm thanh cờ' : 'Bật âm thanh cờ'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-pink-400" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-purple-950/50 hover:bg-red-950/60 border border-purple-500/30 hover:border-red-500/40 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Thanh chuyển chế độ cờ (Segmented Tabs) */}
        <div className="px-5 py-2.5 bg-[#0f0920] border-b border-purple-500/15 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 p-1 bg-[#1a1033] rounded-xl border border-purple-500/20">
            <button
              onClick={() => setGameMode('caro')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                gameMode === 'caro'
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>⭕ Cờ Caro (Gomoku)</span>
            </button>
            <button
              onClick={() => setGameMode('chess')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                gameMode === 'chess'
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>♟️ Cờ Vua (Chess 8x8)</span>
            </button>
          </div>

          {/* Bảng tỉ số */}
          <div className="flex items-center gap-3 text-xs font-mono text-slate-300">
            <span className="flex items-center gap-1 text-emerald-400">
              <Trophy className="w-3.5 h-3.5" /> Thắng: {currentScore.player}
            </span>
            <span className="text-slate-500">|</span>
            <span className="text-rose-400">Thua: {currentScore.bot}</span>
            <span className="text-slate-500">|</span>
            <span className="text-amber-400">Hòa: {currentScore.draw}</span>
          </div>
        </div>

        {/* Bong bóng bình luận Anime Bot */}
        <div className="px-5 py-2.5 bg-gradient-to-r from-purple-950/40 via-[#180f30] to-purple-950/40 border-b border-purple-500/20 flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-500 to-pink-500 flex items-center justify-center text-white text-xs font-bold shrink-0">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div className="flex-1 text-xs text-purple-200">
            <span className="font-semibold text-white mr-1.5">{botName}:</span>
            <span className="italic">"{botCommentary}"</span>
          </div>
          {isBotThinking && (
            <div className="flex items-center gap-1.5 text-xs text-pink-400 shrink-0 font-medium animate-pulse">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>Đang tính nước đi...</span>
            </div>
          )}
        </div>

        {/* Vùng Bàn cờ chính */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-5 flex flex-col items-center justify-center bg-[#0d071c]">
          {gameMode === 'caro' ? (
            /* --- BÀN CỜ CARO --- */
            <div className="flex flex-col items-center">
              <div className="mb-2 flex items-center justify-between w-full max-w-[480px] text-xs text-slate-300 px-1">
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-cyan-400 inline-block"></span>
                  <span>Bạn: <strong>Quân X</strong></span>
                </span>
                <span className="font-semibold text-purple-300">
                  {caroWinner?.winner
                    ? caroWinner.winner === 'X'
                      ? '🎉 BẠN THẮNG!'
                      : caroWinner.winner === 'O'
                      ? 'BOT THẮNG!'
                      : 'HÒA CỜ'
                    : caroTurn === 'player'
                    ? 'Lượt của bạn'
                    : `${botName} đang đi...`}
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-pink-500 inline-block"></span>
                  <span>{botName}: <strong>Quân O</strong></span>
                </span>
              </div>

              {/* Lưới Caro 12x12 */}
              <div className="inline-block p-2 bg-[#171030] rounded-2xl border border-purple-500/40 shadow-xl overflow-x-auto max-w-full">
                <div
                  className="grid gap-[2px] bg-purple-950/60 p-1 rounded-xl"
                  style={{
                    gridTemplateColumns: `repeat(${CARO_BOARD_SIZE}, minmax(0, 1fr))`,
                  }}
                >
                  {caroBoard.map((row, r) =>
                    row.map((cell, c) => {
                      const isLast = lastCaroMove && lastCaroMove[0] === r && lastCaroMove[1] === c;
                      const isWinCell =
                        caroWinner?.line &&
                        caroWinner.line.some(([wr, wc]) => wr === r && wc === c);

                      return (
                        <button
                          key={`${r}-${c}`}
                          type="button"
                          onClick={() => handleCaroCellClick(r, c)}
                          disabled={caroTurn !== 'player' || !!caroWinner || cell !== null || isBotThinking}
                          className={`w-7 h-7 sm:w-9 sm:h-9 rounded-md flex items-center justify-center font-bold text-sm sm:text-base transition-all select-none ${
                            isWinCell
                              ? 'bg-emerald-500 text-white animate-bounce shadow-lg shadow-emerald-500/50 scale-105 z-10'
                              : isLast
                              ? 'bg-purple-800/80 ring-2 ring-purple-400'
                              : 'bg-[#100a22] hover:bg-purple-900/50'
                          } ${cell === null && caroTurn === 'player' ? 'cursor-pointer hover:border-purple-400/50' : ''}`}
                        >
                          {cell === 'X' && (
                            <span className="text-cyan-400 drop-shadow-[0_0_6px_rgba(34,211,238,0.8)]">✕</span>
                          )}
                          {cell === 'O' && (
                            <span className="text-pink-400 drop-shadow-[0_0_6px_rgba(244,114,182,0.8)]">◯</span>
                          )}
                        </button>
                      );
                    })
                  )}
                </div>
              </div>
            </div>
          ) : (
            /* --- BÀN CỜ VUA 8x8 --- */
            <div className="flex flex-col items-center">
              <div className="mb-2 flex items-center justify-between w-full max-w-[440px] text-xs text-slate-300 px-1">
                <span className="flex items-center gap-1.5">
                  <span className="text-base text-white">♔</span>
                  <span>Bạn (Quân Trắng)</span>
                </span>
                <span className="font-semibold text-purple-300">
                  {chessWinner
                    ? chessWinner === 'white'
                      ? '🎉 BẠN THẮNG!'
                      : chessWinner === 'black'
                      ? 'BOT THẮNG!'
                      : 'HÒA CỜ'
                    : isWhiteKingInCheck
                    ? '⚠️ BẠN ĐANG BỊ CHIẾU TƯỚNG!'
                    : isBlackKingInCheck
                    ? '⚡ ĐỐI THỦ ĐANG BỊ CHIẾU!'
                    : chessTurn === 'white'
                    ? 'Lượt của bạn'
                    : `${botName} đang suy nghĩ...`}
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="text-base text-pink-400">♚</span>
                  <span>{botName} (Quân Đen)</span>
                </span>
              </div>

              {/* Khung Bàn cờ 8x8 với tọa độ */}
              <div className="relative p-2.5 sm:p-3 bg-[#191030] rounded-2xl border border-purple-500/40 shadow-2xl">
                {/* Tọa độ cột trên (A - H) */}
                <div className="grid grid-cols-8 text-center text-[10px] font-mono text-purple-300/80 mb-1">
                  {['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'].map((col) => (
                    <span key={col}>{col.toUpperCase()}</span>
                  ))}
                </div>

                <div className="flex">
                  {/* Tọa độ hàng trái (8 - 1) */}
                  <div className="flex flex-col justify-around text-[10px] font-mono text-purple-300/80 mr-1.5">
                    {[8, 7, 6, 5, 4, 3, 2, 1].map((row) => (
                      <span key={row} className="h-9 sm:h-12 flex items-center">
                        {row}
                      </span>
                    ))}
                  </div>

                  {/* Lưới 64 ô cờ vua */}
                  <div className="grid grid-cols-8 grid-rows-8 border-2 border-purple-900/80 rounded-xl overflow-hidden shadow-inner">
                    {chessBoard.map((row, r) =>
                      row.map((piece, c) => {
                        const isLight = (r + c) % 2 === 0;
                        const isSelected = selectedSquare && selectedSquare[0] === r && selectedSquare[1] === c;
                        const isValidDest = validChessMoves.some(([tr, tc]) => tr === r && tc === c);
                        const isKingChecked =
                          piece &&
                          piece.type === 'k' &&
                          ((piece.color === 'white' && isWhiteKingInCheck) ||
                            (piece.color === 'black' && isBlackKingInCheck));
                        const isLastMove =
                          lastChessMove &&
                          ((lastChessMove.from[0] === r && lastChessMove.from[1] === c) ||
                            (lastChessMove.to[0] === r && lastChessMove.to[1] === c));

                        return (
                          <button
                            key={`${r}-${c}`}
                            type="button"
                            onClick={() => handleChessSquareClick(r, c)}
                            className={`w-9 h-9 sm:w-12 sm:h-12 flex items-center justify-center relative select-none transition-colors ${
                              isSelected
                                ? 'bg-amber-400/80'
                                : isKingChecked
                                ? 'bg-rose-600/90 animate-pulse'
                                : isLastMove
                                ? isLight
                                  ? 'bg-purple-300/80'
                                  : 'bg-purple-800/80'
                                : isLight
                                ? 'bg-[#e2d5c3]'
                                : 'bg-[#7c5643]'
                            }`}
                          >
                            {/* Chấm tròn chỉ thị nước đi hợp lệ */}
                            {isValidDest && (
                              <div
                                className={`absolute rounded-full pointer-events-none z-10 ${
                                  piece
                                    ? 'w-7 h-7 sm:w-10 sm:h-10 border-4 border-emerald-400 bg-emerald-500/20'
                                    : 'w-3 h-3 bg-emerald-500 shadow-md shadow-emerald-500/80'
                                }`}
                              />
                            )}

                            {/* Quân cờ */}
                            {piece && (
                              <span
                                className={`text-2xl sm:text-3xl font-serif leading-none transition-transform ${
                                  isSelected ? 'scale-110' : ''
                                } ${
                                  piece.color === 'white'
                                    ? 'text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]'
                                    : 'text-slate-900 drop-shadow-[0_1px_2px_rgba(255,255,255,0.4)]'
                                }`}
                              >
                                {CHESS_SYMBOLS[piece.color][piece.type]}
                              </span>
                            )}
                          </button>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer: Các nút điều khiển Ván mới, Đi lại, Đóng */}
        <div className="px-5 py-3.5 bg-[#170f2f] border-t border-purple-500/20 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={gameMode === 'caro' ? handleResetCaro : handleResetChess}
              className="px-3.5 py-2 rounded-xl bg-purple-900/60 hover:bg-purple-800 text-purple-200 hover:text-white border border-purple-500/40 text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm"
            >
              <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
              <span>Ván mới</span>
            </button>

            <button
              onClick={gameMode === 'caro' ? handleUndoCaro : handleUndoChess}
              disabled={
                (gameMode === 'caro' ? caroHistory.length === 0 : chessHistory.length === 0) ||
                isBotThinking ||
                (gameMode === 'caro' ? !!caroWinner : !!chessWinner)
              }
              className="px-3.5 py-2 rounded-xl bg-[#201440] hover:bg-purple-900/40 disabled:opacity-40 disabled:cursor-not-allowed text-slate-300 hover:text-white border border-purple-500/25 text-xs font-semibold flex items-center gap-1.5 transition-all"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Đi lại (Undo)</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white text-xs font-bold transition-all shadow-md shadow-purple-950/40"
          >
            Đóng & Quay lại Chat
          </button>
        </div>
      </div>
    </div>
  );
};
