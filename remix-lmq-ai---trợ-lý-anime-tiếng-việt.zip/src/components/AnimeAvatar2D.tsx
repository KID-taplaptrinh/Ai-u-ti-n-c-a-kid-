import React, { useEffect, useState } from 'react';
import { ExpressionType, CustomCharacterData } from '../types';
import { Smile, Frown, Sparkles, Volume2, Meh } from 'lucide-react';

interface AnimeAvatar2DProps {
  characterId: string;
  expression: ExpressionType;
  customCharacter?: CustomCharacterData | null;
  isSpeaking?: boolean;
}

export const AnimeAvatar2D: React.FC<AnimeAvatar2DProps> = ({
  characterId,
  expression,
  customCharacter,
  isSpeaking = false,
}) => {
  const [isBlinking, setIsBlinking] = useState(false);
  const [mouthOpen, setMouthOpen] = useState(false);

  // Chu kỳ chớp mắt tự nhiên
  useEffect(() => {
    let timeoutId: NodeJS.Timeout;

    const scheduleBlink = () => {
      const nextBlinkDelay = Math.random() * 3000 + 2500; // 2.5s - 5.5s
      timeoutId = setTimeout(() => {
        setIsBlinking(true);
        setTimeout(() => {
          setIsBlinking(false);
          scheduleBlink();
        }, 160);
      }, nextBlinkDelay);
    };

    scheduleBlink();
    return () => clearTimeout(timeoutId);
  }, []);

  // Chu kỳ chuyển động khẩu hình khi đang phát giọng nói
  useEffect(() => {
    let mouthInterval: NodeJS.Timeout;
    if (isSpeaking || expression === 'speaking') {
      mouthInterval = setInterval(() => {
        setMouthOpen((prev) => !prev);
      }, 180);
    } else {
      setMouthOpen(false);
    }
    return () => clearInterval(mouthInterval);
  }, [isSpeaking, expression]);

  // Nhãn cảm xúc tiếng Việt
  const expressionLabels: Record<ExpressionType, { label: string; icon: React.ReactNode; color: string }> = {
    idle: { label: 'Bình thường', icon: <Meh className="w-3.5 h-3.5" />, color: 'text-slate-300' },
    happy: { label: 'Vui vẻ', icon: <Smile className="w-3.5 h-3.5" />, color: 'text-pink-400' },
    sad: { label: 'Xúc động', icon: <Frown className="w-3.5 h-3.5" />, color: 'text-blue-400' },
    thinking: { label: 'Đang suy nghĩ', icon: <Sparkles className="w-3.5 h-3.5" />, color: 'text-amber-400' },
    speaking: { label: 'Đang nói', icon: <Volume2 className="w-3.5 h-3.5" />, color: 'text-purple-400' },
  };

  const currentStatus = expressionLabels[expression] || expressionLabels.idle;

  // Nếu là nhân vật tự tải lên (Custom Avatar)
  if (characterId === 'custom' && customCharacter) {
    const specificImage = customCharacter.images[expression];
    const defaultImage = customCharacter.images['idle'] || Object.values(customCharacter.images)[0];
    const activeImage = specificImage || defaultImage;

    return (
      <div className="flex flex-col items-center">
        <div className="relative group">
          {/* Vòng sáng nền */}
          <div
            className={`absolute -inset-1 rounded-3xl bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-500 opacity-60 blur-md transition-all duration-500 ${
              isSpeaking || expression === 'speaking' ? 'animate-pulse opacity-90' : 'group-hover:opacity-80'
            }`}
          />

          {/* Khung hiển thị ảnh avatar */}
          <div className="relative w-48 h-48 md:w-56 md:h-56 rounded-2xl overflow-hidden bg-[#160f2e] border-2 border-purple-500/40 shadow-2xl flex items-center justify-center">
            {activeImage ? (
              <img
                src={activeImage}
                alt={customCharacter.name}
                referrerPolicy="no-referrer"
                className={`w-full h-full object-cover transition-transform duration-300 ${
                  isSpeaking ? 'scale-105' : 'hover:scale-105'
                }`}
              />
            ) : (
              <div className="flex flex-col items-center justify-center p-4 text-center">
                <Sparkles className="w-10 h-10 text-purple-400 mb-2 animate-bounce" />
                <span className="text-xs text-purple-300">Chưa có ảnh avatar</span>
              </div>
            )}

            {/* Hiệu ứng sóng âm khi đang phát giọng nói */}
            {isSpeaking && (
              <div className="absolute bottom-2 left-2 right-2 py-1 px-2 bg-black/60 backdrop-blur-md rounded-lg flex items-center justify-center gap-1">
                <span className="w-1 h-3 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1 h-5 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1 h-4 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                <span className="text-[10px] text-white font-medium ml-1">Đang phát giọng nói</span>
              </div>
            )}
          </div>
        </div>

        {/* Thẻ trạng thái cảm xúc (giữ nguyên avatar tự tải mà không làm méo mặt) */}
        <div className="mt-3 flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-950/70 border border-purple-700/50 shadow-inner">
          <span className={currentStatus.color}>{currentStatus.icon}</span>
          <span className="text-xs font-medium text-slate-200">
            {customCharacter.name} · {currentStatus.label}
          </span>
          {!specificImage && defaultImage && (
            <span className="text-[10px] text-slate-400">(Ảnh đại diện)</span>
          )}
        </div>
      </div>
    );
  }

  // Render 4 nhân vật mẫu Vector Anime 2D cực kỳ sắc nét & chi tiết
  return (
    <div className="flex flex-col items-center">
      <div className="relative group">
        {/* Hào quang Cyberpunk */}
        <div
          className={`absolute -inset-1.5 rounded-3xl bg-gradient-to-tr from-purple-700/50 via-pink-600/40 to-cyan-500/50 opacity-60 blur-lg transition-all duration-700 ${
            isSpeaking ? 'opacity-95 scale-105' : 'group-hover:opacity-90'
          }`}
        />

        {/* Khung nhân vật anime */}
        <div
          className={`relative w-48 h-48 md:w-56 md:h-56 rounded-2xl bg-gradient-to-b from-[#1c133a] to-[#0f0921] border border-purple-500/40 shadow-2xl p-2 flex items-center justify-center overflow-hidden animate-breathe ${
            isSpeaking ? 'animate-speaking-glow' : ''
          }`}
        >
          {/* Lưới nền công nghệ mờ */}
          <div
            className="absolute inset-0 opacity-15 pointer-events-none"
            style={{
              backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(168, 85, 247, 0.4) 1px, transparent 1px)',
              backgroundSize: '16px 16px',
            }}
          />

          {/* SVG Vector Anime Nhân vật */}
          <svg
            viewBox="0 0 200 200"
            className="w-full h-full drop-shadow-lg transition-all duration-200"
            style={{ transform: expression === 'thinking' ? 'rotate(-2deg)' : 'none' }}
          >
            <defs>
              <linearGradient id="cyberHeadset" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#38bdf8" />
                <stop offset="100%" stopColor="#818cf8" />
              </linearGradient>
              <linearGradient id="aoiHair" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#0284c7" />
                <stop offset="50%" stopColor="#38bdf8" />
                <stop offset="100%" stopColor="#06b6d4" />
              </linearGradient>
              <linearGradient id="kuroHair" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#1e1b4b" />
                <stop offset="70%" stopColor="#312e81" />
                <stop offset="100%" stopColor="#f43f5e" />
              </linearGradient>
              <linearGradient id="lunaHair" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#581c87" />
                <stop offset="50%" stopColor="#a855f7" />
                <stop offset="100%" stopColor="#c084fc" />
              </linearGradient>
              <linearGradient id="renHair" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#0f172a" />
                <stop offset="50%" stopColor="#1e293b" />
                <stop offset="100%" stopColor="#475569" />
              </linearGradient>
              <linearGradient id="skinTone" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#fff1f2" />
                <stop offset="100%" stopColor="#ffe4e6" />
              </linearGradient>
            </defs>

            {/* ======================= TÓC PHÍA SAU ======================= */}
            {characterId === 'aoi' && (
              <path d="M 40 80 C 30 140, 50 170, 70 180 L 130 180 C 150 170, 170 140, 160 80 Z" fill="url(#aoiHair)" />
            )}
            {characterId === 'kuro' && (
              <>
                {/* Tai mèo Neko */}
                <path d="M 45 60 L 25 15 L 75 40 Z" fill="#1e1b4b" stroke="#f43f5e" strokeWidth="2" />
                <path d="M 45 52 L 32 24 L 68 40 Z" fill="#fb7185" />
                <path d="M 155 60 L 175 15 L 125 40 Z" fill="#1e1b4b" stroke="#f43f5e" strokeWidth="2" />
                <path d="M 155 52 L 168 24 L 132 40 Z" fill="#fb7185" />
                {/* Tóc sau Kuro */}
                <path d="M 45 75 C 35 125, 45 165, 65 175 L 135 175 C 155 165, 165 125, 155 75 Z" fill="url(#kuroHair)" />
              </>
            )}
            {characterId === 'luna' && (
              <>
                {/* Vòng công nghệ Android */}
                <circle cx="100" cy="40" r="38" fill="none" stroke="#c084fc" strokeWidth="2" strokeDasharray="6 4" opacity="0.8" />
                <path d="M 35 75 C 20 130, 40 185, 60 190 L 140 190 C 160 185, 180 130, 165 75 Z" fill="url(#lunaHair)" />
              </>
            )}
            {characterId === 'ren' && (
              <path d="M 50 70 C 45 120, 55 160, 75 170 L 125 170 C 145 160, 155 120, 150 70 Z" fill="url(#renHair)" />
            )}

            {/* ======================= THÂN / CỔ ÁO ======================= */}
            <path d="M 85 140 L 85 160 L 115 160 L 115 140 Z" fill="#ffe4e6" />
            {characterId === 'aoi' && (
              <path d="M 50 185 C 70 155, 130 155, 150 185 L 150 200 L 50 200 Z" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />
            )}
            {characterId === 'kuro' && (
              <>
                <path d="M 50 185 C 70 155, 130 155, 150 185 L 150 200 L 50 200 Z" fill="#4c0519" />
                <circle cx="100" cy="165" r="5" fill="#facc15" stroke="#eab308" strokeWidth="1.5" />
              </>
            )}
            {characterId === 'luna' && (
              <path d="M 50 185 C 70 155, 130 155, 150 185 L 150 200 L 50 200 Z" fill="#2e1065" stroke="#a855f7" strokeWidth="2" />
            )}
            {characterId === 'ren' && (
              <>
                <path d="M 50 185 C 70 155, 130 155, 150 185 L 150 200 L 50 200 Z" fill="#020617" />
                <path d="M 95 160 L 105 160 L 100 180 Z" fill="#eab308" />
              </>
            )}

            {/* ======================= KHUÔN MẶT ======================= */}
            <path d="M 55 80 C 55 135, 75 155, 100 155 C 125 155, 145 135, 145 80 C 145 45, 55 45, 55 80 Z" fill="url(#skinTone)" />

            {/* Tai hai bên */}
            <path d="M 52 90 C 48 95, 48 105, 54 110 Z" fill="#ffd1d5" />
            <path d="M 148 90 C 152 95, 152 105, 146 110 Z" fill="#ffd1d5" />

            {/* Má hồng (Blush) */}
            {(expression === 'happy' || characterId === 'kuro') && (
              <>
                <ellipse cx="68" cy="115" rx="9" ry="5" fill="#f43f5e" opacity="0.45" />
                <ellipse cx="132" cy="115" rx="9" ry="5" fill="#f43f5e" opacity="0.45" />
              </>
            )}
            {expression === 'speaking' && (
              <>
                <ellipse cx="68" cy="115" rx="6" ry="3.5" fill="#f43f5e" opacity="0.3" />
                <ellipse cx="132" cy="115" rx="6" ry="3.5" fill="#f43f5e" opacity="0.3" />
              </>
            )}

            {/* ======================= ĐÔI MẮT ANIME ======================= */}
            {isBlinking ? (
              // Trạng thái chớp mắt: mắt nhắm lại thành đường cong mượt
              <>
                <path d="M 68 100 Q 78 103 88 100" fill="none" stroke="#1e1b4b" strokeWidth="2.5" strokeLinecap="round" />
                <path d="M 112 100 Q 122 103 132 100" fill="none" stroke="#1e1b4b" strokeWidth="2.5" strokeLinecap="round" />
              </>
            ) : expression === 'happy' ? (
              // Mắt cười tươi hình vòng cung vui vẻ `^ ^`
              <>
                <path d="M 68 102 Q 78 92 88 102" fill="none" stroke="#1e1b4b" strokeWidth="3" strokeLinecap="round" />
                <path d="M 112 102 Q 122 92 132 102" fill="none" stroke="#1e1b4b" strokeWidth="3" strokeLinecap="round" />
              </>
            ) : expression === 'sad' ? (
              // Mắt buồn, chùng xuống, kèm giọt nước mắt lấp lánh
              <>
                <path d="M 70 94 Q 78 97 86 95" fill="none" stroke="#1e1b4b" strokeWidth="2" strokeLinecap="round" />
                <path d="M 114 95 Q 122 97 130 94" fill="none" stroke="#1e1b4b" strokeWidth="2" strokeLinecap="round" />
                <ellipse cx="78" cy="103" rx="7" ry="9" fill="#1e1b4b" />
                <ellipse cx="122" cy="103" rx="7" ry="9" fill="#1e1b4b" />
                <circle cx="76" cy="100" r="2.5" fill="#ffffff" />
                <circle cx="120" cy="100" r="2.5" fill="#ffffff" />
                {/* Giọt nước mắt anime */}
                <circle cx="68" cy="114" r="3" fill="#38bdf8" opacity="0.8" />
              </>
            ) : expression === 'thinking' ? (
              // Mắt nhìn chéo lên trên suy tư
              <>
                <ellipse cx="80" cy="97" rx="7" ry="10" fill="#1e1b4b" />
                <circle cx="82" cy="94" r="2.5" fill="#ffffff" />
                <ellipse cx="124" cy="97" rx="7" ry="10" fill="#1e1b4b" />
                <circle cx="126" cy="94" r="2.5" fill="#ffffff" />
                {/* Đồng tử theo màu sắc nhân vật */}
                <circle
                  cx="80"
                  cy="98"
                  r="4"
                  fill={characterId === 'aoi' ? '#06b6d4' : characterId === 'kuro' ? '#f43f5e' : characterId === 'luna' ? '#a855f7' : '#eab308'}
                />
                <circle
                  cx="124"
                  cy="98"
                  r="4"
                  fill={characterId === 'aoi' ? '#06b6d4' : characterId === 'kuro' ? '#f43f5e' : characterId === 'luna' ? '#a855f7' : '#eab308'}
                />
              </>
            ) : (
              // Trạng thái bình thường / nói chuyện: Mắt to tròn phong cách anime
              <>
                {/* Lông mày */}
                <path d="M 70 88 Q 78 86 86 89" fill="none" stroke="#1e1b4b" strokeWidth="2" strokeLinecap="round" />
                <path d="M 114 89 Q 122 86 130 88" fill="none" stroke="#1e1b4b" strokeWidth="2" strokeLinecap="round" />
                {/* Tròng mắt */}
                <ellipse cx="78" cy="100" rx="7.5" ry="10.5" fill="#0f172a" />
                <ellipse cx="122" cy="100" rx="7.5" ry="10.5" fill="#0f172a" />
                {/* Màu mắt neon */}
                <circle
                  cx="78"
                  cy="102"
                  r="5"
                  fill={characterId === 'aoi' ? '#38bdf8' : characterId === 'kuro' ? '#fb7185' : characterId === 'luna' ? '#c084fc' : '#facc15'}
                />
                <circle
                  cx="122"
                  cy="102"
                  r="5"
                  fill={characterId === 'aoi' ? '#38bdf8' : characterId === 'kuro' ? '#fb7185' : characterId === 'luna' ? '#c084fc' : '#facc15'}
                />
                {/* Đốm sáng trong mắt anime */}
                <circle cx="76" cy="97" r="2.5" fill="#ffffff" />
                <circle cx="81" cy="104" r="1.2" fill="#ffffff" />
                <circle cx="120" cy="97" r="2.5" fill="#ffffff" />
                <circle cx="125" cy="104" r="1.2" fill="#ffffff" />
              </>
            )}

            {/* Kính mắt của Ren */}
            {characterId === 'ren' && (
              <circle cx="78" cy="100" r="12" fill="none" stroke="#eab308" strokeWidth="1.5" />
            )}

            {/* Mũi nhỏ xíu dễ thương */}
            <path d="M 100 114 L 100 116" stroke="#fca5a5" strokeWidth="2" strokeLinecap="round" />

            {/* ======================= KHẨU HÌNH (MIỆNG) ======================= */}
            {isSpeaking || mouthOpen ? (
              // Miệng cử động khi nói
              <path d="M 94 126 Q 100 134 106 126 Z" fill="#f43f5e" stroke="#881337" strokeWidth="1" />
            ) : expression === 'happy' ? (
              // Miệng cười tươi
              <path d="M 93 125 Q 100 132 107 125" fill="none" stroke="#881337" strokeWidth="2.5" strokeLinecap="round" />
            ) : expression === 'sad' ? (
              // Miệng buồn chùng
              <path d="M 94 130 Q 100 125 106 130" fill="none" stroke="#881337" strokeWidth="2" strokeLinecap="round" />
            ) : expression === 'thinking' ? (
              // Miệng tròn suy nghĩ
              <circle cx="100" cy="127" r="2" fill="#881337" />
            ) : (
              // Mỉm cười dịu dàng
              <path d="M 95 126 Q 100 129 105 126" fill="none" stroke="#881337" strokeWidth="2" strokeLinecap="round" />
            )}

            {/* ======================= TÓC PHÍA TRƯỚC (BANGS) ======================= */}
            {characterId === 'aoi' && (
              <>
                <path d="M 50 65 C 50 40, 150 40, 150 65 C 130 90, 115 65, 100 85 C 85 65, 70 90, 50 65 Z" fill="url(#aoiHair)" />
                {/* Kẹp tóc neon cyber */}
                <rect x="52" y="62" width="14" height="4" rx="2" fill="#38bdf8" />
                <rect x="52" y="69" width="14" height="4" rx="2" fill="#38bdf8" />
              </>
            )}
            {characterId === 'kuro' && (
              <path d="M 52 65 C 52 45, 148 45, 148 65 C 135 88, 120 70, 100 88 C 80 70, 65 88, 52 65 Z" fill="url(#kuroHair)" />
            )}
            {characterId === 'luna' && (
              <>
                <path d="M 50 65 C 50 45, 150 45, 150 65 C 135 90, 120 65, 100 85 C 80 65, 65 90, 50 65 Z" fill="url(#lunaHair)" />
                {/* Cyber gem trên trán */}
                <polygon points="100,52 104,58 100,64 96,58" fill="#e879f9" />
              </>
            )}
            {characterId === 'ren' && (
              <path d="M 52 65 C 52 45, 148 45, 148 65 C 130 85, 110 65, 100 78 C 90 65, 70 85, 52 65 Z" fill="url(#renHair)" />
            )}
          </svg>
        </div>
      </div>

      {/* Trạng thái cảm xúc */}
      <div className="mt-3 flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1b1236]/80 border border-purple-500/30 shadow-inner">
        <span className={currentStatus.color}>{currentStatus.icon}</span>
        <span className="text-xs font-medium text-slate-200">{currentStatus.label}</span>
      </div>
    </div>
  );
};
