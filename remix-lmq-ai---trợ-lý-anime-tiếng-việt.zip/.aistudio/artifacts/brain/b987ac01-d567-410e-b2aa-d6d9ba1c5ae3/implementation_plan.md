# LMQ AI — Smart Knowledge Base Matching & Gemini AI Context Routing

Fix false-positive topic mismatches in the local search engine so unrelated questions no longer trigger wrong articles, while routing unmatched queries automatically to Gemini AI with relevant knowledge context.

## User Review & Critical Decisions

> [!IMPORTANT]
> **Confirmed Routing Strategy:** Based on your answers, the assistant will strictly match keywords and core subjects against the Local Knowledge Base first, automatically route non-matching queries to Gemini AI when enabled, and attach relevant knowledge snippets as grounding context.

- **Confirmed Decision 1 (Strict Keyword First, Gemini AI Fallback):** Queries only resolve from the Local Knowledge Base when they meet strict keyword, synonym, or core-subject coverage thresholds; any query without a genuine match routes directly to Gemini AI.
- **Confirmed Decision 2 (Automatic Gemini AI Fallback):** When Gemini AI mode is active, questions outside the Local Knowledge Base are answered automatically without forcing an intermediate fallback dead-end.
- **Confirmed Decision 3 (Knowledge-Grounded Context):** Related or user-taught entries from the Local Knowledge Base are passed to Gemini AI as optional reference context so answers stay aligned with your custom knowledge while ignoring unrelated articles.

---

## 1. Overview & Core Concept

- **What It Does:** Eliminates off-topic answers (such as matching *"ý nghĩa của cuộc sống là gì"* to a geometry article on Pi simply because both share the word *"nghĩa"*) by separating generic Vietnamese question framing words from actual subject keywords, enforcing minimum subject-token overlap, and combining exact local retrieval with context-aware Gemini AI responses.
- **Target Audience / Persona:** Vietnamese users chatting with the LMQ AI anime assistant for everyday Q&A, study help, coding, gaming, and custom personal notes.
- **Key Value:** Accurate answers every time—instant offline responses for known topics and natural, on-topic Gemini AI answers for open-ended questions.

---

## 2. User Experience & Visual Design

- **Key User Flows:**
  1. User sends a message (e.g., *"ý nghĩa của cuộc sống là gì"* or *"cách chế tạo bàn phù phép"*).
  2. Quick commands (opening games, opening the Knowledge Base modal, math expressions, date/time) execute immediately on the client.
  3. The Local Knowledge Engine checks whether the query genuinely matches a topic's core keywords, synonyms, or sample questions.
  4. **Match Found:** Displays the verified local article with the **Kho Tri Thức** badge and character persona.
  5. **No Strict Match (Gemini AI On):** Queries the server-side Gemini AI endpoint with recent chat history plus any loosely related Local Knowledge Base snippets as optional reference context, then renders the response with the **Gemini AI** badge and full Markdown/KaTeX formatting.
  6. **No Strict Match (Gemini AI Off):** Honestly reports that no local data was found and offers the **Ask Gemini AI**, **Teach LMQ AI**, and **Google Search** actions.
- **Visual Identity & Theme:** Preserves the existing deep-indigo/purple anime interface, character avatar/VRM stage, source badges (**Kho Tri Thức** vs. **Gemini AI**), and KaTeX math rendering without introducing clutter or API key forms.
- **Interactive Feedback & Motion:** Shows the existing animated typing indicator while checking local knowledge or waiting for Gemini AI, and gracefully falls back if the network or server endpoint is unavailable.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Strict Subject-Token Gating & Expanded Stop-Word Filtering**
  - *Chosen Approach:* Move generic Vietnamese question words (such as *"ý nghĩa"*, *"cách"*, *"làm"*, *"khái niệm"*, *"tại sao"*, *"định luật"*) into a non-scoring qualifier list, use word-boundary token matching instead of raw substring checks, and require strong subject-token coverage or an explicit keyword/sample-question match before accepting a local article.
  - *Why:* Prevents a single common framing word like *"nghĩa"* from hijacking completely unrelated open-ended questions, while keeping teencode, unaccented Vietnamese, and paraphrase variations working accurately.
  - *Alternatives Considered:* Simply raising the numeric score cutoff without fixing generic words—rejected because generic words could still accumulate points from both title and body text.

- **Decision 2: Word-Boundary Guard on Conversational Intent Rules**
  - *Chosen Approach:* Match casual social rules using whole-word or phrase boundaries rather than loose substring containment, and prioritize clear knowledge/open-ended questions before casual chitchat triggers.
  - *Why:* Stops short social keywords from accidentally intercepting longer factual questions.
  - *Alternatives Considered:* Removing rule-based chitchat—rejected to preserve instant offline greetings and character personality.

- **Decision 3: Relevance-Filtered Grounding Context for Gemini AI**
  - *Chosen Approach:* When a query misses the strict local threshold, pass up to the top 3 loosely related Local Knowledge Base entries (including user-taught custom items) to the server-side Gemini AI prompt with explicit instructions to use them only if genuinely relevant to the user's question and ignore them otherwise.
  - *Why:* Lets Gemini AI leverage custom facts you taught the bot without forcing unrelated context into answers.
  - *Alternatives Considered:* Sending the entire knowledge base on every request—rejected due to prompt bloat and latency.

---

## 4. Technical Architecture & Data Strategy

- **Architecture & Component Diagram:**

```
┌──────────────────────────────────────────────────────────────────────┐
│                        User Chat Input                               │
└──────────────────────────────────┬───────────────────────────────────┘
                                   ▼
┌──────────────────────────────────────────────────────────────────────┐
│               Local Command & Rule Pre-Processor                     │
│   (Game Triggers · Knowledge Modal · Safe Math · Date/Time)          │
└──────────────────────────────────┬───────────────────────────────────┘
                                   │ Not a command
                                   ▼
┌──────────────────────────────────────────────────────────────────────┐
│            Strict Local Knowledge Matching Engine                    │
│  • Strip generic Vietnamese framing words & normalize teencode       │
│  • Word-boundary matching on keywords, synonyms, titles & samples    │
│  • Require high confidence + core subject coverage                   │
└──────────────┬───────────────────────────────────────┬───────────────┘
               │ Strict Match                          │ No Match
               ▼                                       ▼
┌──────────────────────────────┐     ┌─────────────────────────────────┐
│  Render Local KB Answer      │     │  Extract Optional Context       │
│  [Kho Tri Thức Badge]        │     │  (Top custom/related snippets)  │
└──────────────────────────────┘     └─────────────────┬───────────────┘
                                                       ▼
                                     ┌─────────────────────────────────┐
                                     │  Server Proxy (/api/chat-gemini)│
                                     │  • Gemini 4 Hydrogen            │
                                     │  • Character Persona + History  │
                                     │  • Conditional KB Grounding     │
                                     └─────────────────┬───────────────┘
                                                       ▼
                                     ┌─────────────────────────────────┐
                                     │  Render AI Reply (Markdown/Math)│
                                     │  [Gemini AI Badge]              │
                                     └─────────────────────────────────┘
```

- **Data Model & State:** Knowledge items in IndexedDB remain unchanged; the client chat pipeline forwards optional `{ title, content, category }` context snippets alongside conversation history and character persona to the server-side proxy.
- **Interactive Component & State Mapping:** Toggling between **Gemini AI: Bật** and **Chỉ Offline** dynamically controls whether unmatched queries automatically route to the server endpoint or show the honest local fallback with manual action buttons; automated knowledge tests continue validating accented, unaccented, teencode, disambiguation, and out-of-scope rejection cases.
- **Key Sequences & Integrations:** Server-side calls continue using the `@google/genai` SDK with the `gemini-4-hydrogen` model and environment-configured `GEMINI_API_KEY`, returning structured `{ text, expression }` payloads for synchronized avatar reactions and Markdown/KaTeX rendering.
