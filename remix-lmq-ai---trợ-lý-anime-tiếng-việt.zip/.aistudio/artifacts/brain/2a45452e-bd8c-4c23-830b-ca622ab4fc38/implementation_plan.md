# Kế hoạch phát triển LMQ AI - Trợ lý Chatbot Anime Tiếng Việt & Character Selector

Kế hoạch xây dựng ứng dụng chatbot tiếng Việt **LMQ AI** hoạt động 100% dựa trên quy tắc (rule-based), giao diện tím đen cyberpunk anime cao cấp, tích hợp hệ thống quản lý avatar **Anime Character Selector** hỗ trợ ảnh tùy chỉnh đa biểu cảm và kiến trúc sẵn sàng tải mô hình 3D định dạng VRM qua Three.js.

---

### Quyết định từ khảo sát người dùng

> [!IMPORTANT]
> - **Chế độ 3D VRM**: Cung cấp song song cả chế độ hiển thị 2D biểu cảm hoạt họa tự nhiên và tab/chế độ thử nghiệm 3D VRM tương tác thời gian thực bằng Three.js (có sẵn công cụ nạp file `.vrm`/`.glb` từ máy tính và kèm hướng dẫn chi tiết).
> - **Bộ sưu tập nhân vật mẫu**: Cung cấp 4 nhân vật anime thiết kế sẵn với phong cách phong phú:
>   1. **Aoi (Cyber Assistant)**: Nữ trợ lý công nghệ tóc xanh neon, phong cách tương lai.
>   2. **Kuro (Neko Chibi)**: Cô bé tai mèo tinh nghịch, biểu cảm linh hoạt.
>   3. **Luna (Android Hacker)**: Nữ chiến binh cyberpunk mắt tím bí ẩn.
>   4. **Ren (Butler Scholar)**: Quản gia thông thái, điềm tĩnh và lịch lãm.
> - **Hành vi giọng nói tiếng Việt (TTS)**: Mặc định đọc khi người dùng bấm biểu tượng phát âm thanh ở từng tin nhắn hoặc kích hoạt nút bật/tắt "Tự động đọc" trên thanh điều khiển.
> - **Độc lập và an toàn**: Hoạt động hoàn toàn trên trình duyệt, không gọi Gemini/OpenAI API, không yêu cầu khóa API hay máy chủ cơ sở dữ liệu đám mây.

---

## 1. Tổng quan & Mục tiêu sản phẩm

- **Tên ứng dụng**: **LMQ AI** (Trợ lý Anime Thông minh Tiếng Việt).
- **Mục tiêu**: Cung cấp một người bạn đồng hành ảo mượt mà, phản hồi tức thì với kho tri thức tiếng Việt phong phú (chào hỏi, cảm xúc, lập trình web HTML/CSS/JS, tra cứu máy tính, tính toán toán học an toàn, ngày giờ thực tế, động lực học tập và các câu đố vui dí dỏm).
- **Khả năng mở rộng**: Người dùng có thể tự do thay đổi avatar, tải lên ảnh cá nhân theo 5 trạng thái cảm xúc (Bình thường, Vui vẻ, Buồn bã, Suy nghĩ, Nói chuyện), hoặc tải tệp mô hình 3D `.vrm` để quan sát mô hình 3D trong không gian Three.js.

---

## 2. Trải nghiệm người dùng & Thiết kế giao diện (UX/UI)

### 2.1 Bố cục và Phong cách thẩm mỹ (Cyberpunk Dark Purple)
- **Bảng màu chủ đạo (60-30-10)**:
  - *Nền canvas (60%)*: Màu tím đen sâu `#090714` kết hợp gradient chuyển mờ `#120c24`.
  - *Bề mặt cấu trúc (30%)*: Thẻ điều khiển, khung chat bo tròn bo viền `#241b3d` và `#1b142f`, độ tương phản vừa vặn không gây lóa mắt.
  - *Điểm nhấn tương tác (10%)*: Sắc tím neon `#a855f7`, ánh sáng hồng tím `#ec4899` và xanh lơ điện tử `#38bdf8` tạo cảm hứng anime công nghệ cao.
- **Bố cục màn hình**:
  - *Bên trái / Nửa trên*: Khung hình hiển thị nhân vật Anime (avatar tương tác với chuyển động chớp mắt, nhịp thở hô hấp idle, bóng đổ tiếp xúc và khung phản chiếu cảm xúc; chuyển đổi nhanh sang chế độ xem 3D VRM Three.js).
  - *Bên phải / Nửa dưới*: Cửa sổ hội thoại hiện đại với bong bóng chat mượt mà, gợi ý câu hỏi thông minh (quick prompts), thanh nhập tin nhắn có mic nhận diện giọng nói (Web Speech API), nút gửi và nút xóa đoạn chat.
  - *Thanh điều hướng trên cùng (Top Bar Contract)*: Logo thương hiệu "LMQ AI", nút chuyển nhanh tab "Trò chuyện", "Nhân vật của tôi", "Chế độ 3D VRM" và nút bật/tắt âm thanh.

### 2.2 Hoạt ảnh và Biểu cảm Anime (2D & 3D)
- **5 trạng thái cảm xúc tự nhiên**:
  - `idle`: Nhịp thở êm ái, chớp mắt chu kỳ ngẫu nhiên (3 - 5 giây/lần).
  - `happy`: Mắt cười cong, má hồng tỏa sáng, xuất hiện khi bot khen ngợi, cảm ơn hoặc đùa vui.
  - `thinking`: Nghiêng nhẹ đầu, mắt hướng lên suy tư khi đang tính toán hoặc tra cứu.
  - `speaking`: Khẩu hình mở nhẹ kết hợp sóng âm nhẹ nhàng theo nhịp trả lời giọng nói.
  - `sad`: Ánh mắt chùng xuống, xuất hiện khi người dùng buồn hoặc khi chia sẻ động viên.
- **Xử lý ảnh tự tải (Custom Upload Fallback)**:
  - Nếu người dùng tải đủ 5 ảnh cảm xúc: tự động đổi ảnh theo trạng thái.
  - Nếu người dùng chỉ tải 1 ảnh đại diện duy nhất: Giữ nguyên ảnh đại diện trang trọng và bổ sung nhãn hiệu ứng cảm xúc tinh tế thay vì làm méo mó khuôn mặt người dùng.

---

## 3. Kiến trúc kỹ thuật & Động cơ quy tắc tiếng Việt

### 3.1 Bộ xử lý ngôn ngữ quy tắc tiếng Việt (Rule Engine)
```
Input người dùng
       │
       ▼
Chuẩn hóa văn bản (Bỏ dấu phụ, chữ thường, lọc ký tự đặc biệt, chuẩn hóa teencode)
       │
       ▼
Kiểm tra biểu thức toán học an toàn (Safe Math Parser, KHÔNG dùng eval())
       │
       ▼
Khớp mẫu Intent & Keywords tiếng Việt (Chào hỏi, giờ giấc, máy tính, code, giải trí...)
       │
       ├── Khớp thành công ──► Chọn ngẫu nhiên 1 trong nhiều câu trả lời + Gán cảm xúc phù hợp
       │
       └── Không khớp ───────► Phản hồi gợi ý thông minh + Cung cấp nút Tra cứu Google
```

- **Hỗ trợ biến thể tiếng Việt**: Tự động nhận diện cả tiếng Việt có dấu (`thời tiết hôm nay thế nào`) và không dấu (`thoi tiet hom nay the nao`), các từ viết tắt/teencode phổ biến (`ko`, `dc`, `bt`, `j`, `sao vay`).
- **An toàn toán học**: Đánh giá các phép toán cộng, trừ, nhân, chia, lũy thừa, căn bậc hai thông qua thuật toán phân tích cú pháp an toàn (Tokenization & Shunting-yard), ngăn ngừa tuyệt đối mọi nguy cơ XSS hay lỗi thực thi mã độc.
- **Bộ dữ liệu phong phú**: Hơn 20 nhóm chủ đề với hàng trăm phản hồi tiếng Việt tự nhiên, có cảm xúc và thông minh.

### 3.2 Hệ thống 3D VRM & Three.js Architecture
- Tích hợp Three.js với chuẩn PBR, `RoomEnvironment`, `ACESFilmicToneMapping` và module nạp VRM (`GLTFLoader` + `@pixiv/three-vrm`).
- Cho phép xem trước mô hình 3D, xoay 360 độ (OrbitControls), tương tác chuyển động nhẹ (breathing & blinking qua VRM BlendShapes/MorphTargets).
- Cung cấp tính năng "Tải tệp VRM của bạn" (`.vrm`/`.glb`) từ máy tính chạy trực tiếp trên bộ nhớ trình duyệt (FileReader URL), không gửi file lên bất kỳ máy chủ nào.

---

## 4. Sơ đồ kiến trúc thành phần

```
┌────────────────────────────────────────────────────────────────────────┐
│                        LMQ AI Web Application                          │
├────────────────────────────────────────────────────────────────────────┤
│ Top Navigation: [Brand: LMQ AI] ── [Trò chuyện | Nhân vật | 3D VRM] ── │
├──────────────────────────────────┬─────────────────────────────────────┤
│      Khu vực Nhân vật (Trái)     │       Khu vực Hội thoại (Phải)      │
│ ┌──────────────────────────────┐ │ ┌─────────────────────────────────┐ │
│ │ • Anime 2D Vector Display    │ │ │ Danh sách tin nhắn (Scrollable) │ │
│ │   - Chớp mắt (CSS/JS Timer)  │ │ │ - Bong bóng tin nhắn User/Bot   │ │
│ │   - 5 Biểu cảm động          │ │ │ - Nút nghe đọc (TTS) từng câu   │ │
│ │ • Hoặc Three.js VRM Viewport │ │ │ - Nút tra cứu Google khi cần    │ │
│ │   - Tương tác chuột Orbit    │ │ ├─────────────────────────────────┤ │
│ │   - Nạp tệp .VRM tùy chọn    │ │ │ Gợi ý câu hỏi nhanh (Quick Chips)││
│ └──────────────────────────────┘ │ ├─────────────────────────────────┤ │
│ ┌──────────────────────────────┐ │ │ Ô nhập liệu + Nút Mic nhận diện │ │
│ │ Bộ chọn "Nhân vật của tôi"   │ │ │ Nút Gửi + Nút Xóa lịch sử       │ │
│ │ - 4 Nhân vật mẫu có sẵn      │ │ └─────────────────────────────────┘ │
│ │ - Tải ảnh đại diện/biểu cảm  │ │                                     │
│ └──────────────────────────────┘ │                                     │
├──────────────────────────────────┴─────────────────────────────────────┤
│ Bộ nhớ cục bộ: LocalStorage (Lưu lịch sử chat, nhân vật và cấu hình)   │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 5. Quy trình thực hiện chi tiết

1. **Khởi tạo dữ liệu & Cấu hình ứng dụng**:
   - Khởi tạo `metadata.json` với tên `LMQ AI - Trợ lý Anime Tiếng Việt`.
   - Cài đặt các gói thư viện cần thiết (`three`, `@pixiv/three-vrm`, `@types/three`).
2. **Xây dựng Động cơ Quy tắc Tiếng Việt (`vietnameseRules.ts`)**:
   - Từ điển nhận diện intent, chuẩn hóa tiếng Việt không dấu.
   - Trình phân tích toán học an toàn không dùng `eval()`.
   - Động cơ ngày giờ động, các lời khuyên công nghệ, HTML/CSS/JS, giải trí.
3. **Phát triển Nhân vật Anime 2D & Hệ thống Quản lý Avatar**:
   - Thiết kế vector anime 2D chất lượng cao (Aoi, Kuro, Luna, Ren) với các trạng thái biểu cảm.
   - Giao diện "Nhân vật của tôi": chọn thẻ nhân vật, tải ảnh tùy biến (`PNG`, `JPG`, `WebP`), xóa ảnh và khôi phục mặc định.
   - Lưu trữ toàn bộ vào `localStorage`.
4. **Phát triển Chế độ 3D VRM Three.js (`VrmViewer.tsx`)**:
   - Thiết lập khung nhìn 3D chuẩn studio, ánh sáng 3 điểm, đổ bóng mềm và sàn phản xạ.
   - Trình nạp VRM qua Three.js GLTFLoader hỗ trợ nạp tệp VRM trực tiếp từ máy tính.
   - Hướng dẫn chi tiết bằng tiếng Việt cách tải mô hình VRM miễn phí (VRoid Hub, Booth).
5. **Giao diện Chat & Âm thanh Web Speech**:
   - Bong bóng chat đẹp mắt, hiệu ứng gõ chữ (typing indicator).
   - Tích hợp SpeechSynthesis (TTS tiếng Việt) và SpeechRecognition (STT).
   - Nút tra cứu Google Query mở tab mới tiện lợi.
6. **Kiểm tra, biên dịch và hoàn thiện**:
   - Kiểm tra `compile_applet`, rà soát các chức năng và biên soạn tài liệu hướng dẫn chạy trên Windows.
