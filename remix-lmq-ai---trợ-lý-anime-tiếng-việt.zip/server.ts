import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);

app.use(express.json());

// Khởi tạo Gemini AI SDK an toàn trên server-side
function getAiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Kiểm tra trạng thái cấu hình Gemini AI miễn phí trên server (không lộ key)
app.get('/api/ai-status', (_req, res) => {
  res.json({
    configured: Boolean(process.env.GEMINI_API_KEY),
    model: 'gemini-4-hydrogen',
  });
});

// Endpoint proxy gọi Gemini AI miễn phí (gemini-4-hydrogen) an toàn từ server-side
app.post('/api/chat-gemini', async (req, res) => {
  try {
    const { message, characterName, personality, history, knowledgeContext } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Nội dung tin nhắn không hợp lệ' });
    }

    const ai = getAiClient();
    if (!ai) {
      return res.status(503).json({
        error: 'Chưa cấu hình GEMINI_API_KEY trên máy chủ (Settings > Secrets).',
        fallback: true,
      });
    }

    const systemInstruction = `Bạn là ${characterName || 'LMQ AI'} - một trợ lý anime tiếng Việt thông minh, dễ thương và ân cần.
Đặc điểm tính cách: ${personality || 'Ấm áp, hòa đồng, lễ phép, sử dụng tiếng Việt tự nhiên và thêm biểu cảm anime nhẹ nhàng như (✿◠‿◠), (≧◡≦), (•̀o•́)ง'}.
Quy tắc:
1. Trả lời bằng tiếng Việt tự nhiên, súc tích, chính xác và hỗ trợ người dùng hết mình.
2. Tập trung trả lời đúng trọng tâm câu hỏi của người dùng.
3. Định dạng câu trả lời bằng Markdown đẹp mắt (gạch đầu dòng, in đậm từ khóa, công thức LaTeX $...$ nếu cần, khối code nếu liên quan lập trình).
4. Nếu có đoạn tham khảo từ Kho Tri Thức Cục Bộ kèm theo, CHỈ sử dụng khi thông tin đó thực sự liên quan đến câu hỏi; nếu không liên quan thì bỏ qua hoàn toàn.`;

    const contextBlock =
      Array.isArray(knowledgeContext) && knowledgeContext.length > 0
        ? `Tài liệu tham khảo từ Kho Tri Thức Cục Bộ (chỉ dùng nếu liên quan trực tiếp):\n${knowledgeContext
            .slice(0, 3)
            .map(
              (k: { title?: string; content?: string }, idx: number) =>
                `[${idx + 1}] ${String(k.title || '')}: ${String(k.content || '').slice(0, 500)}`
            )
            .join('\n\n')}\n\n`
        : '';

    const historyBlock =
      Array.isArray(history) && history.length > 0
        ? `Ngữ cảnh hội thoại gần đây:\n${history
            .slice(-4)
            .map((h: { sender?: string; text?: string }) =>
              `${h.sender === 'user' ? 'Người dùng' : characterName || 'LMQ AI'}: ${String(h.text || '').slice(0, 300)}`
            )
            .join('\n')}\n\n`
        : '';

    const promptContents = `${contextBlock}${historyBlock}Câu hỏi hiện tại của người dùng: ${message}`;

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: promptContents,
      config: {
        systemInstruction,
      },
    });

    const responseText = response.text || 'Mình đã nhận được câu hỏi nhưng chưa thể trả lời lúc này.';

    // Phân tích biểu cảm phù hợp
    let expression: 'happy' | 'thinking' | 'sad' | 'idle' = 'happy';
    const lower = responseText.toLowerCase();
    if (lower.includes('buồn') || lower.includes('tiếc') || lower.includes('xin lỗi')) {
      expression = 'sad';
    } else if (
      lower.includes('nghĩ') ||
      lower.includes('phân tích') ||
      lower.includes('thuật toán') ||
      lower.includes('giải thích')
    ) {
      expression = 'thinking';
    }

    res.json({
      text: responseText,
      expression,
      model: 'gemini-4-hydrogen',
    });
  } catch (err: any) {
    console.error('Lỗi Gemini API:', err);
    const status = typeof err?.status === 'number' ? err.status : 500;
    res.status(status).json({
      error: err?.message || 'Lỗi xử lý Gemini AI',
      fallback: true,
    });
  }
});

// Thiết lập Vite middlewares cho môi trường dev và static files cho production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`LMQ AI Server đang chạy tại http://0.0.0.0:${port}`);
  });
}

startServer();
